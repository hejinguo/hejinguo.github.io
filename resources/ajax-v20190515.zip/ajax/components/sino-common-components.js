/**
 * ҳ�涥���Ĺ�����
 * @type {Function|*}
 */
var SinoBarHeader = san.defineComponent({
    template:
    '<div class="sino-san-bar-header">' +
    '<a s-if="close" href="javascript:void(0)" on-click="callback({code:\'Close\',done:\'do_Close\'})">' +
    '    <i class="fa fa-remove"></i><span style="">&nbsp;�ر�</span>' +
    '</a>' +
    '<a s-if="cancel" href="javascript:void(0)" on-click="callback({code:\'Cancel\',done:\'do_Custom_Cancel\'})">' +
    '    <i class="fa fa-undo"></i><span style="">&nbsp;����</span>' +
    '</a>' +
    '<a s-if="reject" href="javascript:void(0)" on-click="callback({code:\'Reject\',done:\'do_Custom_Cancel\'})">' +
    '    <i class="fa fa-backward"></i><span style="">&nbsp;�˻�</span>' +
    '</a>' +
    '<a s-if="save" href="javascript:void(0)" on-click="callback({code:\'Save\',done:\'do_Custom_Save\'})">' +
    '    <i class="fa fa-floppy-o"></i><span style="">&nbsp;����</span>' +
    '</a>' +
    '<a s-if="submit" href="javascript:void(0)" on-click="callback({code:\'Submit\',done:\'do_Custom_Submit\'})">' +
    '    <i class="fa fa-arrow-right"></i><span style="">&nbsp;�ύ</span>' +
    '</a>' +
    '</div>',
    callback: function (data) {
        this.fire('click', data);
    }
});

/**
 * ҳ�湦�ܷ�����
 * @type {Function|*}
 */
var SinoNavHeader = san.defineComponent({
    template:
    '<ul class="nav nav-tabs-title">' +
    '<li class="active"><span><i class="{{icon}}" s-if="icon"></i>{{title}}</span></li>' +
    '<li class="buttons"><slot></slot></li>' +
    '</ul>',
    initData: function () {
        return {
            title: '������ "title" ����'
        };
    }
});

/**
 * ҳ�湦�ܰ�ť
 * @type {Function}
 */
var SinoButton = san.defineComponent({
    template:
    '<button type="{{category}}" class="btn {{type}} {{size}}" disabled="{{disabled}}" on-click="_doClickButton">' +
    '<i s-if="{{icon}}" class="fa {{icon}}"></i>{{title}}' +
    '</button>',
    initData: function () {
        return {
            type: 'btn-primary',
            size: 'btn-sm',
            icon: null,//fa-info
            title: '��ͨ��ť',
            disabled: false,
            category: 'button'
        }
    },
    _doClickButton: function () {
        // console.log(this.data.get());
        this.fire('click');//, this.data.get()
    }
});

/**
 * ҳ������пؼ�
 * @type {Function|*}
 */
var SinoDataTable = san.defineComponent({
    template:
    '<table class="table table-bordered table-striped table-hover">' +
    '<thead>' +
    '<tr><th s-for="column,hindex in columns" width="{{column.width}}">' +
    '<template s-if="column.name == \'$check\'"><input type="checkbox" on-click="_checkedAll($event)" checked="{{checkedAll}}"/></template>' +
    '<template s-else>{{column.title}}</template>' +
    '</th></tr>' +
    '</thead>' +
    '<tbody>' +
    '<tr s-for="row,rindex in rows"><td s-for="column,cindex in columns" class="text-{{column.align ? column.align : \'left\'}}">' +
    '<template s-if="column.name == \'$check\'"><input type="checkbox" value="{{rindex}}" checked="{= value =}" on-click="_checkedOne()"/></template>' +
    '<template s-elif="column.name == \'$index\'">{{rindex+1}}</template>' +
    '<template s-elif="column.name == \'$slot\'"><slot name="{{column.slot}}" var-row="row" var-column="column" var-index="rindex">{{row[column.name]}}</slot></template>' +
    // '<template s-elif="column.name == \'$render\'">{{column | renderFormat(row) | raw}}</template>' + React����Render��ʱ������,����Vue����Slot
    '<template s-else>{{row[column.name] | raw}}</template>' +
    '</td></tr>' +
    '</tbody>' +
    '</table>',
    initData: function () {
        return {
            value: []
        };
    },
    computed: {
        checkedAll: function () {
            return this.data.get('value').length == this.data.get('rows').length && this.data.get('value').length > 0;
        }
    },
    _checkedAll: function (e) {
        // console.log(e.srcElement);//e.target.checked
        if (e.srcElement.checked) {
            var _checkeds = [];
            for (var i = 0; i < this.data.get('rows').length; i++) {
                _checkeds.push(i + '');
            }
            this.data.set('value', _checkeds);
        } else {
            this.data.set('value', []);
        }
        this._checkedOne();
    },
    _checkedOne: function () {
        var that = this;
        this.nextTick(function () {
            // that.data.set('value', that.data.get('value'));//value���԰�ѡ��ֵ
            that.fire('check', {checkeds: that.data.get('value')});
        });
    }
});

/**
 * ҳ��ͨ�÷�ҳ�ؼ�
 * @type {Function|*}
 */
var SinoPagination = san.defineComponent({
    template:
    '<nav class="text-center">' +
    '<ul class="pagination" style="margin:5px 0px;">' +
    '<template s-if="pagination.curPage > 1">' +
    '<li><a href="javascript:void(0);" on-click="_changeCurPage(1)">��ҳ</a></li>' +
    '<li><a href="javascript:void(0);" on-click="_changeCurPage(pagination.curPage-1)">��һҳ</a></li>' +
    '</template>' +
    '<template s-else>' +
    '<li class="disabled"><a href="javascript:void(0);">��ҳ</a></li>' +
    '<li class="disabled"><a href="javascript:void(0);">��һҳ</a></li>' +
    '</template>' +
    '<li s-for="number,index in pageNumbers" class="{{pagination.curPage == number ? \'active\' : \'\'}}">' +
    '<a href="javascript:void(0);" on-click="_changeCurPage(number)">{{number}}</a>' +
    '</li>' +
    '<template s-if="pagination.curPage < pagination.pageCount">' +
    '<li><a href="javascript:void(0);" on-click="_changeCurPage(pagination.curPage+1)">��һҳ</a></li>' +
    '<li><a href="javascript:void(0);" on-click="_changeCurPage(pagination.pageCount)">βҳ</a></li>' +
    '</template>' +
    '<template s-else>' +
    '<li class="disabled"><a href="javascript:void(0);">��һҳ</a></li>' +
    '<li class="disabled"><a href="javascript:void(0);">βҳ</a></li>' +
    '</template>' +
    '</ul>' +
    '<ul class="pagination-msg" style="margin:5px 0px;">' +
    '<span>�� {{pagination.pageCount}} ҳ����ǰ�ǵ� {{pagination.curPage}} ҳ����ת����</span>' +
    '<input type="text" class="form-control input-sm" value="{{pagination.curPage}}" on-keyup="_inputCurPage($event)" title="����ҳ����밴�س�����ת">' +
    '<span>ҳ</span>' +
    '</ul>' +
    '</nav>',
    computed: {
        pageNumbers: function () {
            var page = this.data.get('pagination');
            var result = new Array();
            for (var i = 1; i <= page.pageCount; i++) {
                if ((i >= page.curPage - 2 && i <= page.curPage + 2)) {
                    result.push(i);
                }
            }
            return result;
        }
    },
    _changeCurPage: function (curPage) {
        this.data.set('pagination.curPage', curPage);
        this.fire('page', this.data.get('pagination'));
    },
    _inputCurPage: function (e) {
        if (e.keyCode == 13) {
            var page = this.data.get('pagination');
            var _pageNum = e.srcElement.value;
            if (isNaN(_pageNum) || isNaN(parseInt(_pageNum)) || parseInt(_pageNum) < 1) {
                _pageNum = 1;
            } else if (parseInt(_pageNum) > page.pageCount) {
                _pageNum = page.pageCount;
            }
            this._changeCurPage(_pageNum);
        }
    }
});

/**
 * DIV��ʽ��ģ̬����
 * @type {Function}
 */
var SinoModalDialog = san.defineComponent({
    template:
    '<div class="modal fade sino-box {{classKey ? classKey : \'_bs_example_modal\'}}" id="{{_san_bs_dialog_id}}" ' +
    '   tabindex="-1" role="dialog" aria-hidden="true" data-backdrop="static">' +
    '<div class="modal-dialog modal-lg" role="document">' +
    '<div class="modal-content">' +
    '<div class="modal-header">' +
    '<button s-if="cancelBtnFlag" type="button" class="close" data-dismiss="modal" aria-label="Close" style="margin-top:0px;">' +
    '<i class="fa fa-close"></i>' +
    '</button>' +
    '<h3 class="modal-title"><i class="fa fa-windows"></i> {{title}}</h3>' +
    '</div>' +
    '<div class="modal-body sino-box-modal">' +
    '<div style="max-height: 500px;overflow: auto;border-bottom:1px solid #e5e5e5;padding-bottom: 10px;">' +
    '<slot></slot>' +
    '</div>' +
    '<div class="text-center sino-san-box-buttons">' +
    '<slot name="buttons"></slot>' +
    '<button type="button" s-if="cancelBtnFlag" class="btn btn-default btn-sm" data-dismiss="modal">' +
    '<i class="fa fa-close"></i>�ر�' +
    '</button>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: 'ģ̬���ڵı���',
            _san_bs_dialog_id: '_san_bs_dialog_' + Math.random().toString().substring(2),
            cancelBtnFlag: true//Ĭ���Ƿ���ʾ�رհ�ť
        };
    },
    attached: function () {
        var that = this;
        $('#' + this.data.get('_san_bs_dialog_id')).on('hide.bs.modal', function (e) {
            that.data.set('show', false);
        })
        this._doDialogModal();
        this.watch('show', function (value) {
            this._doDialogModal();
        });
    },
    _doDialogModal: function () {
        // console.log("show:" + this.data.get('show'));
        if (this.data.get('show')) {
            $('#' + this.data.get('_san_bs_dialog_id')).modal({backdrop: 'static', keyboard: false});
        } else {
            $('#' + this.data.get('_san_bs_dialog_id')).modal('hide');
        }
    }
});

/**
 * ��ͨ���ı�¼���
 * @type {Function}
 */
var SinoInput = san.defineComponent({
    template:
    '<input type="text" class="form-control input-sm" value="{= value =}" ' +
    '   readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}" />'
});

/**
 * �����е��ı�¼���
 * @type {Function}
 */
var SinoFormInput = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}}">' +
    '<input type="text" class="form-control input-sm" value="{= value =}" ' +
    '   on-keyup="_inputKeyUp($event)" ' +
    '   readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '�����',
            cell: [4, 8]
        };
    },
    _inputKeyUp: function (e) {
        this.fire('keyup', e);
    }
});

/**
 * ��ͨ���ı�¼����
 * @type {Function}
 */
var SinoTextArea = san.defineComponent({
    template: '<textarea class="form-control" rows="{{rows}}" value="{= value =}" readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}" maxlength="{{number}}"></textarea>',
    initData: function () {
        return {
            rows: 3,
            number: 200//�������������
        };
    }
});

/**
 * �����е��ı�¼����
 * @type {Function}
 */
var SinoFormTextArea = san.defineComponent({
    template:
    '<div class="form-group sino-form-group sino-form-group-horizontal">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}}" data-toggle="text-count">' +
    '<textarea class="form-control" rows="{{rows}}" value="{= value =}" readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}"></textarea>' +
    '<span class="text-count"><var class="text-count-word">{{number}}</var>/{{number}}</span>' +
    '</div>' +
    '</div>',
    initData: function () {//statInputNum($(this).find("textarea"),$(this).find(".text-count-word"));
        return {
            title: '�ı���',
            cell: [2, 10],
            rows: 3,
            number: 200//�������������
        };
    }
});

/**
 * ��ͨ������ѡ���
 * @type {Function}
 */
var SinoSelect = san.defineComponent({
    template:
    '<select class="form-control input-sm" value="{= value =}" readonly="{{readonly}}" disabled="{{disabled}}" s-ref="sino-san-form-select">' +
    '<option s-for="item,index in options" value="{{item[optionValue]}}">{{item[optionText]}}</option>' +
    '</select>',
    initData: function () {
        return {
            options: [],
            optionValue: 'value',
            optionText: 'text'
        };
    },
    attached: function () {
        var _this = this;
        _this.watch('options', function (options) {
            _this.nextTick(function () {
                $(_this.ref('sino-san-form-select')).selectpicker('refresh');
            });
        });
        _this.watch('value', function (value) {
            $(_this.ref('sino-san-form-select')).selectpicker('val', value);
        });
    }
});

/**
 * �����е�����ѡ���
 * @type {Function}
 */
var SinoFormSelect = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}}">' +
    '<select class="form-control input-sm" value="{= value =}" readonly="{{readonly}}" disabled="{{disabled}}" s-ref="sino-san-form-select">' +
    '<option s-for="item,index in options" value="{{item[optionValue]}}">{{item[optionText]}}</option>' +
    '</select>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: 'ѡ���',
            cell: [4, 8],
            options: [],
            optionValue: 'value',
            optionText: 'text'
        };
    },
    attached: function () {
        var _this = this;
        _this.watch('options', function (options) {
            _this.nextTick(function () {
                $(_this.ref('sino-san-form-select')).selectpicker('refresh');
            });
        });
        _this.watch('value', function (value) {
            $(_this.ref('sino-san-form-select')).selectpicker('val', value);
        });
    }
});

/**
 * ��ͨ��LOOKUPѡ���
 * @type {Function}
 */
var SinoLookup = san.defineComponent({
    template: '<div class="input-group">' +
    '<input type="text" class="form-control input-sm" on-click="_doCommonLookupSearch" readonly value="{{message ? message : placeholder}}"/>' +
    // '<span class="input-group-addon input-group-addon-clear" style="display: none"><i class="fa fa-close"></i></span>' +
    '<span class="input-group-addon" on-click="_doCommonLookupSearch"><i class="fa fa-folder-open"></i></span>' +
    '</div>',
    _doCommonLookupSearch: function () {
        if (this.data.get('exception')) {//������exception��Ϣʱ������ѡ��Lookup
            if (BootstrapDialog && BootstrapDialog.alert) {
                BootstrapDialog.alert(this.data.get('exception'));
            } else {
                alert(this.data.get('exception'));
            }
            return false;
        } else if (this.data.get('disabled')) {//������Ϊ����ʱ������ѡ��Lookup
            return false;
        }
        var that = this;
        var _options = {
            lookupCode: this.data.get('code'),
            lookupData: this.data.get('data'),
            onCallback: function (data) {
                if (data) {
                    that.fire('select', data);
                }
            }
        };
        if (this.data.get('multiple')) {
            sino.lookupList(_options)
        } else {
            sino.lookupOne(_options);
        }
    }
});

/**
 * �����е�LOOKUPѡ���
 * @type {Function}
 */
var SinoFormLookup = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}} input-group">' +
    '<input type="text" class="form-control input-sm" on-click="_doCommonLookupSearch" readonly value="{{message ? message : placeholder}}"/>' +
    // '<span class="input-group-addon input-group-addon-clear" style="display: none"><i class="fa fa-close"></i></span>' +
    '<span class="input-group-addon" on-click="_doCommonLookupSearch"><i class="fa fa-folder-open"></i></span>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: 'LOOKUP',
            disabled: false,
            cell: [4, 8]
        };
    },
    _doCommonLookupSearch: function () {
        if (this.data.get('exception')) {//������exception��Ϣʱ������ѡ��Lookup
            if (BootstrapDialog && BootstrapDialog.alert) {
                BootstrapDialog.alert(this.data.get('exception'));
            } else {
                alert(this.data.get('exception'));
            }
            return false;
        } else if (this.data.get('disabled')) {//������Ϊ����ʱ������ѡ��Lookup
            return false;
        }
        var that = this;
        var _options = {
            lookupCode: this.data.get('code'),
            lookupData: this.data.get('data'),
            onCallback: function (data) {
                if (data) {
                    that.fire('select', data);
                }
            }
        };
        if (this.data.get('multiple')) {
            sino.lookupList(_options)
        } else {
            sino.lookupOne(_options);
        }
    }
});

/**
 * �����еĵ�ѡ��
 * @type {Function}
 */
var SinoFormRadio = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}} radio">' +
    '<label s-for="item,index in items" style="margin-right:6px;"><input type="radio" value="{{item.value}}" checked="{= value =}" name="{{_san_bs_radio_name}}">{{item.text}}</label>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '��ѡ��',
            cell: [4, 8],
            _san_bs_radio_name: '_san_bs_radio_' + Math.random().toString().substring(2)
        };
    }
});

/**
 * �����еĸ�ѡ��
 * @type {Function}
 */
var SinoFormCheckbox = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}} checkbox">' +
    '<label s-for="item,index in items" style="margin-right:6px;"><input type="checkbox" value="{{item.value}}" checked="{= value =}">{{item.text}}</label>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '��ѡ��',
            cell: [4, 8]
        };
    }
});

/**
 * �����е�����ѡ���
 * @type {Function}
 */
var SinoFormDatePicker = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}} input-group">' +
    '<input type="text" id="{{_san_bs_dp_id}}" class="form-control input-sm" value="{= value =}" on-click="_doSelectDate" readonly disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    // '<span class="input-group-addon input-group-addon-clear" style="display: none"><i class="fa fa-close"></i></span>' +
    '<span class="input-group-addon" on-click="_doSelectDate"><i class="fa fa-calendar"></i></span>' +
    // '<input type="text" id="{{_san_bs_dp_id}}" class="form-control input-sm" value="{= value =}" on-click="callback" readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '����ѡ��',
            pattern: 'yyyy-MM-dd HH:mm:ss',
            cell: [4, 8],
            _san_bs_dp_id: '_san_bs_datepicker_' + Math.random().toString().substring(2)
        };
    },
    _doSelectDate: function () {
        var that = this;
        WdatePicker(
            {
                el: this.data.get('_san_bs_dp_id'),
                dateFmt: this.data.get('pattern'),
                onpicked: function (dp) {
                    that.data.set('value', dp.cal.getNewDateStr());
                },
                oncleared: function (dp) {
                    that.data.set('value', '');
                }
            }
        );
    }
});

/**
 * �����е���������ѡ����
 * @type {Function}
 */
var SinoFormDateRangePicker = san.defineComponent({
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i> {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}} form-inline">' +
    '<div class="col-sm-6 input-group">' +
    // '<div class="input-group-addon">��</div>'+
    '<input type="text" id="{{_san_bs_dp_id[0]}}" class="form-control input-sm" value="{= value[0] =}" on-click="_doSelectDate(0)" readonly disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    // '<span class="input-group-addon input-group-addon-clear" style="display: none"><i class="fa fa-close"></i></span>' +
    '<span class="input-group-addon" on-click="_doSelectDate(0)"><i class="fa fa-calendar"></i></span>' +
    // '<input type="text" id="{{_san_bs_dp_id}}" class="form-control input-sm" value="{= value =}" on-click="callback" readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    '</div>' +
    '<div class="col-sm-6 input-group">' +
    // '<div class="input-group-addon">��</div>'+
    '<input type="text" id="{{_san_bs_dp_id[1]}}" class="form-control input-sm" value="{= value[1] =}" on-click="_doSelectDate(1)" readonly disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    // '<span class="input-group-addon input-group-addon-clear" style="display: none"><i class="fa fa-close"></i></span>' +
    '<span class="input-group-addon" on-click="_doSelectDate(1)"><i class="fa fa-calendar"></i></span>' +
    // '<input type="text" id="{{_san_bs_dp_id}}" class="form-control input-sm" value="{= value =}" on-click="callback" readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}"/>' +
    '</div>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '����ѡ��',
            pattern: 'yyyy-MM-dd HH:mm:ss',
            cell: [4, 8],
            _san_bs_dp_id: [
                '_san_bs_datepicker_0_' + Math.random().toString().substring(2),
                '_san_bs_datepicker_1_' + Math.random().toString().substring(2)
            ],
        };
    },
    _doSelectDate: function (idx) {
        var that = this;
        WdatePicker(
            {
                el: this.data.get('_san_bs_dp_id[' + idx + ']'),
                dateFmt: this.data.get('pattern'),
                minDate: idx == 1 ? this.data.get('value[0]') : '',//DateRange
                maxDate: idx == 0 ? this.data.get('value[1]') : '',//DateRange
                onpicked: function (dp) {
                    that.data.set('value[' + idx + ']', dp.cal.getNewDateStr());
                },
                oncleared: function (dp) {
                    that.data.set('value[' + idx + ']', '');
                }
            }
        );
    }
});

/**
 * �����е��Զ���ɿ�
 * @type {Function|*}
 */
var SinoFormAutocomplete = san.defineComponent({
    //https://www.cnblogs.com/shiyu404/p/6344591.html,https://github.com/bassjobsen/Bootstrap-3-Typeahead,https://www.cnblogs.com/haogj/p/3376874.html
    template:
    '<div class="form-group sino-form-group">' +
    '<label class="col-sm-{{cell[0]}} control-label"><i s-if="required" class="text-red">*</i>' +
    '<img src="{{imgAddress}}" s-if="showLoading"/>' +
    ' {{title}}��</label>' +
    '<div class="col-sm-{{cell[1]}}">' +
    '<input type="text" id="{{_san_autocomplete_id}}" class="form-control input-sm typeahead" ata-provide="typeahead" autocomplete="off" ' +
    '   readonly="{{readonly}}" disabled="{{disabled}}" placeholder="{{placeholder}}" />' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            title: '�Զ���ɿ�',
            cell: [4, 8],
            url: '',
            param: 'searchParam',
            showLoading: false,
            writeBack: true,//�Ƿ��дѡ�������
            _san_autocomplete_id: '_san_autocomplete_id' + Math.random().toString().substring(2)
        };
    },
    computed: {
        imgAddress: function () {
            return contextPath + '/scm/ajax/image/loading.gif';
        }
    },
    attached: function () {
        var _query = null;
        var _this = this;
        var $input = $("#" + this.data.get('_san_autocomplete_id'));
        $input.typeahead({
            // minLength:2,//����������ʾ����С�����ַ���
            items: 10,//Ĭ�������ʾ��̨���ص�10������
            delay: 500,//�����ӳٱ����δ�����ѯ����
            fitToElement: true,
            source: function (query, process) {
                _query = query;
                _this.data.set('showLoading', true);
                sino.ajax({
                    address: _this.data.get('url'),//�����ַ
                    params: _this.data.get('param') + '=' + query,//�������
                    onSuccess: function (data) {
                        return process(data);
                    },
                    onComplete: function () {
                        _this.data.set('showLoading', false);
                    }
                });
            },
            matcher: function (item) {//�ж��Ƿ񷵻��д�ѡ
                return true;
            },
            displayText: function (item) {//��ʾ��ֵ
                var _display = _this.data.get('display');
                if (typeof _display === 'string') {
                    return item[_display];
                } else if (typeof _display === 'object') {
                    var _result = "";
                    for (var i = 0, il = _display.length; i < il; i++) {
                        _result += ((i > 0 ? '��' : '') + item[_display[i]]);
                    }
                    return _result;
                } else {
                    return JSON.stringify(item)
                }
            },
            highlighter: function (item) {//��ʾ����ʽHTML
                return item;
            },
            updater: function (item) {//�����ֵ
                _this.fire('select', item);
                return item;
            },
            afterSelect: function () {
                if (!_this.data.get('writeBack')) {//�Ƿ��дѡ�������
                    $input.val(_query);
                    $input.html('');
                }
            }
        });
    }
});

/**
 * ��Ӧ���Ļ�������
 * @type {Function}
 */
var SinoBodyLayout = san.defineComponent({
    template:
    '<template>' +
    '<div s-if="north > 0" class="sino-san-layout-north" style="height:{{north}}px;">' +
    '<slot name="north"></slot>' +
    '</div>' +
    '<div class="sino-san-layout-center" style="padding:{{north}}px 0px {{south}}px 0px;">' +
    '<div class="{{fluid ? \'container-fluid\' : \'container\'}}"><slot></slot></div>' +
    '</div>' +
    '<div s-if="south > 0" class="sino-san-layout-south" style="height:{{south}}px;">' +
    '<slot name="south"></slot>' +
    '</div>' +
    '</template>',
    created: function () {
        if (this.data.get('fluid')) {
            this.fire('resize', {clientHeight: document.documentElement.clientHeight});
        }
    },
    attached: function () {
        if (this.data.get('fluid')) {
            var that = this;
            window.onresize = function () {
                that.fire('resize', {clientHeight: document.documentElement.clientHeight});
            }
        }
    },
    initData: function () {
        return {
            // clientHeight: document.documentElement.clientHeight,
            north: 0,
            south: 0
        };
    }
});

/**
 * ��Ӧ��������������(�޷�ʹ��,���ҷ���)
 * @type {Function}
 */
var SinoProcedureHidden_His = san.defineComponent({
    template:
    '<div class="{{hidden ? \'hidden\' : \'\'}}">' +//
    '<div s-for="value,key in fndActForm" class="form-group sino-form-group">' +
    '<label class="col-sm-4 control-label">fndActForm.{{key}}��</label>' +
    '<div class="col-sm-8">' +
    '<input type="text" class="form-control input-sm" id="fndActForm.{{key}}" name="fndActForm.{{key}}" value="{{value}}" readonly/>' +
    '</div>' +
    '</div>' +
    '</div>',
    initData: function () {
        return {
            fndActForm: {},
            hidden: true
        }
    }
});

/**
 * ��Ӧ�������̴�����¼
 * @type {Function|*}
 */
var SinoProcedureArchive = san.defineComponent({
    template:
    '<template>' +
    '<sino-data-table columns="{{lineTable.columns}}" rows="{{lineTable.rows}}" />' +
    '</template>',
    components: {
        'sino-data-table': SinoDataTable
    },
    initData: function () {
        return {
            lineTable: {
                columns: [
                    // {title: '�����ӵ�', name: 'nodeName', width: 168, align: 'center'},
                    {title: '��������', name: 'appDeptName', width: 168, align: 'center'},
                    {title: '������Ա', name: 'appUserName', width: 168, align: 'center'},
                    {title: '�������', name: 'appContent', width: 436, align: 'center'},
                    {title: '��������', name: 'showDate', width: 168, align: 'center'}
                ],
                rows: []
            },
            appPkValue: undefined,
            appTableName: undefined
        }
    },
    attached: function () {
        this._loadArchiveRecord();
        this.watch('appPkValue', function (value) {
            this._loadArchiveRecord();
        });
    },
    _loadArchiveRecord: function () {
        var that = this;
        var appPkValue = this.data.get('appPkValue');
        var appTableName = this.data.get('appTableName');
        if (appPkValue && appTableName) {
            sino.ajax({
                address: contextPath + '/flow/fndAppContentAction.do?act=APP_CONTENT_AJAX',//�����ַ
                params: {appPkValue: appPkValue, appTableName: appTableName},//�������
                handleMask: 3,//����������ʾ�ɰ�
                onSuccess: function (data) {
                    that.data.set('lineTable.rows', data);
                }
            });
        }
    }
});

/**
 * ��Ӧ��������������
 * @type {Function}
 */
var SinoProcedureHidden = san.defineComponent({
    template:
    '<div class="{{hidden ? \'hidden\' : \'\'}}">' +
    '<input type="text" readonly name="fndActForm.actId" value="{{fndActForm.actId}}" id="fndActForm.actId"/>' +
    '<input type="text" readonly name="fndActForm.instanceId" value="{{fndActForm.instanceId}}" id="fndActForm.instanceId"/>' +
    '<input type="text" readonly name="fndActForm.processId" value="{{fndActForm.processId}}" id="fndActForm.processId"/>' +
    '<input type="text" readonly name="fndActForm.title" value="{{fndActForm.title}}" id="fndActForm.title"/>' +
    '<input type="text" readonly name="fndActForm.applicationTableName" value="{{fndActForm.applicationTableName}}" id="fndActForm.applicationTableName"/>' +
    '<input type="text" readonly name="fndActForm.applicationPkValue" value="{{fndActForm.applicationPkValue}}" id="fndActForm.applicationPkValue"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn1" value="{{fndActForm.actApplColumn1}}" id="fndActForm.actApplColumn1"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn2" value="{{fndActForm.actApplColumn2}}" id="fndActForm.actApplColumn2"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn3" value="{{fndActForm.actApplColumn3}}" id="fndActForm.actApplColumn3"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn4" value="{{fndActForm.actApplColumn4}}" id="fndActForm.actApplColumn4"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn5" value="{{fndActForm.actApplColumn5}}" id="fndActForm.actApplColumn5"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn6" value="{{fndActForm.actApplColumn6}}" id="fndActForm.actApplColumn6"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn7" value="{{fndActForm.actApplColumn7}}" id="fndActForm.actApplColumn7"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn8" value="{{fndActForm.actApplColumn8}}" id="fndActForm.actApplColumn8"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn9" value="{{fndActForm.actApplColumn9}}" id="fndActForm.actApplColumn9"/>' +
    '<input type="text" readonly name="fndActForm.actApplColumn10" value="{{fndActForm.actApplColumn10}}" id="fndActForm.actApplColumn10"/>' +
    '<input type="text" readonly name="fndActForm.actApplName" value="{{fndActForm.actApplName}}" id="fndActForm.actApplName"/>' +
    '<input type="text" readonly name="fndActForm.actorId" value="{{fndActForm.actorId}}" id="fndActForm.actorId"/>' +
    '<input type="text" readonly name="fndActForm.actorIds" value="{{fndActForm.actorIds}}" id="fndActForm.actorIds"/>' +
    '<input type="text" readonly name="fndActForm.actorName" value="{{fndActForm.actorName}}" id="fndActForm.actorName"/>' +
    '<input type="text" readonly name="fndActForm.actorNames" value="{{fndActForm.actorNames}}" id="fndActForm.actorNames"/>' +
    '<input type="text" readonly name="fndActForm.linkUrl" value="{{fndActForm.linkUrl}}" id="fndActForm.linkUrl"/>' +
    '<input type="text" readonly name="fndActForm.actApplStartDate" value="{{fndActForm.actApplStartDate}}" id="fndActForm.actApplStartDate"/>' +
    '<input type="text" readonly name="fndActForm.actApplCompletedDate" value="{{fndActForm.actApplCompletedDate}}" id="fndActForm.actApplCompletedDate"/>' +
    '<input type="text" readonly name="fndActForm.requestType" value="{{fndActForm.requestType}}" id="fndActForm.requestType"/>' +
    '<input type="text" readonly name="fndActForm.actReqName" value="{{fndActForm.actReqName}}" id="fndActForm.actReqName"/>' +
    '<input type="text" readonly name="fndActForm.status" value="{{fndActForm.status}}" id="fndActForm.status"/>' +
    '<input type="text" readonly name="fndActForm.fromBy" value="{{fndActForm.fromBy}}" id="fndActForm.fromBy"/>' +
    '<input type="text" readonly name="fndActForm.addPrikeyValue" value="{{fndActForm.addPrikeyValue}}" id="fndActForm.addPrikeyValue"/>' +
    '<input type="text" readonly name="fndActForm.valueKey" value="{{fndActForm.valueKey}}" id="fndActForm.valueKey"/>' +
    '<input type="text" readonly name="fndActForm.flowToEnd" value="{{fndActForm.flowToEnd}}" id="fndActForm.flowToEnd"/>' +
    '<input type="text" readonly name="fndActForm.opinion" value="{{fndActForm.opinion}}" id="fndActForm.opinion"/>' +
    '<input type="text" readonly name="fndActForm.commonOpinion" value="{{fndActForm.commonOpinion}}" id="fndActForm.commonOpinion"/>' +
    '<input type="text" readonly name="fndActForm.procedureCode" value="{{fndActForm.procedureCode}}" id="fndActForm.procedureCode"/>' +
    '<input type="text" readonly name="fndActForm.processName" value="{{fndActForm.processName}}" id="fndActForm.processName"/>' +
    '<input type="text" readonly name="fndActForm.viewUrl" value="{{fndActForm.viewUrl}}" id="fndActForm.viewUrl"/>' +
    '<input type="text" readonly name="fndActForm.firstTask" value="{{fndActForm.firstTask}}" id="fndActForm.firstTask"/>' +
    '<input type="text" readonly name="fndActForm.actType" value="{{fndActForm.actType}}" id="fndActForm.actType"/>' +
    '<input type="text" readonly name="fndActForm.nodeName" value="{{fndActForm.nodeName}}" id="fndActForm.nodeName"/>' +
    '<input type="text" readonly name="fndActForm.composeUser" value="{{fndActForm.composeUser}}" id="fndActForm.composeUser"/>' +
    '<input type="text" readonly name="fndActForm.composeUserName" value="{{fndActForm.composeUserName}}" id="fndActForm.composeUserName"/>' +
    '<input type="text" readonly name="fndActForm.composeDept" value="{{fndActForm.composeDept}}" id="fndActForm.composeDept"/>' +
    '<input type="text" readonly name="fndActForm.composeDate" value="{{fndActForm.composeDate}}" id="fndActForm.composeDate"/>' +
    '<input type="text" readonly name="fndActForm.nextMutex" value="{{fndActForm.nextMutex}}" id="fndActForm.nextMutex"/>' +
    '<input type="text" readonly name="fndActForm.definedProperties" value="{{fndActForm.definedProperties}}" id="fndActForm.definedProperties"/>' +
    '<input type="text" readonly name="fndActForm.eipProcedureCode" value="{{fndActForm.eipProcedureCode}}" id="fndActForm.eipProcedureCode"/>' +
    '<input type="text" readonly name="fndActForm.handleType" value="{{fndActForm.handleType}}" id="fndActForm.handleType"/>' +
    '<input type="text" readonly name="fndActForm.pendingType" value="{{fndActForm.pendingType}}" id="fndActForm.pendingType"/>' +
    '<input type="text" readonly name="fndActForm.sendMessage" value="{{fndActForm.sendMessage}}" id="fndActForm.sendMessage"/>' +
    '<input type="text" readonly name="fndActForm.ipAddr" value="{{fndActForm.ipAddr}}" id="fndActForm.ipAddr"/>' +
    '</div>',
    initData: function () {
        return {
            fndActForm: {},
            hidden: true
        }
    }
});

/**
 * �ϴ��ļ�ͨ�����
 * @type {Function|*}
 */
var SinoUploadFile = san.defineComponent({
    template:
    '<template>' +
    '<form name="appendixForm" action="{{uploadFileAddress}}" encType="multipart/form-data" method="post" ' +
    '   target="{{_sino_san_upload_target}}">' +
    '<table><tr><td>ѡ���ļ�:</td><td style="padding:0px 10px;"><input type="file" name="file" on-change="_doSelectedUploadFile" s-ref="sino-upload-file-input" /></td>' +
    '<td><sino-button title="{{btnTitle}}" icon="{{btnIcon}}" disabled="{{!selectedFlag}}" category="submit" /></td></tr></table>' +
    '<div class="hidden">' +
    '<input type="text" name="appendixRef" value="000" />' +
    '<input type="text" name="appendixModule" value="" />' +
    '<input type="text" name="appendixType" value="" />' +
    '</div></form>' +
    '<table class="table table-hover" style="margin-top:10px;margin-bottom:0px;"><tbody>' +
    '<template s-for="item,index in uploadFiles">' +
    '<tr><td style="width:20px;text-align:center;"><i class="fa fa-paperclip"></i></td>' +
    '<td>{{item.fileName}}</td>' +
    '<td style="width:20px;text-align:center;">' +
    '<a on-click="_doRemoveUploadedFile(index)" class="fa fa-close text-danger" href="javascript:void(0);"></a></td></tr>' +
    '</template>' +
    '</tbody></table>' +
    '<div class="hidden"><iframe name="{{_sino_san_upload_target}}" on-load="_doLoadIframeEvent"/></div>' +
    '</template>',
    components: {
        'sino-button': SinoButton
    },
    initData: function () {
        return {
            uploadFiles: [],//����󶨵��ϴ��ļ�����(SELECT * FROM FND_APPENDIX WHERE APPENDIX_REF = '000')
            btnTitle: '�ϴ��ļ�',
            btnIcon: 'fa-upload',
            selectedFlag: false,
            _sino_san_upload_target: '_sino_san_upload_target_' + Math.random().toString().substring(2)
        }
    },
    computed: {
        uploadFileAddress: function () {
            return contextPath + '/fnd/appendixAction.do?act=MULTIPLE_UPLOAD';
        },
        deleteFileAddress: function () {
            return contextPath + '/fnd/appendixAction.do?act=DELETE';
        }
    },
    _doSelectedUploadFile: function () {
        var _this = this;
        _this.nextTick(function () {
            if ($(_this.ref('sino-upload-file-input')).val()) {
                _this.data.set('selectedFlag', true);
            } else {
                _this.data.set('selectedFlag', false);
            }
        });
    },
    _doRemoveUploadedFile: function (index) {
        var _this = this;
        sino.ajax({
            address: _this.data.get('deleteFileAddress'),//�����ַ
            params: "appendixIdStr=" + _this.data.get('uploadFiles')[index].appendixId,//�������
            onSuccess: function (data) {
                if (data.succeed) {
                    _this.data.removeAt('uploadFiles', index);
                } else {
                    alert("ɾ���ļ�ʧ��:" + data.message);
                }
            },
            onComplete: function () {
                // _this.data.set('showLoading', false);
            }
        });
    },
    _doLoadIframeEvent: function () {
        var _iframeContent = $('iframe[name="' + this.data.get('_sino_san_upload_target') + '"]').contents().find('body').html();
        if (_iframeContent) {
            var _iframeContentJson = $.parseJSON(_iframeContent)
            if (_iframeContentJson.succeed) {
                this.data.push('uploadFiles', {
                    fileName: _iframeContentJson.fileName,
                    appendixId: _iframeContentJson.appendixId
                });
            } else {
                alert("�ϴ��ļ�ʧ��:" + _iframeContentJson.message);
            }
        }
        this.data.set('selectedFlag', false);
        $(this.ref('sino-upload-file-input')).val('');
    }
});

var SinoCommonComponents = {
    'sino-nav-header': SinoNavHeader,
    'sino-bar-header': SinoBarHeader,
    'sino-button': SinoButton,
    'sino-data-table': SinoDataTable,
    'sino-pagination': SinoPagination,
    'sino-modal-dialog': SinoModalDialog,
    'sino-body-layout': SinoBodyLayout,
    'sino-input': SinoInput,
    'sino-form-input': SinoFormInput,
    'sino-textarea': SinoTextArea,
    'sino-form-textarea': SinoFormTextArea,
    'sino-select': SinoSelect,
    'sino-form-select': SinoFormSelect,
    'sino-lookup': SinoLookup,
    'sino-form-lookup': SinoFormLookup,
    'sino-form-radio': SinoFormRadio,
    'sino-form-checkbox': SinoFormCheckbox,
    'sino-form-datepicker': SinoFormDatePicker,
    'sino-form-daterangepicker': SinoFormDateRangePicker,
    'sino-form-autocomplete': SinoFormAutocomplete,
    'sino-upload-file': SinoUploadFile,
    'sino-procedure-hidden': SinoProcedureHidden,
    'sino-procedure-archive': SinoProcedureArchive
};