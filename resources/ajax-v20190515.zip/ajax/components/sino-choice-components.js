/**
 * ѡ������Աģ̬����
 * @type {Function|*}
 */
var SinoChoiceUserDialog = san.defineComponent({
    template:
    '<template>' +
    '<sino-modal-dialog title="{{title}}" show="{= show =}">' +
    '<div class="alert alert-danger" role="alert" style="margin-bottom:10px;" s-if="alertDanger">' +
    '<a class="fa fa-close" href="javascript:void(0);" on-click="_clearAlertDanger"></a> {{alertDanger}}' +
    '</div>' +
    '<div class="container-fluid"><div class="row">' +
    '<div class="sino-form" style="margin-bottom: 10px;">' +
    '<div class="form-horizontal"><div class="col-xs-12 col-sm-12 col-md-12">' +
    '<sino-form-textarea title="�������" value="{= callbackData.handleOpinion =}" rows="2" number="300"/>' +
    '</div></div></div>' +
    '<div class="col-sm-5" style="height:290px;border:1px solid #DDD;overflow: auto;">' +
    '<ul id="{{_san_choice_dialog_id}}" class="ztree"></ul>' +
    '</div>' +
    '<div class="col-sm-1 text-center">' +
    '<div style="margin-top:70px;"><a class="label label-info" on-click="_clickSelectedBtn(\'MP\')"><span class="fa fa-chevron-right" aria-hidden="true"></span></a></div>' +
    '<div style="margin-top:130px;"><a class="label label-info" on-click="_clickSelectedBtn(\'CP\')"><span class="fa fa-chevron-right" aria-hidden="true"></span></a></div>' +
    '</div>' +
    '<div class="col-sm-6">' +
    '<div style="height:140px;border:1px solid #DDD;">' +
    '<div class="sino-form mini-form"><div class="form-horizontal">' +
    '<sino-form-autocomplete title="������" url="{{autocompleteAddress}}" display="{{[\'userName\',\'abbrGroupName\']}}" on-select="_selectAutocompleteMP" writeBack="{{false}}" cell="{{[3,9]}}"/>' +
    '</div></div>' +
    '<div style="height:100px;overflow:auto;"><ul class="list-group">' +
    '<li class="list-group-item" s-for="item,index in callbackData.selectedMP">' +
    '<a class="badge" on-click="_clickRemoveBtn(\'MP\',index)">ɾ��</a>{{index+1}}. {{item.userName}}</li></ul></div>' +
    '</div>' +
    '<div style="height:140px;border:1px solid #DDD;overflow: auto;margin-top:10px;">' +
    '<div class="sino-form mini-form"><div class="form-horizontal">' +
    '<sino-form-autocomplete title="������" url="{{autocompleteAddress}}" display="{{[\'userName\',\'abbrGroupName\']}}" on-select="_selectAutocompleteCP" writeBack="{{false}}" cell="{{[3,9]}}"/>' +
    '</div></div>' +
    '<div style="height:100px;overflow:auto;"><ul class="list-group">' +
    '<li class="list-group-item" s-for="item,index in callbackData.selectedCP">' +
    '<a class="badge" on-click="_clickRemoveBtn(\'CP\',index)">ɾ��</a>{{index+1}}. {{item.userName}}</li></ul></div>' +
    '</div>' +
    '</div>' +
    '</div></div>' +
    '<sino-button slot="buttons" icon="fa-send" title="ȷ��" on-click="_clickConfirmBtn"/>' +
    '</sino-modal-dialog>' +
    '</template>',
    components: {
        'sino-modal-dialog': SinoModalDialog,
        'sino-form-textarea': SinoFormTextArea,
        'sino-form-autocomplete': SinoFormAutocomplete,
        'sino-button': SinoButton
    },
    initData: function () {
        return {
            title: 'ѡ������Ա',
            show: false,//�Ƿ�򿪴���
            alertDanger: '',//Ԥ����ʾ��Ϣ
            rootGroupId: 0,//��ʼĬ�ϵĸ��ڵ�0����ȫʡ
            _san_choice_dialog_id: '_san_choice_dialog_id' + Math.random().toString().substring(2),
            callbackData: {
                handleOpinion: '',//�������
                selectedMP: [],//ѡ���������
                selectedCP: []//ѡ��ĳ�����
            }
        };
    },
    computed: {
        autocompleteAddress: function () {
            return contextPath + '/bat/choiceUser.do?act=AJAX_QUERY_USER&rootGroupId=' + this.data.get('rootGroupId');
        }
    },
    attached: function () {
        var setting = {
            async: {
                enable: true,
                url: contextPath + '/bat/choiceUser.do?act=AJAX_QUERY_TREE&rootGroupId=' + this.data.get('rootGroupId'),
                autoParam: ["groupId", "userId"],
                dataFilter: function (treeId, parentNode, childNodes) {
                    if (!childNodes) return null;
                    for (var i = 0, il = childNodes.length; i < il; i++) {
                        // childNodes[i].name = childNodes[i].groupName.replace(/\.n/g, '.');
                        childNodes[i].name = childNodes[i].formType === 'GROUP' ? childNodes[i].groupName : childNodes[i].userName;
                        childNodes[i].isParent = childNodes[i].formType === 'GROUP';
                    }
                    return childNodes;
                }
            },
            callback: {
                onClick: function (event, treeId, treeNode) {
                    if (treeNode.isParent) {
                        var treeObj = $.fn.zTree.getZTreeObj(treeId);
                        treeObj.cancelSelectedNode(treeNode);
                    }
                }/*,
                onDblClick: function (event, treeId, treeNode) {
                    if (!treeNode.isParent) {}
                }*/
            }
        };
        $.fn.zTree.init($('#' + this.data.get('_san_choice_dialog_id')), setting);
    },
    _selectAutocompleteMP: function (data) {
        this._clickAppendBtn('MP', [data]);
    },
    _selectAutocompleteCP: function (data) {
        this._clickAppendBtn('CP', [data]);
    },
    _clickSelectedBtn: function (type) {//type:MP,CP
        var treeObj = $.fn.zTree.getZTreeObj(this.data.get('_san_choice_dialog_id'));
        var nodes = treeObj.getSelectedNodes();
        this._clickAppendBtn(type, nodes);
        treeObj.cancelSelectedNode();
    },
    _clickAppendBtn: function (type, nodes) {//type:MP,CP
        var _extisUser = "";
        for (var i = 0, il = nodes.length; i < il; i++) {
            if (!nodes[i].isParent) {
                var _extisFlag = false;//�ж�����Ѿ�����ʱ���ټ����ظ�����
                /*var selecteds = this.data.get('callbackData.selected' + type);*/
                var selecteds = [];
                selecteds = selecteds.concat(this.data.get('callbackData.selectedMP'));
                selecteds = selecteds.concat(this.data.get('callbackData.selectedCP'));
                for (var n = 0, nl = selecteds.length; n < nl; n++) {
                    if (nodes[i].userId === selecteds[n].userId) {
                        _extisFlag = true;
                        _extisUser += ' ' + nodes[i].userName + ' ';
                    }
                }
                if (!_extisFlag) {
                    this.data.push('callbackData.selected' + type, {
                        userId: nodes[i].userId,
                        userName: nodes[i].userName
                    });
                }
            }
        }
        if (_extisUser) {
            this.data.set('alertDanger', '�����ظ�ѡ����Ϊ������(' + _extisUser + ')����֪��.');
        } else {
            this.data.set('alertDanger', '');
        }
    },
    _clickRemoveBtn: function (type, index) {//type:MP,CP
        this.data.removeAt('callbackData.selected' + type, index);
    },
    _clickConfirmBtn: function () {
        this.fire('confirm', this.data.get('callbackData'))
    },
    _clearAlertDanger: function () {
        this.data.set('alertDanger', '');
    }
});

if (typeof  SinoCommonComponents === 'undefined') {
    alert('please import sino-common-components.js');
} else {
    SinoCommonComponents['sino-choice-user-dialog'] = SinoChoiceUserDialog;
}