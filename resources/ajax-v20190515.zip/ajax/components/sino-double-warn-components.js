var _sinoChoiceUser = san.defineComponent({
    template:
    '<div class="container-fluid"><div class="row">' +
    '<div class="col-sm-5" style="height:290px;border:1px solid #DDD;overflow: auto;">' +
    '<ul id="{{_san_choice_dialog_id}}" class="ztree"></ul>' +
    '</div>' +
    '<div class="col-sm-1 text-center">' +
    '<div style="margin-top:70px;"><a class="label label-primary" on-click="_clickSelectedBtn(\'MP\')"><span class="fa fa-chevron-right" aria-hidden="true"></span></a></div>' +
    '<div style="margin-top:130px;"><a class="label label-primary" on-click="_clickSelectedBtn(\'CP\')"><span class="fa fa-chevron-right" aria-hidden="true"></span></a></div>' +
    '</div>' +
    '<div class="col-sm-6">' +
    '<div style="height:140px;border:1px solid #DDD;">' +
    '<div class="sino-form mini-form"><div class="form-horizontal">' +
    '<sino-form-autocomplete title="������" url="{{autocompleteAddress}}" display="{{[\'userName\',\'abbrGroupName\']}}" on-select="_selectAutocompleteMP" writeBack="{{false}}" cell="{{[3,9]}}"/>' +
    '</div></div>' +
    '<div style="height:100px;overflow:auto;"><ul class="list-group">' +
    '<li class="list-group-item" s-for="item,index in callbackData.selectedMP">' +
    '<a class="badge" on-click="_clickRemoveBtn(\'MP\',index)">ɾ��</a>{{index+1}}. {{item.userName}}</li></ul></div>' +
    '</div>' +
    '<div style="height:140px;border:1px solid #DDD;overflow: auto;margin-top:10px;">' +
    '<div class="sino-form mini-form"><div class="form-horizontal">' +
    '<sino-form-autocomplete title="������" url="{{autocompleteAddress}}" display="{{[\'userName\',\'abbrGroupName\']}}" on-select="_selectAutocompleteCP" writeBack="{{false}}" cell="{{[3,9]}}"/>' +
    '</div></div>' +
    '<div style="height:100px;overflow:auto;"><ul class="list-group">' +
    '<li class="list-group-item" s-for="item,index in callbackData.selectedCP">' +
    '<a class="badge" on-click="_clickRemoveBtn(\'CP\',index)">ɾ��</a>{{index+1}}. {{item.userName}}</li></ul></div>' +
    '</div>' +
    '</div>' +
    '</div></div>',
    components: SinoCommonComponents,
    initData: function () {
        return {
            rootGroupId: 0,//��ʼĬ�ϵĸ��ڵ�0����ȫʡ
            _san_choice_dialog_id: '_san_choice_dialog_id' + Math.random().toString().substring(2),
            callbackData: {
                selectedMP: [],//ѡ���������
                selectedCP: []//ѡ��ĳ�����
            }
        };
    },
    computed: {
        autocompleteAddress: function () {
            return contextPath + '/bat/choiceUser.do?act=AJAX_QUERY_USER&rootGroupId=' + this.data.get('rootGroupId');
        }
    },
    attached: function () {
        var setting = {
            async: {
                enable: true,
                url: contextPath + '/bat/choiceUser.do?act=AJAX_QUERY_TREE&rootGroupId=' + this.data.get('rootGroupId'),
                autoParam: ["groupId", "userId"],
                dataFilter: function (treeId, parentNode, childNodes) {
                    if (!childNodes) return null;
                    for (var i = 0, il = childNodes.length; i < il; i++) {
                        // childNodes[i].name = childNodes[i].groupName.replace(/\.n/g, '.');
                        childNodes[i].name = childNodes[i].formType === 'GROUP' ? childNodes[i].groupName : childNodes[i].userName;
                        childNodes[i].isParent = childNodes[i].formType === 'GROUP';
                    }
                    return childNodes;
                }
            },
            callback: {
                onClick: function (event, treeId, treeNode) {
                    if (treeNode.isParent) {
                        var treeObj = $.fn.zTree.getZTreeObj(treeId);
                        treeObj.cancelSelectedNode(treeNode);
                    }
                }
            }
        };
        $.fn.zTree.init($('#' + this.data.get('_san_choice_dialog_id')), setting);
    },
    _selectAutocompleteMP: function (data) {
        this._clickAppendBtn('MP', [data]);
    },
    _selectAutocompleteCP: function (data) {
        this._clickAppendBtn('CP', [data]);
    },
    _clickSelectedBtn: function (type) {//type:MP,CP
        var treeObj = $.fn.zTree.getZTreeObj(this.data.get('_san_choice_dialog_id'));
        var nodes = treeObj.getSelectedNodes();
        this._clickAppendBtn(type, nodes);
        treeObj.cancelSelectedNode();
    },
    _clickAppendBtn: function (type, nodes) {//type:MP,CP
        var _extisUser = "";
        for (var i = 0, il = nodes.length; i < il; i++) {
            if (!nodes[i].isParent) {
                var _extisFlag = false;//�ж�����Ѿ�����ʱ���ټ����ظ�����
                /*var selecteds = this.data.get('callbackData.selected' + type);*/
                var selecteds = [];
                selecteds = selecteds.concat(this.data.get('callbackData.selectedMP'));
                selecteds = selecteds.concat(this.data.get('callbackData.selectedCP'));
                for (var n = 0, nl = selecteds.length; n < nl; n++) {
                    if (nodes[i].userId === selecteds[n].userId) {
                        _extisFlag = true;
                        _extisUser += ' ' + nodes[i].userName + ' ';
                    }
                }
                if (!_extisFlag) {
                    this.data.push('callbackData.selected' + type, {
                        userId: nodes[i].userId,
                        userName: nodes[i].userName
                    });
                }
            }
        }
        if (_extisUser) {
            alert('�����ظ�ѡ����Ϊ������(' + _extisUser + ')����֪��.');
        }
    },
    _clickRemoveBtn: function (type, index) {//type:MP,CP
        this.data.removeAt('callbackData.selected' + type, index);
    }
});

SinoCommonComponents['sino-choice-user'] = _sinoChoiceUser;

var _sinoDoubleWarnDialog = san.defineComponent({
    template:
    '<template><sino-modal-dialog title="Ԥ������" show="{= dialogShow =}" cancelBtnFlag="{{false}}">' +
    '<table class="table table-bordered" style="margin-bottom:0px;"><tbody>' +
    '<tr><td style="width:120px;padding-top:{{defaultParams.handleOpinion.rows*10}}px;" class="text-center bg-info">�������</td>' +
    '<td><sino-textarea value="{= defaultParams.handleOpinion.value =}" rows="{{defaultParams.handleOpinion.rows}}" number="{{defaultParams.handleOpinion.number}}"/></td></tr>' +
    '<tr class="{{!handleChoiceUser ? \'\' : \'hidden\'}}"><td style="width:120px;" class="text-center bg-info">{{defaultParams.handleSelect.title}}</td>' +
    '<td><table style="width:100%;"><tbody><tr>' +
    '<td width="50%"><sino-select options="{{defaultParams.handleSelect.select}}" value="{= defaultParams.handleSelect.value =}" /></td>' +
    '<td s-if="handleSelectOne.type" nowrap="nowrap" style="padding:0px 10px;" class="text-right">{{handleSelectOne.extendData.title}}</td>' +
    '<td s-if="handleSelectOne.type === \'text\'" width="45%"><sino-input value="{= handleSelectOne.extendData.value =}"/></td>' +
    '<td s-elif="handleSelectOne.type === \'lookup\'" width="45%">' +
    '<sino-lookup code="{{handleSelectOne.extendData.code}}" ' +
    '   data="{{handleSelectOne.extendData.data}}" ' +
    '   message="{{handleSelectOne.extendData.message}}"' +
    '   on-select="_lookupSelectedEvent"/></td>' +
    '</tr></tbody></table>' +
    '</td></tr><tr class="{{!handleChoiceUser ? \'\' : \'hidden\'}}"><td style="width:120px;height:150px;" class="text-center bg-info">����</td>' +
    '   <td><sino-upload-file uploadFiles="{= uploadFiles =}" /></td></tr>' +
    '</tbody></table>' +
    '<div class="{{handleChoiceUser ? \'\' : \'hidden\'}}"><sino-choice-user rootGroupId="{{defaultParams.rootGroupId}}" callbackData="{= choiceUserData =}" /></div>' +
    '<template slot="buttons">' +
    '<sino-button on-click="_clickHandleReplyBtn" title="�ظ�" type="btn-default" s-if="!handleChoiceUser" />' +
    '<sino-button on-click="_clickChoiceUserBtn" title="ת��" type="btn-default" />' +
    '<sino-button on-click="_clickPlaceFileBtn" title="�鵵" type="btn-default" s-if="!handleChoiceUser" />' +
    '<sino-button on-click="_clickDialogCancelBtn" title="ȡ��" type="btn-default" />' +
    '</template>' +
    '</sino-modal-dialog></template>',
    components: SinoCommonComponents,
    initData: function () {
        return {
            defaultParams: {
                /*rootGroupId: 0,//ѡ���ŵĳ�ʼ�ڵ�
                handleOpinion: {
                    value: '',//Ĭ����ʾ�Ĵ������
                    rows: 5,//�ı�����ʾ���и�
                    number: 400//�������������ַ���
                },
                handleSelect: {
                    title: 'Ԥ��������Ϣ',
                    select: [
                        // {value: '11', text: '����������', type: 'select', extendData: {title: 'ѡ���', select: [], value: ''}},//extendData ������չ�ؼ�����
                        {value: '12', text: '���Ժ�����һ���ı�������', type: 'text', extendData: {title: '������ͬ', value: ''}},//extendData ������չ�ؼ�����
                        {
                            value: '13',
                            text: '���Ժ�����һ��LOOKUP�����',
                            type: 'lookup',
                            extendData: {
                                title: 'ѡ�����',
                                code: 'GET_ORGANIZATION_BY_HD',
                                data: {OA_ORG_BEGIN: 0, OA_ORG_END: 100},
                                optionText: 'organizationName'
                            }
                        },//extendData ������չ�ؼ�����
                        {value: '14', text: '���Ժ���û���κοؼ������'}//, type: ''
                    ],
                    value: '13',//Ĭ��ѡ���������ѡ��
                }*/
            },
            dialogShow: false,
            handleChoiceUser: false,
            handleSelectOne: {},//��ǰ����ѡ���ֵ
            choiceUserData: {
                selectedMP: [],//ѡ���������
                selectedCP: []//ѡ��ĳ�����
            },
            uploadFiles: []//�ϴ��ĸ�����Ϣ
        };
    },
    attached: function () {
        var _this = this;
        _this.watch('defaultParams.handleSelect.value', function (value) {
            this._watchHandleSelectEvent();
        });
        this._watchHandleSelectEvent();
    },
    computed: {
        deleteFileAddress: function () {
            return contextPath + '/fnd/appendixAction.do?act=DELETE';
        }
    },
    _watchHandleSelectEvent: function () {
        var _resultOption = {};
        var _handleSelectOptions = this.data.get('defaultParams.handleSelect.select');
        var _handleSelectValue = this.data.get('defaultParams.handleSelect.value');
        for (var i = 0; i < _handleSelectOptions.length; i++) {
            if (_handleSelectOptions[i].value === _handleSelectValue) {
                _resultOption = _handleSelectOptions[i];
                break;
            }
        }
        this.data.set('handleSelectOne', _resultOption);
    },
    _lookupSelectedEvent: function (data) {
        this.data.set('handleSelectOne.extendData.value', data);
        this.data.set('handleSelectOne.extendData.message', data[this.data.get('handleSelectOne.extendData.optionText')]);
    },
    _clickDialogCancelBtn: function () {//ȡ��
        if (this.data.get('handleChoiceUser')) {
            this.data.set('handleChoiceUser', false);
            this.data.set('defaultParams.handleOpinion.rows', 5);
        } else {
            this.data.set('dialogShow', false);
            // alert('�رմ��ڵ�ʱ��ǵ�������ѡ���ļ�');
            var _params = "";
            var _uploadFiles = this.data.get('uploadFiles');
            for (var i = 0; i < _uploadFiles.length; i++) {
                _params += ((i > 0 ? ',' : '') + _uploadFiles[i].appendixId);
            }
            alert(_params);
            var _this = this;
            sino.ajax({
                address: _this.data.get('deleteFileAddress'),//�����ַ
                params: "appendixIdStr=" + _params,//�������
                onSuccess: function (data) {
                    if (data.succeed) {
                        _this.data.set('uploadFiles', []);
                    } else {
                        alert("�����ļ�ʧ��:" + data.message);
                    }
                },
                onComplete: function () {
                    // _this.data.set('showLoading', false);
                }
            });
        }
    },
    _clickChoiceUserBtn: function () {//ת��
        if (this.data.get('handleChoiceUser')) {
            this._handleCallbackDialog('ת��');
        } else {
            this.data.set('handleChoiceUser', true);
            this.data.set('defaultParams.handleOpinion.rows', 2);
        }
    },
    _clickHandleReplyBtn: function () {//�ظ�
        this._handleCallbackDialog('�ظ�');
    },
    _clickPlaceFileBtn: function () {//�鵵
        this._handleCallbackDialog('�鵵');
    },
    _handleCallbackDialog: function (_handleType) {
        this.fire('handle', {
            handleType: _handleType,
            handleOpinion: this.data.get('defaultParams.handleOpinion.value'),
            selectedValue: this.data.get('handleSelectOne.value'),
            extendValue: this.data.get('handleSelectOne.extendData.value'),
            choiceUser: this.data.get('choiceUserData'),
            uploadFiles: this.data.get('uploadFiles')
        });
    }
});

var SinoDoubleWarnDialogComponents = {'sino-double-warn-dialog': _sinoDoubleWarnDialog};