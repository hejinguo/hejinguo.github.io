/**
 * Copyright (c) Baidu Inc. All rights reserved.
 *
 * This source code is licensed under the MIT license.
 * See LICENSE file in the project root for license information.
 *
 * @file San ���ļ�
 */

(function (root) {
    // �˹������������˳��ͨ��ע���ֹ�дһЩ����
//     // require('./util/guid');
//     // require('./util/empty');
//     // require('./util/extend');
//     // require('./util/inherits');
//     // require('./util/each');
//     // require('./util/contains');
//     // require('./util/bind');
//     // require('./browser/on');
//     // require('./browser/un');
//     // require('./browser/svg-tags');
//     // require('./browser/create-el');
//     // require('./browser/remove-el');
//     // require('./util/next-tick');
//     // require('./browser/ie');
//     // require('./browser/ie-old-than-9');
//     // require('./browser/input-event-compatible');
//     // require('./browser/auto-close-tags');
//     // require('./util/data-types.js');
//     // require('./util/create-data-types-checker.js');
//     // require('./parser/walker');
//     // require('./parser/create-a-node');
//     // require('./parser/parse-template');
//     // require('./runtime/change-expr-compare');
//     // require('./runtime/data-change-type');
//     // require('./runtime/default-filters');
//     // require('./view/life-cycle');
//     // require('./view/node-type');
//     // require('./view/get-prop-handler');
//     // require('./view/is-data-change-by-element');
//     // require('./view/event-declaration-listener');
//     // require('./view/create-node');


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Ψһid
     */


    /**
     * Ψһid����ʼֵ
     *
     * @inner
     * @type {number}
     */
    var guidIndex = 1;

    /**
     * Ψһid��ǰ׺
     *
     * @inner
     * @type {string}
     */
    var guidPrefix = (new Date()).getTime().toString(16).slice(8);

    /**
     * ��ȡΨһid
     *
     * @inner
     * @return {string} Ψһid
     */
    function guid() {
        return '_' + guidPrefix + (guidIndex++);
    }

// exports = module.exports = guid;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �պ���
     */


    /**
     * ɶ������
     */
    function empty() {}

// exports = module.exports = empty;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���Կ���
     */

    /**
     * �������Կ���
     *
     * @param {Object} target Ŀ�����
     * @param {Object} source Դ����
     * @return {Object} ����Ŀ�����
     */
    function extend(target, source) {
        for (var key in source) {
            if (source.hasOwnProperty(key)) {
                var value = source[key];
                if (typeof value !== 'undefined') {
                    target[key] = value;
                }
            }
        }

        return target;
    }

// exports = module.exports = extend;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ������֮��ļ̳й�ϵ
     */

// var extend = require('./extend');

    /**
     * ������֮��ļ̳й�ϵ
     *
     * @param {Function} subClass ���ຯ��
     * @param {Function} superClass ���ຯ��
     */
    function inherits(subClass, superClass) {
        /* jshint -W054 */
        var subClassProto = subClass.prototype;
        var F = new Function();
        F.prototype = superClass.prototype;
        subClass.prototype = new F();
        subClass.prototype.constructor = subClass;
        extend(subClass.prototype, subClassProto);
        /* jshint +W054 */
    }

// exports = module.exports = inherits;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��������
     */


    /**
     * �������鼯��
     *
     * @param {Array} array ����Դ
     * @param {function(Any,number):boolean} iterator ��������
     */
    function each(array, iterator) {
        if (array && array.length > 0) {
            for (var i = 0, l = array.length; i < l; i++) {
                if (iterator(array[i], i) === false) {
                    break;
                }
            }
        }
    }

// exports = module.exports = each;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ж��������Ƿ����ĳ��
     */

// var each = require('./each');

    /**
     * �ж��������Ƿ����ĳ��
     *
     * @param {Array} array ����
     * @param {*} value ��������
     * @return {boolean}
     */
    function contains(array, value) {
        var result = false;
        each(array, function (item) {
            result = item === value;
            return !result;
        });

        return result;
    }

// exports = module.exports = contains;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file bind����
     */

    /**
     * Function.prototype.bind �����ļ����Է�װ
     *
     * @param {Function} func Ҫbind�ĺ���
     * @param {Object} thisArg thisָ�����
     * @param {...*} args Ԥ��ĳ�ʼ����
     * @return {Function}
     */
    function bind(func, thisArg) {
        var nativeBind = Function.prototype.bind;
        var slice = Array.prototype.slice;
        // #[begin] allua
        if (nativeBind && func.bind === nativeBind) {
            // #[end]
            return nativeBind.apply(func, slice.call(arguments, 1));
            // #[begin] allua
        }

        var args = slice.call(arguments, 2);
        return function () {
            return func.apply(thisArg, args.concat(slice.call(arguments)));
        };
        // #[end]
    }

// exports = module.exports = bind;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file DOM �¼�����
     */

    /**
     * DOM �¼�����
     *
     * @inner
     * @param {HTMLElement} el DOMԪ��
     * @param {string} eventName �¼���
     * @param {Function} listener ��������
     * @param {boolean} capture �Ƿ��ǲ���׶�
     */
    function on(el, eventName, listener, capture) {
        // #[begin] allua
        if (el.addEventListener) {
            // #[end]
            el.addEventListener(eventName, listener, capture);
            // #[begin] allua
        }
        else {
            el.attachEvent('on' + eventName, listener);
        }
        // #[end]
    }

// exports = module.exports = on;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file DOM �¼�ж��
     */

    /**
     * DOM �¼�ж��
     *
     * @inner
     * @param {HTMLElement} el DOMԪ��
     * @param {string} eventName �¼���
     * @param {Function} listener ��������
     * @param {boolean} capture �Ƿ��ǲ���׶�
     */
    function un(el, eventName, listener, capture) {
        // #[begin] allua
        if (el.addEventListener) {
            // #[end]
            el.removeEventListener(eventName, listener, capture);
            // #[begin] allua
        }
        else {
            el.detachEvent('on' + eventName, listener);
        }
        // #[end]
    }

// exports = module.exports = un;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���ַ��������зַ��ض���
     */

// var each = require('../util/each');

    /**
     * ���ַ��������зַ��ض���
     *
     * @param {string} source Դ�ַ���
     * @return {Object}
     */
    function splitStr2Obj(source) {
        var result = {};
        each(
            source.split(','),
            function (key) {
                result[key] = key;
            }
        );
        return result;
    }

// exports = module.exports = splitStr2Obj;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file SVG��ǩ��
     */

// var splitStr2Obj = require('../util/split-str-2-obj');

    /**
     * svgTags
     *
     * @see https://www.w3.org/TR/SVG/svgdtd.html ֻȡ����
     * @type {Object}
     */
    var svgTags = splitStr2Obj(''
        // structure
        + 'svg,g,defs,desc,metadata,symbol,use,'
        // image & shape
        + 'image,path,rect,circle,line,ellipse,polyline,polygon,'
        // text
        + 'text,tspan,tref,textpath,'
        // other
        + 'marker,pattern,clippath,mask,filter,cursor,view,animate,'
        // font
        + 'font,font-face,glyph,missing-glyph,'
        // camel
        + 'animateColor,animateMotion,animateTransform,textPath,foreignObject'
    );

// exports = module.exports = svgTags;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file DOM����
     */

// var svgTags = require('./svg-tags');

    /**
     * ���� DOM Ԫ��
     *
     * @param  {string} tagName tagName
     * @return {HTMLElement}
     */
    function createEl(tagName) {
        if (svgTags[tagName]) {
            return document.createElementNS('http://www.w3.org/2000/svg', tagName);
        }

        return document.createElement(tagName);
    }

// exports = module.exports = createEl;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �Ƴ�DOM
     */

    /**
     * �� DOM ��ҳ�����Ƴ�
     *
     * @param {HTMLElement} el DOMԪ��
     */
    function removeEl(el) {
        if (el && el.parentNode) {
            el.parentNode.removeChild(el);
        }
    }

// exports = module.exports = removeEl;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����һ��ʱ��������������
     */

// �÷���������vue2.5.0��ʵ�֣���лvue�Ŷ�
// SEE: https://github.com/vuejs/vue/blob/0948d999f2fddf9f90991956493f976273c5da1f/src/core/util/env.js#L68


// var bind = require('./bind');

    /**
     * ��һ������Ҫִ�е������б�
     *
     * @inner
     * @type {Array}
     */
    var nextTasks = [];

    /**
     * ִ����һ����������ĺ���
     *
     * @inner
     * @type {Function}
     */
    var nextHandler;

    /**
     * ������Ƿ�֧��ԭ��Promise
     * ��Promise���жϣ���Ϊ�˽���һЩ���Ͻ���Promise��polyfill
     *
     * @inner
     * @type {boolean}
     */
    var isNativePromise = typeof Promise === 'function' && /native code/.test(Promise);

    /**
     * ����һ��ʱ��������������
     *
     * @inner
     * @param {Function} fn Ҫ���е�������
     * @param {Object=} thisArg thisָ�����
     */
    function nextTick(fn, thisArg) {
        if (thisArg) {
            fn = bind(fn, thisArg);
        }
        nextTasks.push(fn);

        if (nextHandler) {
            return;
        }

        nextHandler = function () {
            var tasks = nextTasks.slice(0);
            nextTasks = [];
            nextHandler = null;

            for (var i = 0, l = tasks.length; i < l; i++) {
                tasks[i]();
            }
        };

        // �Ǳ�׼���������Ǵ˷����ǳ��Ǻ�Ҫ��
        if (typeof setImmediate === 'function') {
            setImmediate(nextHandler);
        }
        // ��MessageChannelȥ��setImmediate��polyfill
        // ԭ���ǽ��µ�message�¼����뵽ԭ�е�dom events֮��
        else if (typeof MessageChannel === 'function') {
            var channel = new MessageChannel();
            var port = channel.port2;
            channel.port1.onmessage = nextHandler;
            port.postMessage(1);
        }
        // for native app
        else if (isNativePromise) {
            Promise.resolve().then(nextHandler);
        }
        else {
            setTimeout(nextHandler, 0);
        }
    }

// exports = module.exports = nextTick;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ie�汾��
     */

    // #[begin] allua
    /**
     * ��userAgent��ie�汾�ŵ�ƥ����Ϣ
     *
     * @type {Array}
     */
    var ieVersionMatch = typeof navigator !== 'undefined'
        && navigator.userAgent.match(/msie\s*([0-9]+)/i);

    /**
     * ie�汾�ţ���ieʱΪ0
     *
     * @type {number}
     */
    var ie = ieVersionMatch ? ieVersionMatch[1] - 0 : 0;
// #[end]

// exports = module.exports = ie;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �Ƿ� IE ����С�� 9
     */

// var ie = require('./ie');

// HACK:
// 1. IE8�£�����innerHTMLʱ�����html comment��ͷ��comment�ᱻ�Զ��˵�
//    Ϊ�˱�֤stump���ڣ���Ҫ������html��createComment��appendChild/insertBefore
// 2. IE8�£�innerHTML����֧��custom element��������Ҫ��div���������createElement
// 3. ��ȻIE8�Ѿ��Ż����ַ���+���ӣ���Ƭ���������ܲ����˻�
//    �����������������ݳ������� < 9 �жϣ������ַ�������Ҳ����
//    ���Խ����IE8���ַ��������õ�������join�ķ�ʽ

// #[begin] allua
    /**
     * �Ƿ� IE ����С�� 9
     */
    var ieOldThan9 = ie && ie < 9;
// #[end]

// exports = module.exports = ieOldThan9;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Ԫ���¼�
     */

    /**
     * ����Ԫ���¼�
     *
     * @inner
     * @param {HTMLElement} el DOMԪ��
     * @param {string} eventName �¼���
     */
    function trigger(el, eventName) {
        var event = document.createEvent('HTMLEvents');
        event.initEvent(eventName, true, true);
        el.dispatchEvent(event);
    }

// exports = module.exports = trigger;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��� IE9 �ڱ���Ԫ����ɾ���ַ�ʱ�������¼�������
     */

// var ie = require('./ie');
// var on = require('./on');
// var trigger = require('./trigger');

// #[begin] allua
    if (ie === 9) {
        on(document, 'selectionchange', function () {
            var el = document.activeElement;
            if (el.tagName === 'TEXTAREA' || el.tagName === 'INPUT') {
                trigger(el, 'input');
            }
        });
    }
// #[end]


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �Ապϱ�ǩ��
     */

// var splitStr2Obj = require('../util/split-str-2-obj');

    /**
     * �Ապϱ�ǩ�б�
     *
     * @type {Object}
     */
    var autoCloseTags = splitStr2Obj('area,base,br,col,embed,hr,img,input,keygen,param,source,track,wbr');

// exports = module.exports = autoCloseTags;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file data types
     */

// var bind = require('./bind');
// var empty = require('./empty');
// var extend = require('./extend');

// #[begin] error
    var ANONYMOUS_CLASS_NAME = '<<anonymous>>';

    /**
     * ��ȡ��ȷ������
     *
     * @NOTE ��� obj ��һ�� DOMElement�����ǻ᷵�� `element`��
     *
     * @param  {*} obj Ŀ��
     * @return {string}
     */
    function getDataType(obj) {

        if (obj && obj.nodeType === 1) {
            return 'element';
        }

        return Object.prototype.toString
            .call(obj)
            .slice(8, -1)
            .toLowerCase();
    }
// #[end]

    /**
     * ������ʽ����������У����
     *
     * @param  {Function} validate ������У����
     * @return {Function}
     */
    function createChainableChecker(validate) {
        var chainedChecker = function () {};
        chainedChecker.isRequired = empty;

        // ֻ�� error ��������ʱ����ʵ���ϵ� dataTypes ���
        // #[begin] error
        var checkType = function (isRequired, data, dataName, componentName, fullDataName) {

            var dataValue = data[dataName];
            var dataType = getDataType(dataValue);

            componentName = componentName || ANONYMOUS_CLASS_NAME;

            // ����� null �� undefined����ôҪ��ǰ������
            if (dataValue == null) {
                // �� required �ͱ���
                if (isRequired) {
                    throw new Error('[SAN ERROR] '
                        + 'The `' + dataName + '` '
                        + 'is marked as required in `' + componentName + '`, '
                        + 'but its value is ' + dataType
                    );
                }
                // ���� required���Ǿ��� ok ��
                return;
            }

            validate(data, dataName, componentName, fullDataName);

        };

        chainedChecker = bind(checkType, null, false);
        chainedChecker.isRequired = bind(checkType, null, true);
        // #[end]



        return chainedChecker;

    }

// #[begin] error
    /**
     * ������Ҫ��������У����
     *
     * @param  {string} type ������
     * @return {Function}
     */
    function createPrimaryTypeChecker(type) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            var dataValue = data[dataName];
            var dataType = getDataType(dataValue);

            if (dataType !== type) {
                throw new Error('[SAN ERROR] '
                    + 'Invalid ' + componentName + ' data `' + fullDataName + '` of type'
                    + '(' + dataType + ' supplied to ' + componentName + ', '
                    + 'expected ' + type + ')'
                );
            }

        });

    }



    /**
     * ���� arrayOf У����
     *
     * @param  {Function} arrayItemChecker ������ÿ�����ݵ�У����
     * @return {Function}
     */
    function createArrayOfChecker(arrayItemChecker) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            if (typeof arrayItemChecker !== 'function') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + dataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `arrayOf`, expected `function`'
                );
            }

            var dataValue = data[dataName];
            var dataType = getDataType(dataValue);

            if (dataType !== 'array') {
                throw new Error('[SAN ERROR] '
                    + 'Invalid ' + componentName + ' data `' + fullDataName + '` of type'
                    + '(' + dataType + ' supplied to ' + componentName + ', '
                    + 'expected array)'
                );
            }

            for (var i = 0, len = dataValue.length; i < len; i++) {
                arrayItemChecker(dataValue, i, componentName, fullDataName + '[' + i + ']');
            }

        });

    }

    /**
     * ���� instanceOf �����
     *
     * @param  {Function|Class} expectedClass �ڴ�����
     * @return {Function}
     */
    function createInstanceOfChecker(expectedClass) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            var dataValue = data[dataName];

            if (dataValue instanceof expectedClass) {
                return;
            }

            var dataValueClassName = dataValue.constructor && dataValue.constructor.name
                ? dataValue.constructor.name
                : ANONYMOUS_CLASS_NAME;

            var expectedClassName = expectedClass.name || ANONYMOUS_CLASS_NAME;

            throw new Error('[SAN ERROR] '
                + 'Invalid ' + componentName + ' data `' + fullDataName + '` of type'
                + '(' + dataValueClassName + ' supplied to ' + componentName + ', '
                + 'expected instance of ' + expectedClassName + ')'
            );


        });

    }

    /**
     * ���� shape У����
     *
     * @param  {Object} shapeTypes shape У�����
     * @return {Function}
     */
    function createShapeChecker(shapeTypes) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            if (getDataType(shapeTypes) !== 'object') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + fullDataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `shape`, expected `object`'
                );
            }

            var dataValue = data[dataName];
            var dataType = getDataType(dataValue);

            if (dataType !== 'object') {
                throw new Error('[SAN ERROR] '
                    + 'Invalid ' + componentName + ' data `' + fullDataName + '` of type'
                    + '(' + dataType + ' supplied to ' + componentName + ', '
                    + 'expected object)'
                );
            }

            for (var shapeKeyName in shapeTypes) {
                if (shapeTypes.hasOwnProperty(shapeKeyName)) {
                    var checker = shapeTypes[shapeKeyName];
                    if (typeof checker === 'function') {
                        checker(dataValue, shapeKeyName, componentName, fullDataName + '.' + shapeKeyName);
                    }
                }
            }

        });

    }

    /**
     * ���� oneOf У����
     *
     * @param  {Array} expectedEnumValues �ڴ���ö��ֵ
     * @return {Function}
     */
    function createOneOfChecker(expectedEnumValues) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            if (getDataType(expectedEnumValues) !== 'array') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + fullDataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `oneOf`, array is expected.'
                );
            }

            var dataValue = data[dataName];

            for (var i = 0, len = expectedEnumValues.length; i < len; i++) {
                if (dataValue === expectedEnumValues[i]) {
                    return;
                }
            }

            throw new Error('[SAN ERROR] '
                + 'Invalid ' + componentName + ' data `' + fullDataName + '` of value'
                + '(`' + dataValue + '` supplied to ' + componentName + ', '
                + 'expected one of ' + expectedEnumValues.join(',') + ')'
            );

        });

    }

    /**
     * ���� oneOfType У����
     *
     * @param  {Array<Function>} expectedEnumOfTypeValues �ڴ���ö������
     * @return {Function}
     */
    function createOneOfTypeChecker(expectedEnumOfTypeValues) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            if (getDataType(expectedEnumOfTypeValues) !== 'array') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + dataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `oneOf`, array is expected.'
                );
            }

            var dataValue = data[dataName];

            for (var i = 0, len = expectedEnumOfTypeValues.length; i < len; i++) {

                var checker = expectedEnumOfTypeValues[i];

                if (typeof checker !== 'function') {
                    continue;
                }

                try {
                    checker(data, dataName, componentName, fullDataName);
                    // ��� checker ���У��û�������Ǿͷ�����
                    return;
                }
                catch (e) {
                    // ����д�����ôӦ�ðѴ����̵�
                }

            }

            // ���еĿɽ��� type ��ʧ���ˣ��Ŷ�һ���쳣
            throw new Error('[SAN ERROR] '
                + 'Invalid ' + componentName + ' data `' + dataName + '` of value'
                + '(`' + dataValue + '` supplied to ' + componentName + ')'
            );

        });

    }

    /**
     * ���� objectOf У����
     *
     * @param  {Function} typeChecker ��������ֵУ����
     * @return {Function}
     */
    function createObjectOfChecker(typeChecker) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName) {

            if (typeof typeChecker !== 'function') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + dataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `objectOf`, expected function'
                );
            }

            var dataValue = data[dataName];
            var dataType = getDataType(dataValue);

            if (dataType !== 'object') {
                throw new Error('[SAN ERROR] '
                    + 'Invalid ' + componentName + ' data `' + dataName + '` of type'
                    + '(' + dataType + ' supplied to ' + componentName + ', '
                    + 'expected object)'
                );
            }

            for (var dataKeyName in dataValue) {
                if (dataValue.hasOwnProperty(dataKeyName)) {
                    typeChecker(
                        dataValue,
                        dataKeyName,
                        componentName,
                        fullDataName + '.' + dataKeyName
                    );
                }
            }


        });

    }

    /**
     * ���� exact У����
     *
     * @param  {Object} shapeTypes object ��̬����
     * @return {Function}
     */
    function createExactChecker(shapeTypes) {

        return createChainableChecker(function (data, dataName, componentName, fullDataName, secret) {

            if (getDataType(shapeTypes) !== 'object') {
                throw new Error('[SAN ERROR] '
                    + 'Data `' + dataName + '` of `' + componentName + '` has invalid '
                    + 'DataType notation inside `exact`'
                );
            }

            var dataValue = data[dataName];
            var dataValueType = getDataType(dataValue);

            if (dataValueType !== 'object') {
                throw new Error('[SAN ERROR] '
                    + 'Invalid data `' + fullDataName + '` of type `' + dataValueType + '`'
                    + '(supplied to ' + componentName + ', expected `object`)'
                );
            }

            var allKeys = {};

            // �Ⱥ��� shapeTypes
            extend(allKeys, shapeTypes);
            // �ٺ��� dataValue
            extend(allKeys, dataValue);
            // ��֤ allKeys ��������ȷ

            for (var key in allKeys) {
                if (allKeys.hasOwnProperty(key)) {
                    var checker = shapeTypes[key];

                    // dataValue ����һ�������������
                    if (!checker) {
                        throw new Error('[SAN ERROR] '
                            + 'Invalid data `' + fullDataName + '` key `' + key + '` '
                            + 'supplied to `' + componentName + '`. '
                            + '(`' + key + '` is not defined in `DataTypes.exact`)'
                        );
                    }

                    if (!(key in dataValue)) {
                        throw new Error('[SAN ERROR] '
                            + 'Invalid data `' + fullDataName + '` key `' + key + '` '
                            + 'supplied to `' + componentName + '`. '
                            + '(`' + key + '` is marked `required` in `DataTypes.exact`)'
                        );
                    }

                    checker(
                        dataValue,
                        key,
                        componentName,
                        fullDataName + '.' + key,
                        secret
                    );

                }
            }

        });

    }
// #[end]



    /* eslint-disable fecs-valid-var-jsdoc */
    var DataTypes = {
        array: createChainableChecker(empty),
        object: createChainableChecker(empty),
        func: createChainableChecker(empty),
        string: createChainableChecker(empty),
        number: createChainableChecker(empty),
        bool: createChainableChecker(empty),
        symbol: createChainableChecker(empty),
        any: createChainableChecker,
        arrayOf: createChainableChecker,
        instanceOf: createChainableChecker,
        shape: createChainableChecker,
        oneOf: createChainableChecker,
        oneOfType: createChainableChecker,
        objectOf: createChainableChecker,
        exact: createChainableChecker
    };

// #[begin] error
    DataTypes = {

        any: createChainableChecker(empty),

        // ���ͼ��
        array: createPrimaryTypeChecker('array'),
        object: createPrimaryTypeChecker('object'),
        func: createPrimaryTypeChecker('function'),
        string: createPrimaryTypeChecker('string'),
        number: createPrimaryTypeChecker('number'),
        bool: createPrimaryTypeChecker('boolean'),
        symbol: createPrimaryTypeChecker('symbol'),

        // �������ͼ��
        arrayOf: createArrayOfChecker,
        instanceOf: createInstanceOfChecker,
        shape: createShapeChecker,
        oneOf: createOneOfChecker,
        oneOfType: createOneOfTypeChecker,
        objectOf: createObjectOfChecker,
        exact: createExactChecker

    };
    /* eslint-enable fecs-valid-var-jsdoc */
// #[end]


// module.exports = DataTypes;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �������ݼ�⺯��
     */


// #[begin] error

    /**
     * �������ݼ�⺯��
     *
     * @param  {Object} dataTypes     ���ݸ�ʽ
     * @param  {string} componentName �����
     * @return {Function}
     */
    function createDataTypesChecker(dataTypes, componentName) {

        /**
         * У�� data �Ƿ����� data types �ĸ�ʽ
         *
         * @param  {*} data ����
         */
        return function (data) {

            for (var dataTypeName in dataTypes) {

                if (dataTypes.hasOwnProperty(dataTypeName)) {

                    var dataTypeChecker = dataTypes[dataTypeName];

                    if (typeof dataTypeChecker !== 'function') {
                        throw new Error('[SAN ERROR] '
                            + componentName + ':' + dataTypeName + ' is invalid; '
                            + 'it must be a function, usually from san.DataTypes'
                        );
                    }

                    dataTypeChecker(
                        data,
                        dataTypeName,
                        componentName,
                        dataTypeName
                    );


                }
            }

        };

    }

// #[end]

// module.exports = createDataTypesChecker;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ַ���Դ���ȡ��
     */


    /**
     * �ַ���Դ���ȡ�࣬����ģ���ַ�����������
     *
     * @class
     * @param {string} source Ҫ��ȡ���ַ���
     */
    function Walker(source) {
        this.source = source;
        this.len = this.source.length;
        this.index = 0;
    }

    /**
     * ��ȡ��ǰ�ַ���
     *
     * @return {number}
     */
    Walker.prototype.currentCode = function () {
        return this.source.charCodeAt(this.index);
    };

    /**
     * ��ȡ�ַ���Ƭ��
     *
     * @param {number} start ��ʼλ��
     * @param {number} end ����λ��
     * @return {string}
     */
    Walker.prototype.cut = function (start, end) {
        return this.source.slice(start, end);
    };

    /**
     * ��ǰ��ȡ�ַ�
     *
     * @param {number} distance ��ȡ�ַ���
     */
    Walker.prototype.go = function (distance) {
        this.index += distance;
    };

    /**
     * ��ȡ��һ���ַ���������һ���ַ��� code
     *
     * @return {number}
     */
    Walker.prototype.nextCode = function () {
        this.go(1);
        return this.currentCode();
    };

    /**
     * ��ȡ��Ӧλ���ַ��� code
     *
     * @param {number} index �ַ�λ��
     * @return {number}
     */
    Walker.prototype.charCode = function (index) {
        return this.source.charCodeAt(index);
    };

    /**
     * ��ǰ��ȡ�ַ���ֱ������ָ���ַ���ֹͣ
     * δָ���ַ�ʱ����������һ���ǿո��Ʊ������ַ�ֹͣ
     *
     * @param {number=} charCode ָ���ַ���code
     * @return {boolean} ��ָ���ַ�ʱ�������Ƿ�����ָ�����ַ�
     */
    Walker.prototype.goUntil = function (charCode) {
        var code;
        while (this.index < this.len && (code = this.currentCode())) {
            switch (code) {
                // �ո� space
                case 32:
                // �Ʊ��� tab
                case 9:
                // \r
                case 13:
                // \n
                case 10:
                    this.index++;
                    break;
                default:
                    if (code === charCode) {
                        this.index++;
                        return 1;
                    }
                    return;
            }
        }
    };

    /**
     * ��ǰ��ȡ���Ϲ�����ַ�Ƭ�Σ������ع���ƥ����
     *
     * @param {RegExp} reg �ַ�Ƭ�ε��������ʽ
     * @param {boolean} isMatchStart �Ƿ����ƥ�䵱ǰλ��
     * @return {Array?}
     */
    Walker.prototype.match = function (reg, isMatchStart) {
        reg.lastIndex = this.index;

        var match = reg.exec(this.source);
        if (match && (!isMatchStart || this.index === match.index)) {
            this.index = reg.lastIndex;
            return match;
        }
    };

// exports = module.exports = Walker;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ģ��������ɵĳ���ڵ�
     */

    /**
     * ����ģ��������ɵĳ���ڵ�
     *
     * @param {Object=} options �ڵ����
     * @param {string=} options.tagName ��ǩ��
     * @param {ANode=} options.parent ���ڵ�
     * @param {boolean=} options.textExpr �ı��ڵ����ʽ����
     * @return {Object}
     */
    function createANode(options) {
        options = options || {};

        if (!options.textExpr) {
            options.directives = options.directives || {};
            options.props = options.props || [];
            options.events = options.events || [];
            options.children = options.children || [];
        }

        return options;
    }

// exports = module.exports = createANode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �� kebab case �ַ���ת���� camel case
     */

    /**
     * �� kebab case �ַ���ת���� camel case
     *
     * @param {string} source Դ�ַ���
     * @return {string}
     */
    function kebab2camel(source) {
        return source.replace(/-+(.)/ig, function (match, alpha) {
            return alpha.toUpperCase();
        });
    }

// exports = module.exports = kebab2camel;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ʽ����
     */

    /**
     * ����ʽ����
     *
     * @const
     * @type {Object}
     */
    var ExprType = {
        STRING: 1,
        NUMBER: 2,
        BOOL: 3,
        ACCESSOR: 4,
        INTERP: 5,
        CALL: 6,
        TEXT: 7,
        BINARY: 8,
        UNARY: 9,
        TERTIARY: 10,
        OBJECT: 11,
        ARRAY: 12
    };

// exports = module.exports = ExprType;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �������ʱ���ʽ����
     */

// var ExprType = require('./expr-type');

    /**
     * �������ʱ���ʽ����
     *
     * @param {Array} paths ����·��
     * @return {Object}
     */
    function createAccessor(paths) {
        return {
            type: 4,
            paths: paths
        };
    }

// exports = module.exports = createAccessor;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�ַ���
     */


// var ExprType = require('./expr-type');

    /**
     * ��ȡ�ַ���
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readString(walker) {
        var startCode = walker.currentCode();
        var startIndex = walker.index;
        var charCode;

        walkLoop: while ((charCode = walker.nextCode())) {
            switch (charCode) {
                case 92: // \
                    walker.go(1);
                    break;
                case startCode:
                    walker.go(1);
                    break walkLoop;
            }
        }

        var literal = walker.cut(startIndex, walker.index);
        return {
            type: 1,
            // �����ַ�ת��
            value: (new Function('return ' + literal))()
        };
    }

// exports = module.exports = readString;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡһԪ����ʽ
     */

// var ExprType = require('./expr-type');
// var readString = require('./read-string');
// var readNumber = require('./read-number');
// var readCall = require('./read-call');
// var readParenthesizedExpr = require('./read-parenthesized-expr');
// var readTertiaryExpr = require('./read-tertiary-expr');


    /**
     * ��ȡһԪ����ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readUnaryExpr(walker) {
        walker.goUntil();

        switch (walker.currentCode()) {
            case 33: // !
                walker.go(1);
                return {
                    type: 9,
                    expr: readUnaryExpr(walker),
                    operator: 33
                };

            case 34: // "
            case 39: // '
                return readString(walker);

            case 45: // -
            // number
            case 48:
            case 49:
            case 50:
            case 51:
            case 52:
            case 53:
            case 54:
            case 55:
            case 56:
            case 57:
                return readNumber(walker);

            case 40: // (
                return readParenthesizedExpr(walker);

            // array literal
            case 91: // [
                walker.go(1);
                var arrItems = [];
                while (!walker.goUntil(93)) { // ]
                    var item = {};
                    arrItems.push(item);

                    if (walker.currentCode() === 46 && walker.match(/\.\.\.\s*/g)) {
                        item.spread = true;
                    }

                    item.expr = readTertiaryExpr(walker);
                    walker.goUntil(44); // ,
                }

                return {
                    type: 12,
                    items: arrItems
                };

            // object literal
            case 123: // {
                walker.go(1);
                var objItems = [];

                while (!walker.goUntil(125)) { // }
                    var item = {};
                    objItems.push(item);

                    if (walker.currentCode() === 46 && walker.match(/\.\.\.\s*/g)) {
                        item.spread = true;
                        item.expr = readTertiaryExpr(walker);
                    }
                    else {
                        // #[begin] error
                        var walkerIndexBeforeName = walker.index;
                        // #[end]

                        item.name = readUnaryExpr(walker);

                        // #[begin] error
                        if (item.name.type > 4) {
                            throw new Error(
                                '[SAN FATAL] unexpect object name: '
                                + walker.cut(walkerIndexBeforeName, walker.index)
                            );
                        }
                        // #[end]

                        if (walker.goUntil(58)) { // :
                            item.expr = readTertiaryExpr(walker);
                        }
                        else {
                            item.expr = item.name;
                        }

                        if (item.name.type === 4) {
                            item.name = item.name.paths[0];
                        }
                    }

                    walker.goUntil(44); // ,
                }

                return {
                    type: 11,
                    items: objItems
                };
        }

        return readCall(walker);
    }

// exports = module.exports = readUnaryExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ����
     */


// var ExprType = require('./expr-type');
// var readUnaryExpr = require('./read-unary-expr');

    /**
     * ��ȡ����
     *
     * @inner
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readNumber(walker) {
        var match = walker.match(/\s*(-?[0-9]+(\.[0-9]+)?)/g, 1);

        if (match) {
            return {
                type: 2,
                value: +match[1]
            };
        }
        else if (walker.currentCode() === 45) {
            walker.go(1);
            return {
                type: 9,
                expr: readUnaryExpr(walker),
                operator: 45
            };
        }
    }

// exports = module.exports = readNumber;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡident
     */

    /**
     * ��ȡident
     * ����� ident ָ��ʶ��(identifier)��Ҳ����ͨ�������ϵı�����
     * ����Ĭ�ϵı���������Ϊ������Ԫ����($)�����֡���ĸ�����»���(_)���ɵ��ַ���
     *
     * @inner
     * @param {Walker} walker Դ���ȡ����
     * @return {string}
     */
    function readIdent(walker) {
        var match = walker.match(/\s*([\$0-9a-z_]+)/ig, 1);

        // #[begin] error
        if (!match) {
            throw new Error('[SAN FATAL] expect an ident: ' + walker.cut(walker.index));
        }
        // #[end]

        return match[1];
    }

// exports = module.exports = readIdent;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ��Ԫ����ʽ
     */

// var ExprType = require('./expr-type');
// var readLogicalORExpr = require('./read-logical-or-expr');

    /**
     * ��ȡ��Ԫ����ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readTertiaryExpr(walker) {
        var conditional = readLogicalORExpr(walker);
        walker.goUntil();

        if (walker.currentCode() === 63) { // ?
            walker.go(1);
            var yesExpr = readTertiaryExpr(walker);
            walker.goUntil();

            if (walker.currentCode() === 58) { // :
                walker.go(1);
                return {
                    type: 10,
                    segs: [
                        conditional,
                        yesExpr,
                        readTertiaryExpr(walker)
                    ]
                };
            }
        }

        return conditional;
    }

// exports = module.exports = readTertiaryExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ���ʱ���ʽ
     */

// var ExprType = require('./expr-type');
// var createAccessor = require('./create-accessor');
// var readIdent = require('./read-ident');
// var readTertiaryExpr = require('./read-tertiary-expr');

    /**
     * ��ȡ���ʱ���ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readAccessor(walker) {
        var firstSeg = readIdent(walker);
        switch (firstSeg) {
            case 'true':
            case 'false':
                return {
                    type: 3,
                    value: firstSeg === 'true'
                };
        }

        var result = createAccessor([
            {
                type: 1,
                value: firstSeg
            }
        ]);

        /* eslint-disable no-constant-condition */
        accessorLoop: while (1) {
            /* eslint-enable no-constant-condition */

            switch (walker.currentCode()) {
                case 46: // .
                    walker.go(1);

                    // ident as string
                    result.paths.push({
                        type: 1,
                        value: readIdent(walker)
                    });
                    break;

                case 91: // [
                    walker.go(1);
                    result.paths.push(readTertiaryExpr(walker));
                    walker.goUntil(93); // ]
                    break;

                default:
                    break accessorLoop;
            }
        }

        return result;
    }

// exports = module.exports = readAccessor;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ����
     */

// var ExprType = require('./expr-type');
// var readAccessor = require('./read-accessor');
// var readTertiaryExpr = require('./read-tertiary-expr');

    /**
     * ��ȡ����
     *
     * @param {Walker} walker Դ���ȡ����
     * @param {Array=} defaultArgs Ĭ�ϲ���
     * @return {Object}
     */
    function readCall(walker, defaultArgs) {
        walker.goUntil();
        var result = readAccessor(walker);

        var args;
        if (walker.goUntil(40)) { // (
            args = [];

            while (!walker.goUntil(41)) { // )
                args.push(readTertiaryExpr(walker));
                walker.goUntil(44); // ,
            }
        }
        else if (defaultArgs) {
            args = defaultArgs;
        }

        if (args) {
            result = {
                type: 6,
                name: result,
                args: args
            };
        }

        return result;
    }

// exports = module.exports = readCall;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ���ű���ʽ
     */

// var readTertiaryExpr = require('./read-tertiary-expr');

    /**
     * ��ȡ���ű���ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readParenthesizedExpr(walker) {
        walker.go(1);
        var expr = readTertiaryExpr(walker);
        walker.goUntil(41); // )

        expr.parenthesized = true;
        return expr;
    }

// exports = module.exports = readParenthesizedExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�˷�����ʽ
     */

// var ExprType = require('./expr-type');
// var readUnaryExpr = require('./read-unary-expr');

    /**
     * ��ȡ�˷�����ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readMultiplicativeExpr(walker) {
        var expr = readUnaryExpr(walker);

        while (1) {
            walker.goUntil();

            var code = walker.currentCode();
            switch (code) {
                case 37: // %
                case 42: // *
                case 47: // /
                    walker.go(1);
                    expr = {
                        type: 8,
                        operator: code,
                        segs: [expr, readUnaryExpr(walker)]
                    };
                    continue;
            }

            break;
        }


        return expr;
    }

// exports = module.exports = readMultiplicativeExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�ӷ�����ʽ
     */

// var ExprType = require('./expr-type');
// var readMultiplicativeExpr = require('./read-multiplicative-expr');


    /**
     * ��ȡ�ӷ�����ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readAdditiveExpr(walker) {
        var expr = readMultiplicativeExpr(walker);

        while (1) {
            walker.goUntil();
            var code = walker.currentCode();

            switch (code) {
                case 43: // +
                case 45: // -
                    walker.go(1);
                    expr = {
                        type: 8,
                        operator: code,
                        segs: [expr, readMultiplicativeExpr(walker)]
                    };
                    continue;
            }

            break;
        }

        return expr;
    }

// exports = module.exports = readAdditiveExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ��ϵ�жϱ���ʽ
     */

// var ExprType = require('./expr-type');
// var readAdditiveExpr = require('./read-additive-expr');

    /**
     * ��ȡ��ϵ�жϱ���ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readRelationalExpr(walker) {
        var expr = readAdditiveExpr(walker);
        walker.goUntil();

        var code = walker.currentCode();
        switch (code) {
            case 60: // <
            case 62: // >
                if (walker.nextCode() === 61) {
                    code += 61;
                    walker.go(1);
                }

                return {
                    type: 8,
                    operator: code,
                    segs: [expr, readAdditiveExpr(walker)]
                };
        }

        return expr;
    }

// exports = module.exports = readRelationalExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ��ȱȶԱ���ʽ
     */

// var ExprType = require('./expr-type');
// var readRelationalExpr = require('./read-relational-expr');

    /**
     * ��ȡ��ȱȶԱ���ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readEqualityExpr(walker) {
        var expr = readRelationalExpr(walker);
        walker.goUntil();

        var code = walker.currentCode();
        switch (code) {
            case 61: // =
            case 33: // !
                if (walker.nextCode() === 61) {
                    code += 61;
                    if (walker.nextCode() === 61) {
                        code += 61;
                        walker.go(1);
                    }

                    return {
                        type: 8,
                        operator: code,
                        segs: [expr, readRelationalExpr(walker)]
                    };
                }

                walker.go(-1);
        }

        return expr;
    }

// exports = module.exports = readEqualityExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�߼������ʽ
     */

// var ExprType = require('./expr-type');
// var readEqualityExpr = require('./read-equality-expr');

    /**
     * ��ȡ�߼������ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readLogicalANDExpr(walker) {
        var expr = readEqualityExpr(walker);
        walker.goUntil();

        if (walker.currentCode() === 38) { // &
            if (walker.nextCode() === 38) {
                walker.go(1);
                return {
                    type: 8,
                    operator: 76,
                    segs: [expr, readLogicalANDExpr(walker)]
                };
            }

            walker.go(-1);
        }

        return expr;
    }

// exports = module.exports = readLogicalANDExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�߼������ʽ
     */

// var ExprType = require('./expr-type');
// var readLogicalANDExpr = require('./read-logical-and-expr');

    /**
     * ��ȡ�߼������ʽ
     *
     * @param {Walker} walker Դ���ȡ����
     * @return {Object}
     */
    function readLogicalORExpr(walker) {
        var expr = readLogicalANDExpr(walker);
        walker.goUntil();

        if (walker.currentCode() === 124) { // |
            if (walker.nextCode() === 124) {
                walker.go(1);
                return {
                    type: 8,
                    operator: 248,
                    segs: [expr, readLogicalORExpr(walker)]
                };
            }

            walker.go(-1);
        }

        return expr;
    }

// exports = module.exports = readLogicalORExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��������ʽ
     */

// var Walker = require('./walker');
// var readTertiaryExpr = require('./read-tertiary-expr');

    /**
     * ��������ʽ
     *
     * @param {string} source Դ��
     * @return {Object}
     */
    function parseExpr(source) {
        if (!source) {
            return;
        }

        if (typeof source === 'object' && source.type) {
            return source;
        }

        var expr = readTertiaryExpr(new Walker(source));
        expr.raw = source;
        return expr;
    }

// exports = module.exports = parseExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��������
     */


// var Walker = require('./walker');
// var ExprType = require('./expr-type');
// var readCall = require('./read-call');

    /**
     * ��������
     *
     * @param {string} source Դ��
     * @param {Array=} defaultArgs Ĭ�ϲ���
     * @return {Object}
     */
    function parseCall(source, defaultArgs) {
        var expr = readCall(new Walker(source), defaultArgs);

        if (expr.type !== 6) {
            expr = {
                type: 6,
                name: expr,
                args: defaultArgs || []
            };
        }

        expr.raw = source;
        return expr;
    }

// exports = module.exports = parseCall;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ������ֵ�滻
     */

// var Walker = require('./walker');
// var readTertiaryExpr = require('./read-tertiary-expr');
// var ExprType = require('./expr-type');
// var readCall = require('./read-call');

    /**
     * ������ֵ�滻
     *
     * @param {string} source Դ��
     * @return {Object}
     */
    function parseInterp(source) {
        var walker = new Walker(source);

        var interp = {
            type: 5,
            expr: readTertiaryExpr(walker),
            filters: [],
            raw: source
        };

        while (walker.goUntil(124)) { // |
            var callExpr = readCall(walker, []);
            switch (callExpr.name.paths[0].value) {
                case 'html':
                    break;
                case 'raw':
                    interp.original = 1;
                    break;
                default:
                    interp.filters.push(callExpr);
            }
        }

        return interp;
    }

// exports = module.exports = parseInterp;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���� HTML �ַ�ʵ��
     */

    var ENTITY_DECODE_MAP = {
        lt: '<',
        gt: '>',
        nbsp: ' ',
        quot: '\"',
        emsp: '\u2003',
        ensp: '\u2002',
        thinsp: '\u2009',
        copy: '\xa9',
        reg: '\xae',
        zwnj: '\u200c',
        zwj: '\u200d',
        amp: '&'
    };

    /**
     * ���� HTML �ַ�ʵ��
     *
     * @param {string} source Ҫ������ַ���
     * @return {string}
     */
    function decodeHTMLEntity(source) {
        return source
            .replace(/&#([0-9]+);/g, function (match, code) {
                return String.fromCharCode(+code);
            })
            .replace(/&#x([0-9a-f]+);/ig, function (match, code) {
                return String.fromCharCode(parseInt(code, 16));
            })
            .replace(/&([a-z]+);/ig, function (match, code) {
                return ENTITY_DECODE_MAP[code] || match;
            });
    }

// exports = module.exports = decodeHTMLEntity;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ı�
     */

// var Walker = require('./walker');
// var ExprType = require('./expr-type');
// var parseInterp = require('./parse-interp');
// var decodeHTMLEntity = require('../util/decode-html-entity');

    /**
     * ���ַ������п�����new RegExp�����滯
     *
     * @inner
     * @param {string} source ��Ҫ���滯���ַ���
     * @return {string} �ַ������滯���
     */
    function regexpLiteral(source) {
        return source.replace(/[\^\[\]\$\(\)\{\}\?\*\.\+\\]/g, function (c) {
            return '\\' + c;
        });
    }

    var delimRegCache = {};

    /**
     * �����ı�
     *
     * @param {string} source Դ��
     * @param {Array?} delimiters �ָ�����Ĭ��Ϊ ['{{', '}}']
     * @return {Object}
     */
    function parseText(source, delimiters) {
        delimiters = delimiters || ['{{', '}}'];

        var regCacheKey = delimiters[0] + '>..<' + delimiters[1];
        var exprStartReg = delimRegCache[regCacheKey];
        if (!exprStartReg) {
            exprStartReg = new RegExp(
                regexpLiteral(delimiters[0])
                + '\\s*([\\s\\S]+?)\\s*'
                + regexpLiteral(delimiters[1]),
                'ig'
            );
            delimRegCache[regCacheKey] = exprStartReg;
        }

        var exprMatch;

        var walker = new Walker(source);
        var beforeIndex = 0;

        var expr = {
            type: 7,
            segs: []
        };

        function pushStringToSeg(text) {
            text && expr.segs.push({
                type: 1,
                literal: text,
                value: decodeHTMLEntity(text)
            });
        }

        var delimEndLen = delimiters[1].length;
        while ((exprMatch = walker.match(exprStartReg)) != null) {
            var interpSource = exprMatch[1];
            var interpLen = exprMatch[0].length;
            if (walker.cut(walker.index + 1 - delimEndLen, walker.index + 1) === delimiters[1]) {
                interpSource += walker.cut(walker.index, walker.index + 1);
                walker.go(1);
                interpLen++;
            }

            pushStringToSeg(walker.cut(
                beforeIndex,
                walker.index - interpLen
            ));

            var interp = parseInterp(interpSource);
            expr.original = expr.original || interp.original;
            expr.segs.push(interp);

            beforeIndex = walker.index;
        }

        pushStringToSeg(walker.cut(beforeIndex));



        if (expr.segs.length === 1 && expr.segs[0].type === 1) {
            expr.value = expr.segs[0].value;
        }

        return expr;
    }

// exports = module.exports = parseText;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ָ��
     */


// var Walker = require('./walker');
// var parseExpr = require('./parse-expr');
// var parseCall = require('./parse-call');
// var parseText = require('./parse-text');
// var readAccessor = require('./read-accessor');
// var readUnaryExpr = require('./read-unary-expr');

    /**
     * ָ�������
     *
     * @inner
     * @type {Object}
     */
    var directiveParsers = {
        'for': function (value) {
            var walker = new Walker(value);
            var match = walker.match(/^\s*([\$0-9a-z_]+)(\s*,\s*([\$0-9a-z_]+))?\s+in\s+/ig, 1);

            if (match) {
                var directive = {
                    item: parseExpr(match[1]),
                    index: parseExpr(match[3] || '$index'),
                    value: readUnaryExpr(walker)
                };

                if (walker.match(/\s*trackby\s+/ig, 1)) {
                    var start = walker.index;
                    directive.trackBy = readAccessor(walker);
                    directive.trackBy.raw = walker.cut(start, walker.index);
                }
                return directive;
            }

            // #[begin] error
            throw new Error('[SAN FATAL] for syntax error: ' + value);
            // #[end]
        },

        'ref': function (value, options) {
            return {
                value: parseText(value, options.delimiters)
            };
        },

        'if': function (value) {
            return {
                value: parseExpr(value.replace(/(^\{\{|\}\}$)/g, ''))
            };
        },

        'elif': function (value) {
            return {
                value: parseExpr(value.replace(/(^\{\{|\}\}$)/g, ''))
            };
        },

        'else': function (value) {
            return {
                value: {}
            };
        },

        'bind': function (value) {
            return {
                value: parseExpr(value.replace(/(^\{\{|\}\}$)/g, ''))
            };
        },

        'html': function (value) {
            return {
                value: parseExpr(value.replace(/(^\{\{|\}\}$)/g, ''))
            };
        },

        'transition': function (value) {
            return {
                value: parseCall(value)
            };
        }
    };

    /**
     * ����ָ��
     *
     * @param {ANode} aNode ����ڵ�
     * @param {string} name ָ������
     * @param {string} value ָ��ֵ
     * @param {Object} options ��������
     * @param {Array?} options.delimiters ��ֵ�ָ����б�
     */
    function parseDirective(aNode, name, value, options) {
        if (name === 'else-if') {
            name = 'elif';
        }

        var parser = directiveParsers[name];
        if (parser) {
            (aNode.directives[name] = parser(value, options)).raw = value;
        }
    }

// exports = module.exports = parseDirective;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��������Ϣ���д���
     */

// var ExprType = require('../parser/expr-type');

    /**
     * ��������Ϣ���д���
     * ������� binds ������������ԣ����� input �� checked����Ҫ����
     *
     * ��ƽ����
     * �� text ����ֻ��һ��ʱ��Ҫô���� string��Ҫô���� interp
     * interp �п����ǰ󶨵�������Եı���ʽ����ϣ���� eval text �� string
     * ������������������ֻ��һ��ʱֱ�ӳ����
     *
     * bool���ԣ�
     * ������û��ֵʱ��Ĭ��Ϊtrue
     *
     * @param {Object} prop ���Զ���
     */
    function postProp(prop) {
        var expr = prop.expr;

        if (expr.type === 7) {
            switch (expr.segs.length) {
                case 0:
                    prop.expr = {
                        type: 3,
                        value: true
                    };
                    break;

                case 1:
                    expr = prop.expr = expr.segs[0];
                    if (expr.type === 5 && expr.filters.length === 0) {
                        prop.expr = expr.expr;
                    }
            }
        }
    }

// exports = module.exports = postProp;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��������ڵ�����
     */

// var each = require('../util/each');
// var kebab2camel = require('../util/kebab2camel');
// var ExprType = require('./expr-type');
// var createAccessor = require('./create-accessor');
// var parseExpr = require('./parse-expr');
// var parseCall = require('./parse-call');
// var parseText = require('./parse-text');
// var parseDirective = require('./parse-directive');
// var postProp = require('./post-prop');


    /**
     * ��������ڵ�����
     *
     * @param {ANode} aNode ����ڵ�
     * @param {string} name ��������
     * @param {string} value ����ֵ
     * @param {Object} options ��������
     * @param {Array?} options.delimiters ��ֵ�ָ����б�
     */
    function integrateAttr(aNode, name, value, options) {
        var prefixIndex = name.indexOf('-');
        var realName;
        var prefix;

        if (prefixIndex > 0) {
            prefix = name.slice(0, prefixIndex);
            realName = name.slice(prefixIndex + 1);
        }

        switch (prefix) {
            case 'on':
                var event = {
                    name: realName,
                    modifier: {}
                };
                aNode.events.push(event);

                var colonIndex;
                while ((colonIndex = value.indexOf(':')) > 0) {
                    var modifier = value.slice(0, colonIndex);

                    // eventHandler("dd:aa") �������������modifier����Ҫ��ʶ
                    if (!/^[a-z]+$/i.test(modifier)) {
                        break;
                    }

                    event.modifier[modifier] = true;
                    value = value.slice(colonIndex + 1);
                }

                event.expr = parseCall(value, [
                    createAccessor([
                        {type: 1, value: '$event'}
                    ])
                ]);
                break;

            case 'san':
            case 's':
                parseDirective(aNode, realName, value, options);
                break;

            case 'prop':
                integrateProp(aNode, realName, value, options);
                break;

            case 'var':
                if (!aNode.vars) {
                    aNode.vars = [];
                }

                realName = kebab2camel(realName);
                aNode.vars.push({
                    name: realName,
                    expr: parseExpr(value.replace(/(^\{\{|\}\}$)/g, ''))
                });
                break;

            default:
                integrateProp(aNode, name, value, options);
        }
    }

    /**
     * ��������ڵ������
     *
     * @inner
     * @param {ANode} aNode ����ڵ�
     * @param {string} name ��������
     * @param {string} value ����ֵ
     * @param {Object} options ��������
     * @param {Array?} options.delimiters ��ֵ�ָ����б�
     */
    function integrateProp(aNode, name, value, options) {
        // parse two way binding, e.g. value="{=ident=}"
        var xMatch = value.match(/^\{=\s*(.*?)\s*=\}$/);

        if (xMatch) {
            aNode.props.push({
                name: name,
                expr: parseExpr(xMatch[1]),
                x: 1,
                raw: value
            });

            return;
        }

        // parse normal prop
        var prop = {
            name: name,
            expr: parseText(value, options.delimiters),
            raw: value
        };

        // ���ﲻ�ܰ�ֻ��һ����ֵ�����Գ�ȡ
        // ��Ϊ��ֵ���ֵ������htmlƬ�Σ����ױ�ע��
        // ��������ݰ������initʱ����ȡ
        switch (name) {
            case 'class':
            case 'style':
                each(prop.expr.segs, function (seg) {
                    if (seg.type === 5) {
                        seg.filters.push({
                            type: 6,
                            name: createAccessor([
                                {
                                    type: 1,
                                    value: '_' + prop.name
                                }
                            ]),
                            args: []
                        });
                    }
                });
                break;

            case 'checked':
                if (aNode.tagName === 'input') {
                    postProp(prop);
                }
                break;
        }

        aNode.props.push(prop);
    }


// exports = module.exports = integrateAttr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ģ��
     */


// var createANode = require('./create-a-node');
// var Walker = require('./walker');
// var integrateAttr = require('./integrate-attr');
// var parseText = require('./parse-text');
// var svgTags = require('../browser/svg-tags');
// var autoCloseTags = require('../browser/auto-close-tags');

// #[begin] error
    function getXPath(stack, currentTagName) {
        var path = ['ROOT'];
        for (var i = 1, len = stack.length; i < len; i++) {
            path.push(stack[i].tagName);
        }
        if (currentTagName) {
            path.push(currentTagName);
        }
        return path.join('>');
    }
// #[end]

    /* eslint-disable fecs-max-statements */

    /**
     * ���� template
     *
     * @param {string} source templateԴ��
     * @param {Object?} options ��������
     * @param {string?} options.trimWhitespace �հ��ı��Ĵ������ԡ�none|blank|all
     * @param {Array?} options.delimiters ��ֵ�ָ����б�
     * @return {ANode}
     */
    function parseTemplate(source, options) {
        options = options || {};
        options.trimWhitespace = options.trimWhitespace || 'none';

        var rootNode = createANode();

        if (typeof source !== 'string') {
            return rootNode;
        }

        source = source.replace(/<!--([\s\S]*?)-->/mg, '').replace(/(^\s+|\s+$)/g, '');
        var walker = new Walker(source);

        var tagReg = /<(\/)?([a-z0-9-]+)\s*/ig;
        var attrReg = /([-:0-9a-z\[\]_]+)(\s*=\s*(['"])([^\3]*?)\3)?\s*/ig;

        var tagMatch;
        var currentNode = rootNode;
        var stack = [rootNode];
        var stackIndex = 0;
        var beforeLastIndex = 0;

        while ((tagMatch = walker.match(tagReg)) != null) {
            var tagMatchStart = walker.index - tagMatch[0].length;
            var tagEnd = tagMatch[1];
            var tagName = tagMatch[2];
            if (!svgTags[tagName]) {
                tagName = tagName.toLowerCase();
            }

            // 62: >
            // 47: /
            // ���� </xxxx >
            if (tagEnd) {
                if (walker.currentCode() === 62) {
                    // ����رձ�ǩ������ʱ���رձ�ǩ
                    // ���ϲ��ҵ���Ӧ��ǩ���Ҳ���ʱ���Թر�
                    var closeIndex = stackIndex;

                    // #[begin] error
                    // ������ڱպ�һ���Ապϵı�ǩ������ </input>������
                    if (autoCloseTags[tagName]) {
                        throw new Error(''
                            + '[SAN ERROR] ' + getXPath(stack, tagName) + ' is a `auto closed` tag, '
                            + 'so it cannot be closed with </' + tagName + '>'
                        );
                    }

                    // ����رյ� tag �͵�ǰ�򿪵Ĳ�һ�£�����
                    if (
                        stack[closeIndex].tagName !== tagName
                        // ����Ҫ�� table �Զ����� tbody �������ȥ��
                        && !(tagName === 'table' && stack[closeIndex].tagName === 'tbody')
                    ) {
                        throw new Error('[SAN ERROR] ' + getXPath(stack) + ' is closed with ' + tagName);
                    }
                    // #[end]


                    pushTextNode(source.slice(beforeLastIndex, tagMatchStart));
                    while (closeIndex > 0 && stack[closeIndex].tagName !== tagName) {
                        closeIndex--;
                    }

                    if (closeIndex > 0) {
                        stackIndex = closeIndex - 1;
                        currentNode = stack[stackIndex];
                    }
                    walker.go(1);
                }
                // #[begin] error
                else {
                    // ���� </xxx �������պϱ�ǩ

                    // ����պϱ�ǩʱ��ƥ������һ���ַ��� <������һ����ǩ�Ŀ�ʼ����ô��ǰ�պϱ�ǩδ�պ�
                    if (walker.currentCode() === 60) {
                        throw new Error(''
                            + '[SAN ERROR] ' + getXPath(stack)
                            + '\'s close tag not closed'
                        );
                    }

                    // �պϱ�ǩ������
                    throw new Error(''
                        + '[SAN ERROR] ' + getXPath(stack)
                        + '\'s close tag has attributes'
                    );
                }
                // #[end]
            }
            else {
                var aElement = createANode({
                    tagName: tagName
                });
                var tagClose = autoCloseTags[tagName];

                // ���� attributes

                /* eslint-disable no-constant-condition */
                while (1) {
                    /* eslint-enable no-constant-condition */

                    var nextCharCode = walker.currentCode();

                    // ��ǩ����ʱ���� attributes ��ȡ
                    // ��ǩ����ֱ�ӽ�����պϽ���
                    if (nextCharCode === 62) {
                        walker.go(1);
                        break;
                    }

                    // ���� /> ���պϴ���
                    if (nextCharCode === 47
                        && walker.charCode(walker.index + 1) === 62
                    ) {
                        walker.go(2);
                        tagClose = 1;
                        break;
                    }

                    // template ��������
                    // ��ʱ��˵�������ȡ���ڵ��������ݣ�����text
                    if (!nextCharCode) {
                        pushTextNode(walker.cut(beforeLastIndex));
                        aElement = null;
                        break;
                    }

                    // #[begin] error
                    // �ڴ���һ�� open ��ǩʱ����������� <�� ����һ����ǩ�Ŀ�ʼ����ǰ��ǩδ�������պϣ�����
                    if (nextCharCode === 60) {
                        throw new Error('[SAN ERROR] ' + getXPath(stack, tagName) + ' is not closed');
                    }
                    // #[end]

                    // ��ȡ attribute
                    var attrMatch = walker.match(attrReg);
                    if (attrMatch) {

                        // #[begin] error
                        // ��������� =����ûȡ�� value������
                        if (
                            walker.charCode(attrMatch.index + attrMatch[1].length) === 61
                            && !attrMatch[2]
                        ) {
                            throw new Error(''
                                + '[SAN ERROR] ' + getXPath(stack, tagName) + ' attribute `'
                                + attrMatch[1] + '` is not wrapped with ""'
                            );
                        }
                        // #[end]

                        integrateAttr(
                            aElement,
                            attrMatch[1],
                            attrMatch[2] ? attrMatch[4] : '',
                            options
                        );
                    }

                }

                if (aElement) {
                    pushTextNode(source.slice(beforeLastIndex, tagMatchStart));

                    // match if directive for else/elif directive
                    var elseDirective = aElement.directives['else'] // eslint-disable-line dot-notation
                        || aElement.directives.elif;

                    if (elseDirective) {
                        var parentChildrenLen = currentNode.children.length;

                        while (parentChildrenLen--) {
                            var parentChild = currentNode.children[parentChildrenLen];
                            if (parentChild.textExpr) {
                                currentNode.children.splice(parentChildrenLen, 1);
                                continue;
                            }

                            // #[begin] error
                            if (!parentChild.directives['if']) { // eslint-disable-line dot-notation
                                throw new Error('[SAN FATEL] else not match if.');
                            }
                            // #[end]

                            parentChild.elses = parentChild.elses || [];
                            parentChild.elses.push(aElement);

                            break;
                        }
                    }
                    else {
                        if (aElement.tagName === 'tr' && currentNode.tagName === 'table') {
                            var tbodyNode = createANode({
                                tagName: 'tbody'
                            });
                            currentNode.children.push(tbodyNode);
                            currentNode = tbodyNode;
                            stack[++stackIndex] = tbodyNode;
                        }

                        currentNode.children.push(aElement);
                    }

                    if (!tagClose) {
                        currentNode = aElement;
                        stack[++stackIndex] = aElement;
                    }
                }

            }

            beforeLastIndex = walker.index;
        }

        pushTextNode(walker.cut(beforeLastIndex));

        return rootNode;

        /**
         * �ڶ�ȡջ�������ı��ڵ�
         *
         * @inner
         * @param {string} text �ı�����
         */
        function pushTextNode(text) {
            switch (options.trimWhitespace) {
                case 'blank':
                    if (/^\s+$/.test(text)) {
                        text = null;
                    }
                    break;

                case 'all':
                    text = text.replace(/(^\s+|\s+$)/g, '');
                    break;
            }

            if (text) {
                currentNode.children.push(createANode({
                    textExpr: parseText(text, options.delimiters)
                }));
            }
        }
    }

    /* eslint-enable fecs-max-statements */

// exports = module.exports = parseTemplate;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file Ĭ��filter
     */


    /* eslint-disable fecs-camelcase */

    /**
     * Ĭ��filter
     *
     * @const
     * @type {Object}
     */
    var DEFAULT_FILTERS = {

        /**
         * URL����filter
         *
         * @param {string} source Դ��
         * @return {string} �滻�����
         */
        url: encodeURIComponent,

        _class: function (source) {
            if (source instanceof Array) {
                return source.join(' ');
            }

            return source;
        },

        _style: function (source) {
            if (typeof source === 'object') {
                var result = '';
                for (var key in source) {
                    if (source.hasOwnProperty(key)) {
                        result += key + ':' + source[key] + ';';
                    }
                }

                return result;
            }

            return source;
        },

        _sep: function (source, sep) {
            return source ? sep + source : source;
        }
    };
    /* eslint-enable fecs-camelcase */

// exports = module.exports = DEFAULT_FILTERS;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ʽ����
     */

// var ExprType = require('../parser/expr-type');
// var extend = require('../util/extend');
// var DEFAULT_FILTERS = require('./default-filters');
// var evalArgs = require('./eval-args');
// var dataCache = require('./data-cache');

    /**
     * �������ʽ��ֵ
     *
     * @param {Object} expr ����ʽ����
     * @param {Data} data ������������
     * @param {Component=} owner �����������
     * @return {*}
     */
    function evalExpr(expr, data, owner) {
        if (expr.value != null) {
            return expr.value;
        }

        var value = dataCache.get(data, expr);

        if (value == null) {
            switch (expr.type) {
                case 9:
                    value = evalExpr(expr.expr, data, owner);
                    switch (expr.operator) {
                        case 33:
                            value = !value;
                            break;

                        case 45:
                            value = 0 - value;
                            break;
                    }
                    break;

                case 8:
                    var leftValue = evalExpr(expr.segs[0], data, owner);
                    var rightValue = evalExpr(expr.segs[1], data, owner);

                    /* eslint-disable eqeqeq */
                    switch (expr.operator) {
                        case 37:
                            value = leftValue % rightValue;
                            break;
                        case 43:
                            value = leftValue + rightValue;
                            break;
                        case 45:
                            value = leftValue - rightValue;
                            break;
                        case 42:
                            value = leftValue * rightValue;
                            break;
                        case 47:
                            value = leftValue / rightValue;
                            break;
                        case 60:
                            value = leftValue < rightValue;
                            break;
                        case 62:
                            value = leftValue > rightValue;
                            break;
                        case 76:
                            value = leftValue && rightValue;
                            break;
                        case 94:
                            value = leftValue != rightValue;
                            break;
                        case 121:
                            value = leftValue <= rightValue;
                            break;
                        case 122:
                            value = leftValue == rightValue;
                            break;
                        case 123:
                            value = leftValue >= rightValue;
                            break;
                        case 155:
                            value = leftValue !== rightValue;
                            break;
                        case 183:
                            value = leftValue === rightValue;
                            break;
                        case 248:
                            value = leftValue || rightValue;
                            break;
                    }
                    /* eslint-enable eqeqeq */
                    break;

                case 10:
                    value = evalExpr(
                        expr.segs[evalExpr(expr.segs[0], data, owner) ? 1 : 2],
                        data,
                        owner
                    );
                    break;

                case 12:
                    value = [];
                    for (var i = 0, l = expr.items.length; i < l; i++) {
                        var item = expr.items[i];
                        var itemValue = evalExpr(item.expr, data, owner);

                        if (item.spread) {
                            itemValue && (value = value.concat(itemValue));
                        }
                        else {
                            value.push(itemValue);
                        }
                    }
                    break;

                case 11:
                    value = {};
                    for (var i = 0, l = expr.items.length; i < l; i++) {
                        var item = expr.items[i];
                        var itemValue = evalExpr(item.expr, data, owner);

                        if (item.spread) {
                            itemValue && extend(value, itemValue);
                        }
                        else {
                            value[evalExpr(item.name, data, owner)] = itemValue;
                        }
                    }
                    break;

                case 4:
                    value = data.get(expr);
                    break;

                case 5:
                    value = evalExpr(expr.expr, data, owner);

                    if (owner) {
                        for (var i = 0, l = expr.filters.length; i < l; i++) {
                            var filter = expr.filters[i];
                            var filterName = filter.name.paths[0].value;

                            if (owner.filters[filterName]) {
                                value = owner.filters[filterName].apply(
                                    owner,
                                    [value].concat(evalArgs(filter.args, data, owner))
                                );
                            }
                            else if (DEFAULT_FILTERS[filterName]) {
                                value = DEFAULT_FILTERS[filterName](
                                    value,
                                    filter.args[0] ? filter.args[0].value : ''
                                );
                            }
                        }
                    }

                    if (value == null) {
                        value = '';
                    }

                    break;

                case 6:
                    if (owner && expr.name.type === 4) {
                        var method = owner;
                        var pathsLen = expr.name.paths.length;

                        for (var i = 0; method && i < pathsLen; i++) {
                            method = method[evalExpr(expr.name.paths[i], data, owner)];
                        }

                        if (method) {
                            value = method.apply(owner, evalArgs(expr.args, data, owner));
                        }
                    }

                    break;

                /* eslint-disable no-redeclare */
                case 7:
                    var buf = '';
                    for (var i = 0, l = expr.segs.length; i < l; i++) {
                        var seg = expr.segs[i];
                        buf += seg.value || evalExpr(seg, data, owner);
                    }
                    return buf;
            }

            dataCache.set(data, expr, value);
        }

        return value;
    }

// exports = module.exports = evalExpr;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file Ϊ�������ü�����������ֵ
     */


// var evalExpr = require('./eval-expr');

    /**
     * Ϊ�������ü�����������ֵ
     *
     * @param {Array} args ��������ʽ�б�
     * @param {Data} data ���ݻ���
     * @param {Component} owner �������
     * @return {Array}
     */
    function evalArgs(args, data, owner) {
        var result = [];
        for (var i = 0; i < args.length; i++) {
            result.push(evalExpr(args[i], data, owner));
        }

        return result;
    }

// exports = module.exports = evalArgs;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���ݻ��������
     */



    var dataCacheSource = {};
    var dataCacheClearly = 1;

    /**
     * ���ݻ��������
     *
     * @const
     * @type {Object}
     */
    var dataCache = {
        clear: function () {
            if (!dataCacheClearly) {
                dataCacheClearly = 1;
                dataCacheSource = {};
            }
        },

        set: function (data, expr, value) {
            if (expr.raw) {
                dataCacheClearly = 0;
                (dataCacheSource[data.id] = dataCacheSource[data.id] || {})[expr.raw] = value;
            }
        },

        get: function (data, expr) {
            if (expr.raw && dataCacheSource[data.id]) {
                return dataCacheSource[data.id][expr.raw];
            }
        }
    };


// exports = module.exports = dataCache;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �Ƚϱ������ʽ��Ŀ�����ʽ֮��Ĺ�ϵ
     */

// var ExprType = require('../parser/expr-type');
// var evalExpr = require('./eval-expr');
// var each = require('../util/each');

    /**
     * �жϱ������ʽ��������ʽ֮��Ĺ�ϵ��0Ϊ��ȫû��ϵ��1Ϊ�й�ϵ
     *
     * @inner
     * @param {Object} changeExpr Ŀ�����ʽ
     * @param {Array} exprs ���Դ����ʽ
     * @param {Data} data ����ʽ�������ݻ���
     * @return {number}
     */
    function changeExprCompareExprs(changeExpr, exprs, data) {
        for (var i = 0, l = exprs.length; i < l; i++) {
            if (changeExprCompare(changeExpr, exprs[i], data)) {
                return 1;
            }
        }

        return 0;
    }

    /**
     * �Ƚϱ������ʽ��Ŀ�����ʽ֮��Ĺ�ϵ��������ͼ�����ж�
     * ��ͼ������Ҫ�������ϵ��������Ӧ�ĸ�����Ϊ
     *
     * 0: ��ȫû��ϵ
     * 1: �������ʽ��Ŀ�����ʽ��ĸ��(��a��a.b) �� ��ʾ��Ҫ��ȫ�仯
     * 2: �������ʽ��Ŀ�����ʽ���
     * >2: �������ʽ��Ŀ�����ʽ�������a.b.c��a.b
     *
     * @param {Object} changeExpr �������ʽ
     * @param {Object} expr Ҫ�Ƚϵ�Ŀ�����ʽ
     * @param {Data} data ����ʽ�������ݻ���
     * @return {number}
     */
    function changeExprCompare(changeExpr, expr, data) {
        switch (expr.type) {
            case 4:
                var paths = expr.paths;
                var pathsLen = paths.length;
                var changePaths = changeExpr.paths;
                var changeLen = changePaths.length;

                var result = 1;
                for (var i = 0; i < pathsLen; i++) {
                    var pathExpr = paths[i];
                    var pathExprValue = pathExpr.value;

                    if (pathExprValue == null && changeExprCompare(changeExpr, pathExpr, data)) {
                        return 1;
                    }

                    if (result && i < changeLen
                        /* eslint-disable eqeqeq */
                        && (pathExprValue || evalExpr(pathExpr, data)) != changePaths[i].value
                    /* eslint-enable eqeqeq */
                    ) {
                        result = 0;
                    }
                }

                if (result) {
                    result = Math.max(1, changeLen - pathsLen + 2);
                }
                return result;

            case 9:
                return changeExprCompare(changeExpr, expr.expr, data) ? 1 : 0;


            case 7:
            case 8:
            case 10:
                return changeExprCompareExprs(changeExpr, expr.segs, data);

            case 12:
            case 11:
                for (var i = 0, l = expr.items.length; i < l; i++) {
                    if (changeExprCompare(changeExpr, expr.items[i].expr, data)) {
                        return 1;
                    }
                }

                return 0;

            case 5:
                if (!changeExprCompare(changeExpr, expr.expr, data)) {
                    var filterResult;
                    each(expr.filters, function (filter) {
                        filterResult = changeExprCompareExprs(changeExpr, filter.args, data);
                        return !filterResult;
                    });

                    return filterResult ? 1 : 0;
                }

                return 1;

            case 6:
                if (changeExprCompareExprs(changeExpr, expr.name.paths, data)
                    || changeExprCompareExprs(changeExpr, expr.args, data)
                ) {
                    return 1;
                }
        }

        return 0;
    }

// exports = module.exports = changeExprCompare;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���ݱ������ö��
     */

    /**
     * ���ݱ������ö��
     *
     * @const
     * @type {Object}
     */
    var DataChangeType = {
        SET: 1,
        SPLICE: 2
    };

// exports = module.exports = DataChangeType;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����������
     */

    function lifeCycleOwnIs(name) {
        return this[name];
    }

    /* eslint-disable fecs-valid-var-jsdoc */
    /**
     * �ڵ�����������Ϣ
     *
     * @inner
     * @type {Object}
     */
    var LifeCycle = {
        start: {},

        compiled: {
            is: lifeCycleOwnIs,
            compiled: true
        },

        inited: {
            is: lifeCycleOwnIs,
            compiled: true,
            inited: true
        },

        created: {
            is: lifeCycleOwnIs,
            compiled: true,
            inited: true,
            created: true
        },

        attached: {
            is: lifeCycleOwnIs,
            compiled: true,
            inited: true,
            created: true,
            attached: true
        },

        leaving: {
            is: lifeCycleOwnIs,
            compiled: true,
            inited: true,
            created: true,
            attached: true,
            leaving: true
        },

        detached: {
            is: lifeCycleOwnIs,
            compiled: true,
            inited: true,
            created: true,
            detached: true
        },

        disposed: {
            is: lifeCycleOwnIs,
            disposed: true
        }
    };
    /* eslint-enable fecs-valid-var-jsdoc */


// exports = module.exports = LifeCycle;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ڵ�����
     */

    /**
     * �ڵ�����
     *
     * @const
     * @type {Object}
     */
    var NodeType = {
        TEXT: 1,
        IF: 2,
        FOR: 3,
        ELEM: 4,
        CMPT: 5,
        SLOT: 6,
        TPL: 7,
        LOADER: 8
    };

// exports = module.exports = NodeType;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ ANode props ��������Ӧ name ����
     */

    /**
     * ��ȡ ANode props ��������Ӧ name ����
     *
     * @param {Object} aNode ANode����
     * @param {string} name name����ƥ�䴮
     * @return {Object}
     */
    function getANodeProp(aNode, name) {
        var index = aNode.hotspot.props[name];
        if (index != null) {
            return aNode.props[index];
        }
    }

// exports = module.exports = getANodeProp;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ���Դ�������
     */

// var contains = require('../util/contains');
// var empty = require('../util/empty');
// var svgTags = require('../browser/svg-tags');
// var evalExpr = require('../runtime/eval-expr');
// var getANodeProp = require('./get-a-node-prop');
// var NodeType = require('./node-type');


    /**
     * HTML ���Ժ� DOM �������ԵĶ��ձ�
     *
     * @inner
     * @const
     * @type {Object}
     */
    var HTML_ATTR_PROP_MAP = {
        'readonly': 'readOnly',
        'cellpadding': 'cellPadding',
        'cellspacing': 'cellSpacing',
        'colspan': 'colSpan',
        'rowspan': 'rowSpan',
        'valign': 'vAlign',
        'usemap': 'useMap',
        'frameborder': 'frameBorder',
        'for': 'htmlFor'
    };

    /**
     * Ĭ�ϵ�Ԫ�ص��������õı任����
     *
     * @inner
     * @type {Object}
     */
    var defaultElementPropHandler = {
        prop: function (el, value, name, element) {
            var propName = HTML_ATTR_PROP_MAP[name] || name;
            value = value == null ? '' : value;
            // input �� type �Ǹ��������ԣ���ʵҲӦ���� setAttribute
            // ���� type ��Ӧ������ʱ��̬�ı䣬������м���������
            // ��������ֱ�ӾͲ�����
            if (propName in el) {
                el[propName] = value;
            }
            else {
                el.setAttribute(name, value);
            }

            // attribute �󶨵��� text�����Բ������ null ��������������账��
            // ���仰��˵��san �������� attribute ʱ��ʱ�޵�
            // if (value == null) {
            //     el.removeAttribute(name);
            // }
        },

        output: function (element, bindInfo, data) {
            data.set(bindInfo.expr, element.el[bindInfo.name], {
                target: {
                    id: element.id,
                    prop: bindInfo.name
                }
            });
        }
    };

    var svgPropHandler = {
        prop: function (el, value, name) {
            el.setAttribute(name, value);
        }
    };

    var boolPropHandler = {
        prop: function (el, value, name, element, prop) {
            var propName = HTML_ATTR_PROP_MAP[name] || name;
            el[propName] = !!(prop && prop.raw === ''
                || value && value !== 'false' && value !== '0');
        }
    };

    /* eslint-disable fecs-properties-quote */
    /**
     * Ĭ�ϵ��������ñ任����
     *
     * @inner
     * @type {Object}
     */
    var defaultElementPropHandlers = {
        style: {
            prop: function (el, value) {
                el.style.cssText = value;
            }
        },

        'class': { // eslint-disable-line
            prop: function (el, value) {
                el.className = value;
            }
        },

        slot: {
            prop: empty
        },

        draggable: boolPropHandler
    };
    /* eslint-enable fecs-properties-quote */

    var analInputChecker = {
        checkbox: contains,
        radio: function (a, b) {
            return a === b;
        }
    };

    function analInputCheckedState(element, value) {
        var bindValue = getANodeProp(element.aNode, 'value');
        var bindType = getANodeProp(element.aNode, 'type');

        if (bindValue && bindType) {
            var type = evalExpr(bindType.expr, element.scope, element.owner);

            if (analInputChecker[type]) {
                var bindChecked = getANodeProp(element.aNode, 'checked');
                if (bindChecked != null && !bindChecked.hintExpr) {
                    bindChecked.hintExpr = bindValue.expr;
                }

                return !!analInputChecker[type](
                    value,
                    evalExpr(bindValue.expr, element.scope, element.owner)
                );
            }
        }
    }

    var elementPropHandlers = {
        input: {
            multiple: boolPropHandler,
            checked: {
                prop: function (el, value, name, element) {
                    var state = analInputCheckedState(element, value);

                    boolPropHandler.prop(
                        el,
                        state != null ? state : value,
                        'checked',
                        element
                    );

                    // #[begin] allua
                    // ���벻�ó�������ظ���allua�ڵĴ������ִ�������汾�ᱻ����ʱ�ɵ���gzipҲ�ᴦ���ظ�����
                    // see: #378
                    if (ie && ie < 8 && !element.lifeCycle.attached) {
                        boolPropHandler.prop(
                            el,
                            state != null ? state : value,
                            'defaultChecked',
                            element
                        );
                    }
                    // #[end]
                },

                output: function (element, bindInfo, data) {
                    var el = element.el;
                    var bindValue = getANodeProp(element.aNode, 'value');
                    var bindType = getANodeProp(element.aNode, 'type') || {};

                    if (bindValue && bindType) {
                        switch (el.type.toLowerCase()) {
                            case 'checkbox':
                                data[el.checked ? 'push' : 'remove'](bindInfo.expr, el.value);
                                return;

                            case 'radio':
                                el.checked && data.set(bindInfo.expr, el.value, {
                                    target: {
                                        id: element.id,
                                        prop: bindInfo.name
                                    }
                                });
                                return;
                        }
                    }

                    defaultElementPropHandler.output(element, bindInfo, data);
                }
            },
            readonly: boolPropHandler,
            disabled: boolPropHandler,
            autofocus: boolPropHandler,
            required: boolPropHandler
        },

        option: {
            value: {
                prop: function (el, value, name, element) {
                    defaultElementPropHandler.prop(el, value, name, element);

                    if (isOptionSelected(element, value)) {
                        el.selected = true;
                    }
                }
            }
        },

        select: {
            value: {
                prop: function (el, value) {
                    el.value = value || '';
                },

                output: defaultElementPropHandler.output
            },
            readonly: boolPropHandler,
            disabled: boolPropHandler,
            autofocus: boolPropHandler,
            required: boolPropHandler
        },

        textarea: {
            readonly: boolPropHandler,
            disabled: boolPropHandler,
            autofocus: boolPropHandler,
            required: boolPropHandler
        },

        button: {
            disabled: boolPropHandler,
            autofocus: boolPropHandler,
            type: {
                prop: function (el, value) {
                    el.setAttribute('type', value || '');
                }
            }
        }
    };

    function isOptionSelected(element, value) {
        var parentSelect = element.parent;
        while (parentSelect) {
            if (parentSelect.tagName === 'select') {
                break;
            }

            parentSelect = parentSelect.parent;
        }


        if (parentSelect) {
            var selectValue = null;
            var prop;
            var expr;

            if ((prop = getANodeProp(parentSelect.aNode, 'value'))
                && (expr = prop.expr)
            ) {
                selectValue = parentSelect.nodeType === 5
                    ? evalExpr(expr, parentSelect.data, parentSelect)
                    : evalExpr(expr, parentSelect.scope, parentSelect.owner)
                    || '';
            }

            if (selectValue === value) {
                return 1;
            }
        }
    }


    /**
     * ��ȡ���Դ�������
     *
     * @param {string} tagName Ԫ��tag
     * @param {string} attrName ������
     * @return {Object}
     */
    function getPropHandler(tagName, attrName) {
        if (svgTags[tagName]) {
            return svgPropHandler;
        }

        var tagPropHandlers = elementPropHandlers[tagName];
        if (!tagPropHandlers) {
            tagPropHandlers = elementPropHandlers[tagName] = {};
        }

        var propHandler = tagPropHandlers[attrName];
        if (!propHandler) {
            propHandler = defaultElementPropHandlers[attrName] || defaultElementPropHandler;
            tagPropHandlers[attrName] = propHandler;
        }

        return propHandler;
    }

// exports = module.exports = getPropHandler;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �жϱ���Ƿ���Դ��Ԫ��
     */

    /**
     * �жϱ���Ƿ���Դ��Ԫ�أ���Դ��Ԫ��ʱ����ͼ������Ҫ���
     *
     * @param {Object} change �������
     * @param {Element} element Ԫ��
     * @param {string?} propName ����������ѡ����Ҫ��ȷ�ж��Ƿ���Դ�ڴ�����ʱ����
     * @return {boolean}
     */
    function isDataChangeByElement(change, element, propName) {
        var changeTarget = change.option.target;
        return changeTarget && changeTarget.id === element.id
            && (!propName || changeTarget.prop === propName);
    }

// exports = module.exports = isDataChangeByElement;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ڶ�����ʹ��accessor����ʽ���ҷ���
     */

// var evalExpr = require('../runtime/eval-expr');

    /**
     * �ڶ�����ʹ��accessor����ʽ���ҷ���
     *
     * @param {Object} source Դ����
     * @param {Object} nameExpr ����ʽ
     * @param {Data} data �������ݻ���
     * @return {Function}
     */
    function findMethod(source, nameExpr, data) {
        var method = source;

        for (var i = 0; method != null && i < nameExpr.paths.length; i++) {
            method = method[evalExpr(nameExpr.paths[i], data)];
        }

        return method;
    }

// exports = module.exports = findMethod;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ������
     */

// var ExprType = require('../parser/expr-type');
// var evalExpr = require('./eval-expr');
// var DataChangeType = require('./data-change-type');
// var createAccessor = require('../parser/create-accessor');
// var parseExpr = require('../parser/parse-expr');
// var guid = require('../util/guid');
// var dataCache = require('./data-cache');

    /**
     * ������
     *
     * @class
     * @param {Object?} data ��ʼ����
     * @param {Model?} parent ������������
     */
    function Data(data, parent) {
        this.id = guid();
        this.parent = parent;
        this.raw = data || {};
        this.listeners = [];
    }

// #[begin] error
// ������������ֻ�ڿ���ģʽ�¿��ã�������ģʽ�²�����
    /**
     * DataTypes ���
     */
    Data.prototype.checkDataTypes = function () {
        if (this.typeChecker) {
            this.typeChecker(this.raw);
        }
    };

    /**
     * ���� type checker
     *
     * @param  {Function} typeChecker ����У����
     */
    Data.prototype.setTypeChecker = function (typeChecker) {
        this.typeChecker = typeChecker;
    };

// #[end]

    /**
     * �������ݱ�����¼�������
     *
     * @param {Function} listener ��������
     */
    Data.prototype.listen = function (listener) {
        if (typeof listener === 'function') {
            this.listeners.push(listener);
        }
    };

    /**
     * �Ƴ����ݱ�����¼�������
     *
     * @param {Function} listener ��������
     */
    Data.prototype.unlisten = function (listener) {
        var len = this.listeners.length;
        while (len--) {
            if (!listener || this.listeners[len] === listener) {
                this.listeners.splice(len, 1);
            }
        }
    };

    /**
     * �������ݱ��
     *
     * @param {Object} change �����Ϣ����
     */
    Data.prototype.fire = function (change) {
        if (change.option.silent || change.option.silence || change.option.quiet) {
            return;
        }

        for (var i = 0; i < this.listeners.length; i++) {
            this.listeners[i].call(this, change);
        }
    };

    /**
     * ��ȡ������
     *
     * @param {string|Object?} expr ������·��
     * @param {Data?} callee ��ǰ���ݻ�ȡ�ĵ��û���
     * @return {*}
     */
    Data.prototype.get = function (expr, callee) {
        var value = this.raw;
        if (!expr) {
            return value;
        }

        expr = parseExpr(expr);

        var paths = expr.paths;
        callee = callee || this;

        value = value[paths[0].value];

        if (value == null && this.parent) {
            value = this.parent.get(expr, callee);
        }
        else {
            for (var i = 1, l = paths.length; value != null && i < l; i++) {
                value = value[paths[i].value || evalExpr(paths[i], callee)];
            }
        }

        return value;
    };


    /**
     * ���ݶ���������
     *
     * @inner
     * @param {Object|Array} source Ҫ�����Դ����
     * @param {Array} exprPaths ����·��
     * @param {*} value �������ֵ
     * @param {Data} data ��Ӧ��Data����
     * @return {*} ������������
     */
    function immutableSet(source, exprPaths, pathsStart, pathsLen, value, data) {
        if (pathsStart >= pathsLen) {
            return value;
        }

        if (source == null) {
            source = {};
        }

        var pathExpr = exprPaths[pathsStart];
        var prop = evalExpr(pathExpr, data);
        var result = source;

        if (source instanceof Array) {
            var index = +prop;
            prop = isNaN(index) ? prop : index;

            result = source.slice(0);
            result[prop] = immutableSet(source[prop], exprPaths, pathsStart + 1, pathsLen, value, data);
        }
        else if (typeof source === 'object') {
            result = {};

            for (var key in source) {
                if (key !== prop) {
                    result[key] = source[key];
                }
            }

            result[prop] = immutableSet(source[prop], exprPaths, pathsStart + 1, pathsLen, value, data);
        }

        if (pathExpr.value == null) {
            exprPaths[pathsStart] = {
                type: typeof prop === 'string' ? 1 : 2,
                value: prop
            };
        }

        return result;
    }

    /**
     * ����������
     *
     * @param {string|Object} expr ������·��
     * @param {*} value ����ֵ
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     */
    Data.prototype.set = function (expr, value, option) {
        option = option || {};

        // #[begin] error
        var exprRaw = expr;
        // #[end]

        expr = parseExpr(expr);

        // #[begin] error
        if (expr.type !== 4) {
            throw new Error('[SAN ERROR] Invalid Expression in Data set: ' + exprRaw);
        }
        // #[end]

        if (this.get(expr) === value && !option.force) {
            return;
        }

        expr = createAccessor(expr.paths.slice(0));

        dataCache.clear();
        this.raw = immutableSet(this.raw, expr.paths, 0, expr.paths.length, value, this);
        this.fire({
            type: 1,
            expr: expr,
            value: value,
            option: option
        });

        // #[begin] error
        this.checkDataTypes();
        // #[end]

    };

    /**
     * �ϲ�����������
     *
     * @param {string|Object} expr ������·��
     * @param {Object} source ���ϲ�������ֵ
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     */
    Data.prototype.merge = function (expr, source, option) {
        option = option || {};

        // #[begin] error
        var exprRaw = expr;
        // #[end]

        expr = parseExpr(expr);

        // #[begin] error
        if (expr.type !== 4) {
            throw new Error('[SAN ERROR] Invalid Expression in Data merge: ' + exprRaw);
        }

        if (typeof this.get(expr) !== 'object') {
            throw new Error('[SAN ERROR] Merge Expects a Target of Type \'object\'; got ' + typeof oldValue);
        }

        if (typeof source !== 'object') {
            throw new Error('[SAN ERROR] Merge Expects a Source of Type \'object\'; got ' + typeof source);
        }
        // #[end]

        for (var key in source) { // eslint-disable-line
            this.set(
                createAccessor(
                    expr.paths.concat(
                        [
                            {
                                type: 1,
                                value: key
                            }
                        ]
                    )
                ),
                source[key],
                option
            );
        }
    };

    /**
     * ���ڸ��º�������������
     *
     * @param {string|Object} expr ������·��
     * @param {Function} fn ���ݴ�������
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     */
    Data.prototype.apply = function (expr, fn, option) {
        // #[begin] error
        var exprRaw = expr;
        // #[end]

        expr = parseExpr(expr);

        // #[begin] error
        if (expr.type !== 4) {
            throw new Error('[SAN ERROR] Invalid Expression in Data apply: ' + exprRaw);
        }
        // #[end]

        var oldValue = this.get(expr);

        // #[begin] error
        if (typeof fn !== 'function') {
            throw new Error(
                '[SAN ERROR] Invalid Argument\'s Type in Data apply: '
                + 'Expected Function but got ' + typeof fn
            );
        }
        // #[end]

        this.set(expr, fn(oldValue), option);
    };

    /**
     * ����������splice����
     *
     * @param {string|Object} expr ������·��
     * @param {Array} args splice ���ܵĲ����б�����������Array.prototype.splice�Ĳ���һ��
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     * @return {Array} ������
     */
    Data.prototype.splice = function (expr, args, option) {
        option = option || {};
        // #[begin] error
        var exprRaw = expr;
        // #[end]

        expr = parseExpr(expr);

        // #[begin] error
        if (expr.type !== 4) {
            throw new Error('[SAN ERROR] Invalid Expression in Data splice: ' + exprRaw);
        }
        // #[end]

        var target = this.get(expr);
        var returnValue = [];

        if (target instanceof Array) {
            var index = args[0];
            var len = target.length;
            if (index > len) {
                index = len;
            }
            else if (index < 0) {
                index = len + index;
                if (index < 0) {
                    index = 0;
                }
            }

            var newArray = target.slice(0);
            returnValue = newArray.splice.apply(newArray, args);

            expr = createAccessor(expr.paths.slice(0));

            dataCache.clear();
            this.raw = immutableSet(this.raw, expr.paths, 0, expr.paths.length, newArray, this);

            this.fire({
                expr: expr,
                type: 2,
                index: index,
                deleteCount: returnValue.length,
                value: returnValue,
                insertions: args.slice(2),
                option: option
            });
        }

        // #[begin] error
        this.checkDataTypes();
        // #[end]

        return returnValue;
    };

    /**
     * ����������push����
     *
     * @param {string|Object} expr ������·��
     * @param {*} item Ҫpush��ֵ
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     * @return {number} �������length����
     */
    Data.prototype.push = function (expr, item, option) {
        var target = this.get(expr);

        if (target instanceof Array) {
            this.splice(expr, [target.length, 0, item], option);
            return target.length + 1;
        }
    };

    /**
     * ����������pop����
     *
     * @param {string|Object} expr ������·��
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     * @return {*}
     */
    Data.prototype.pop = function (expr, option) {
        var target = this.get(expr);

        if (target instanceof Array) {
            var len = target.length;
            if (len) {
                return this.splice(expr, [len - 1, 1], option)[0];
            }
        }
    };

    /**
     * ����������shift����
     *
     * @param {string|Object} expr ������·��
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     * @return {*}
     */
    Data.prototype.shift = function (expr, option) {
        return this.splice(expr, [0, 1], option)[0];
    };

    /**
     * ����������unshift����
     *
     * @param {string|Object} expr ������·��
     * @param {*} item Ҫunshift��ֵ
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     * @return {number} �������length����
     */
    Data.prototype.unshift = function (expr, item, option) {
        var target = this.get(expr);

        if (target instanceof Array) {
            this.splice(expr, [0, 0, item], option);
            return target.length + 1;
        }
    };

    /**
     * �����������Ƴ�����
     *
     * @param {string|Object} expr ������·��
     * @param {number} index Ҫ�Ƴ��������
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     */
    Data.prototype.removeAt = function (expr, index, option) {
        this.splice(expr, [index, 1], option);
    };

    /**
     * �����������Ƴ�����
     *
     * @param {string|Object} expr ������·��
     * @param {*} value Ҫ�Ƴ�����
     * @param {Object=} option ���ò���
     * @param {boolean} option.silent ��Ĭ���ã�����������¼�
     */
    Data.prototype.remove = function (expr, value, option) {
        var target = this.get(expr);

        if (target instanceof Array) {
            var len = target.length;
            while (len--) {
                if (target[len] === value) {
                    this.splice(expr, [len, 1], option);
                    break;
                }
            }
        }
    };

// exports = module.exports = Data;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ʽ�¼��ļ�������
     */


// var evalArgs = require('../runtime/eval-args');
// var findMethod = require('../runtime/find-method');
// var Data = require('../runtime/data');

    /**
     * ����ʽ�¼��ļ�������
     *
     * @param {Object} eventBind ����Ϣ����
     * @param {boolean} isComponentEvent �Ƿ�����Զ����¼�
     * @param {Data} data ���ݻ���
     * @param {Event} e �¼�����
     */
    function eventDeclarationListener(eventBind, isComponentEvent, data, e) {
        var method = findMethod(this, eventBind.expr.name, data);

        if (typeof method === 'function') {
            var scope = new Data(
                {$event: isComponentEvent ? e : e || window.event},
                data
            );
            method.apply(this, evalArgs(eventBind.expr.args, scope, this));
        }
    }

// exports = module.exports = eventDeclarationListener;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �Ƿ����������
     */

    var isBrowser = typeof window !== 'undefined';

// exports = module.exports = isBrowser;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file insertBefore �����ļ����Է�װ
     */

    /**
     * insertBefore �����ļ����Է�װ
     *
     * @param {HTMLNode} targetEl Ҫ����Ľڵ�
     * @param {HTMLElement} parentEl ��Ԫ��
     * @param {HTMLElement?} beforeEl �ڴ�Ԫ��֮ǰ����
     */
    function insertBefore(targetEl, parentEl, beforeEl) {
        if (parentEl) {
            if (beforeEl) {
                parentEl.insertBefore(targetEl, beforeEl);
            }
            else {
                parentEl.appendChild(targetEl);
            }
        }
    }

// exports = module.exports = insertBefore;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ж�Ԫ���Ƿ���������HTML
     */

// some html elements cannot set innerHTML in old ie
// see: https://msdn.microsoft.com/en-us/library/ms533897(VS.85).aspx

    /**
     * �ж�Ԫ���Ƿ���������HTML
     *
     * @param {HTMLElement} el Ҫ�жϵ�Ԫ��
     * @return {boolean}
     */
    function noSetHTML(el) {
        return /^(col|colgroup|frameset|style|table|tbody|tfoot|thead|tr|select)$/i.test(el.tagName);
    }

// exports = module.exports = noSetHTML;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ʱ�ľ�����ʾ
     */

// #[begin] error
    /**
     * ����ʱ�ľ�����ʾ
     *
     * @param {string} message ������Ϣ
     */
    function warn(message) {
        message = '[SAN WARNING] ' + message;

        /* eslint-disable no-console */
        if (typeof console === 'object' && console.warn) {
            console.warn(message);
        }
        else {
            // ��ֹ�����жϵ��ö�ջ
            setTimeout(function () {
                throw new Error(message);
            }, 0);
        }
        /* eslint-enable no-console */
    }
// #[end]

// exports = module.exports = warn;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file  ��ȡ�ڵ� stump �� comment
     */

// var noSetHTML = require('../browser/no-set-html');
// var warn = require('../util/warn');

// #[begin] error
    /**
     * ��ȡ�ڵ� stump �� comment
     *
     * @param {HTMLElement} el HTMLԪ��
     */
    function warnSetHTML(el) {
        // dont warn if not in browser runtime
        if (!(typeof window !== 'undefined' && typeof navigator !== 'undefined' && window.document)) {
            return;
        }

        // some html elements cannot set innerHTML in old ie
        // see: https://msdn.microsoft.com/en-us/library/ms533897(VS.85).aspx
        if (noSetHTML(el)) {
            warn('set html for element "' + el.tagName + '" may cause an error in old IE');
        }
    }
// #[end]

// exports = module.exports = warnSetHTML;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �ж��Ƿ����׮
     */

// #[begin] reverse
    /**
     * �ж��Ƿ����׮
     *
     * @param {HTMLElement|HTMLComment} target Ҫ�жϵ�Ԫ��
     * @param {string} type ׮����
     * @return {boolean}
     */
    function isEndStump(target, type) {
        return target.nodeType === 8 && target.data === '/s-' + type;
    }
// #[end]

// exports = module.exports = isEndStump;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ�ڵ���������е�·��
     */


// var NodeType = require('./node-type');

// #[begin] reverse
    /**
     * ��ȡ�ڵ���������е�·��
     *
     * @param {Node} node �ڵ����
     * @return {Array}
     */
    function getNodePath(node) {
        var nodePaths = [];
        var nodeParent = node;
        while (nodeParent) {
            switch (nodeParent.nodeType) {
                case 4:
                    nodePaths.unshift(nodeParent.tagName);
                    break;

                case 2:
                    nodePaths.unshift('if');
                    break;

                case 3:
                    nodePaths.unshift('for[' + nodeParent.anode.directives['for'].raw + ']'); // eslint-disable-line dot-notation
                    break;

                case 6:
                    nodePaths.unshift('slot[' + (nodeParent.name || 'default') + ']');
                    break;

                case 7:
                    nodePaths.unshift('template');
                    break;

                case 5:
                    nodePaths.unshift('component[' + (nodeParent.subTag || 'root') + ']');
                    break;

                case 1:
                    nodePaths.unshift('text');
                    break;
            }

            nodeParent = nodeParent.parent;
        }

        return nodePaths;
    }
// #[end]

// exports = module.exports = getNodePath;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file text �ڵ���
     */

// var isBrowser = require('../browser/is-browser');
// var removeEl = require('../browser/remove-el');
// var insertBefore = require('../browser/insert-before');
// var changeExprCompare = require('../runtime/change-expr-compare');
// var evalExpr = require('../runtime/eval-expr');
// var NodeType = require('./node-type');
// var warnSetHTML = require('./warn-set-html');
// var isEndStump = require('./is-end-stump');
// var getNodePath = require('./get-node-path');


    /**
     * text �ڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function TextNode(aNode, owner, scope, parent, reverseWalker) {
        this.aNode = aNode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;

        // #[begin] reverse
        if (reverseWalker) {
            var currentNode = reverseWalker.current;
            if (currentNode) {
                switch (currentNode.nodeType) {
                    case 8:
                        if (currentNode.data === 's-text') {
                            this.sel = currentNode;
                            currentNode.data = this.id;
                            reverseWalker.goNext();

                            while (1) { // eslint-disable-line
                                currentNode = reverseWalker.current;
                                if (!currentNode) {
                                    throw new Error('[SAN REVERSE ERROR] Text end flag not found. \nPaths: '
                                        + getNodePath(this).join(' > '));
                                }

                                if (isEndStump(currentNode, 'text')) {
                                    this.el = currentNode;
                                    reverseWalker.goNext();
                                    currentNode.data = this.id;
                                    break;
                                }

                                reverseWalker.goNext();
                            }
                        }
                        break;

                    case 3:
                        reverseWalker.goNext();
                        if (!this.aNode.textExpr.original) {
                            this.el = currentNode;
                        }
                        break;
                }
            }
            else {
                this.el = document.createTextNode('');
                insertBefore(this.el, reverseWalker.target, reverseWalker.current);
            }
        }
        // #[end]
    }

    TextNode.prototype.nodeType = 1;

    /**
     * ��text attach��ҳ��
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    TextNode.prototype.attach = function (parentEl, beforeEl) {
        this.content = evalExpr(this.aNode.textExpr, this.scope, this.owner);

        if (this.aNode.textExpr.original) {
            this.sel = document.createComment(this.id);
            insertBefore(this.sel, parentEl, beforeEl);

            this.el = document.createComment(this.id);
            insertBefore(this.el, parentEl, beforeEl);

            var tempFlag = document.createElement('script');
            parentEl.insertBefore(tempFlag, this.el);
            tempFlag.insertAdjacentHTML('beforebegin', this.content);
            parentEl.removeChild(tempFlag);
        }
        else {
            this.el = document.createTextNode(this.content);
            insertBefore(this.el, parentEl, beforeEl);
        }
    };

    /**
     * ���� text �ڵ�
     *
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     */
    TextNode.prototype.dispose = function (noDetach) {
        if (!noDetach) {
            removeEl(this.el);
            removeEl(this.sel);
        }

        this.el = null;
        this.sel = null;
    };

    var textUpdateProp = isBrowser
        && (typeof document.createTextNode('').textContent === 'string'
            ? 'textContent'
            : 'data');

    /**
     * ���� text �ڵ����ͼ
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    TextNode.prototype._update = function (changes) {
        if (this.aNode.textExpr.value) {
            return;
        }

        var len = changes ? changes.length : 0;
        while (len--) {
            if (changeExprCompare(changes[len].expr, this.aNode.textExpr, this.scope)) {
                var text = evalExpr(this.aNode.textExpr, this.scope, this.owner);

                if (text !== this.content) {
                    this.content = text;

                    if (this.aNode.textExpr.original) {
                        var startRemoveEl = this.sel.nextSibling;
                        var parentEl = this.el.parentNode;

                        while (startRemoveEl !== this.el) {
                            var removeTarget = startRemoveEl;
                            startRemoveEl = startRemoveEl.nextSibling;
                            removeEl(removeTarget);
                        }

                        // #[begin] error
                        warnSetHTML(parentEl);
                        // #[end]

                        var tempFlag = document.createElement('script');
                        parentEl.insertBefore(tempFlag, this.el);
                        tempFlag.insertAdjacentHTML('beforebegin', text);
                        parentEl.removeChild(tempFlag);
                    }
                    else {
                        this.el[textUpdateProp] = text;
                    }
                }

                return;
            }
        }
    };

// exports = module.exports = TextNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �жϱ�������Ƿ�Ӱ�쵽��������ժҪ
     */


    /**
     * �жϱ�������Ƿ�Ӱ�쵽��������ժҪ
     *
     * @param {Array} changes �������
     * @param {Object} dataRef ��������ժҪ
     * @return {boolean}
     */
    function changesIsInDataRef(changes, dataRef) {
        for (var i = 0; i < changes.length; i++) {
            var change = changes[i];

            if (!change.overview) {
                var paths = change.expr.paths;
                change.overview = paths[0].value;

                if (paths.length > 1) {
                    change.extOverview = paths[0].value + '.' + paths[1].value;
                    change.wildOverview = paths[0].value + '.*';
                }
            }

            if (dataRef[change.overview]
                || change.wildOverview && dataRef[change.wildOverview]
                || change.extOverview && dataRef[change.extOverview]
            ) {
                return true;
            }
        }
    }

// exports = module.exports = changesIsInDataRef;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file Ԫ���ӽڵ����������
     */

// var removeEl = require('../browser/remove-el');

// #[begin] reverse
    /**
     * Ԫ���ӽڵ����������
     *
     * @inner
     * @class
     * @param {HTMLElement} el Ҫ������Ԫ��
     */
    function DOMChildrenWalker(el) {
        this.raw = [];
        this.index = 0;
        this.target = el;

        var child = el.firstChild;
        var next;
        while (child) {
            next = child.nextSibling;

            switch (child.nodeType) {
                case 3:
                    if (/^\s*$/.test(child.data || child.textContent)) {
                        removeEl(child);
                    }
                    else {
                        this.raw.push(child);
                    }
                    break;

                case 1:
                case 8:
                    this.raw.push(child);
            }

            child = next;
        }

        this.current = this.raw[this.index];
        this.next = this.raw[this.index + 1];
    }

    /**
     * ������һ��Ԫ��
     */
    DOMChildrenWalker.prototype.goNext = function () {
        this.current = this.raw[++this.index];
        this.next = this.raw[this.index + 1];
    };
// #[end]

// exports = module.exports = DOMChildrenWalker;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file Ԫ�ؽڵ���
     */


// var guid = require('../util/guid');
// var removeEl = require('../browser/remove-el');
// var changeExprCompare = require('../runtime/change-expr-compare');
// var changesIsInDataRef = require('../runtime/changes-is-in-data-ref');
// var evalExpr = require('../runtime/eval-expr');
// var LifeCycle = require('./life-cycle');
// var NodeType = require('./node-type');
// var reverseElementChildren = require('./reverse-element-children');
// var isDataChangeByElement = require('./is-data-change-by-element');
// var getPropHandler = require('./get-prop-handler');
// var elementUpdateChildren = require('./element-update-children');
// var elementOwnCreate = require('./element-own-create');
// var elementOwnAttach = require('./element-own-attach');
// var elementOwnDetach = require('./element-own-detach');
// var elementOwnDispose = require('./element-own-dispose');
// var elementOwnOnEl = require('./element-own-on-el');
// var elementOwnToPhase = require('./element-own-to-phase');
// var elementOwnAttached = require('./element-own-attached');
// var elementDispose = require('./element-dispose');
// var elementInitTagName = require('./element-init-tag-name');
// var nodeSBindInit = require('./node-s-bind-init');
// var nodeSBindUpdate = require('./node-s-bind-update');
// var handleProp = require('./handle-prop');
// var warnSetHTML = require('./warn-set-html');
// var getNodePath = require('./get-node-path');

    /**
     * Ԫ�ؽڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function Element(aNode, owner, scope, parent, reverseWalker) {
        this.aNode = aNode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;

        this.lifeCycle = LifeCycle.start;
        this.children = [];
        this._elFns = [];
        this.parentComponent = parent.nodeType === 5
            ? parent
            : parent.parentComponent;

        this.id = guid();

        elementInitTagName(this);

        nodeSBindInit(this, aNode.directives.bind);

        this._toPhase('inited');

        // #[begin] reverse
        if (reverseWalker) {
            var currentNode = reverseWalker.current;

            if (!currentNode) {
                throw new Error('[SAN REVERSE ERROR] Element not found. \nPaths: '
                    + getNodePath(this).join(' > '));
            }

            if (currentNode.nodeType !== 1) {
                throw new Error('[SAN REVERSE ERROR] Element type not match, expect 1 but '
                    + currentNode.nodeType + '.\nPaths: '
                    + getNodePath(this).join(' > '));
            }

            if (currentNode.tagName.toLowerCase() !== this.tagName) {
                throw new Error('[SAN REVERSE ERROR] Element tagName not match, expect '
                    + this.tagName + ' but meat ' + currentNode.tagName.toLowerCase() + '.\nPaths: '
                    + getNodePath(this).join(' > '));
            }

            this.el = currentNode;
            reverseWalker.goNext();

            reverseElementChildren(this);

            this._attached();
        }
        // #[end]
    }



    Element.prototype.nodeType = 4;


    Element.prototype.attach = elementOwnAttach;
    Element.prototype.detach = elementOwnDetach;
    Element.prototype.dispose = elementOwnDispose;
    Element.prototype._create = elementOwnCreate;
    Element.prototype._toPhase = elementOwnToPhase;
    Element.prototype._onEl = elementOwnOnEl;

    Element.prototype._doneLeave = function () {
        if (this.leaveDispose) {
            if (!this.lifeCycle.disposed) {
                elementDispose(
                    this,
                    this.disposeNoDetach,
                    this.disposeNoTransition
                );
            }
        }
        else if (this.lifeCycle.attached) {
            removeEl(this.el);
            this._toPhase('detached');
        }
    };

    /**
     * ��ͼ����
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    Element.prototype._update = function (changes) {
        if (!changesIsInDataRef(changes, this.aNode.hotspot.data)) {
            return;
        }

        // update s-bind
        var me = this;
        nodeSBindUpdate(
            this,
            this.aNode.directives.bind,
            changes,
            function (name, value) {
                if (name in me.aNode.hotspot.props) {
                    return;
                }

                getPropHandler(me.tagName, name).prop(me.el, value, name, me);
            }
        );

        // update prop
        var dynamicProps = this.aNode.hotspot.dynamicProps;
        for (var i = 0, l = dynamicProps.length; i < l; i++) {
            var prop = dynamicProps[i];

            for (var j = 0, changeLen = changes.length; j < changeLen; j++) {
                var change = changes[j];

                if (!isDataChangeByElement(change, this, prop.name)
                    && (
                        changeExprCompare(change.expr, prop.expr, this.scope)
                        || prop.hintExpr && changeExprCompare(change.expr, prop.hintExpr, this.scope)
                    )
                ) {
                    handleProp(this, evalExpr(prop.expr, this.scope, this.owner), prop);
                    break;
                }
            }
        }

        // update content
        var htmlDirective = this.aNode.directives.html;
        if (htmlDirective) {
            var len = changes.length;
            while (len--) {
                if (changeExprCompare(changes[len].expr, htmlDirective.value, this.scope)) {
                    // #[begin] error
                    warnSetHTML(this.el);
                    // #[end]

                    this.el.innerHTML = evalExpr(htmlDirective.value, this.scope, this.owner);
                    break;
                }
            }
        }
        else {
            elementUpdateChildren(this.children, changes);
        }
    };

    /**
     * ִ�����attached״̬����Ϊ
     */
    Element.prototype._attached = elementOwnAttached;

// exports = module.exports = Element;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���ٽڵ㣬��սڵ��ϵ����ó�Ա
     */


    /**
     * ���ٽڵ�
     *
     * @param {Object} node �ڵ����
     */
    function nodeDispose(node) {
        node.el = null;
        node.sel = null;
        node.owner = null;
        node.scope = null;
        node.aNode = null;
        node.parent = null;
        node.parentComponent = null;
        node.children = null;

        if (node._toPhase) {
            node._toPhase('disposed');
        }

        if (node._ondisposed) {
            node._ondisposed();
        }
    }

// exports = module.exports = nodeDispose;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ʼ���ڵ�� s-bind ����
     */


// var evalExpr = require('../runtime/eval-expr');

    /**
     * ��ʼ���ڵ�� s-bind ����
     *
     * @param {Object} node �ڵ����
     * @param {Object} sBind bindָ�����
     * @return {boolean}
     */
    function nodeSBindInit(node, sBind) {
        if (sBind && node.scope) {
            node._sbindData = evalExpr(sBind.value, node.scope, node.owner);
            return true;
        }
    }

// exports = module.exports = nodeSBindInit;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ������������ key �Ĳ���
     */

    /**
     * ������������ key �Ĳ���
     *
     * @param {Object} obj1 Ŀ�����
     * @param {Object} obj2 Դ����
     * @return {Array}
     */
    function unionKeys(obj1, obj2) {
        var result = [];

        for (var key in obj1) {
            if (obj1.hasOwnProperty(key)) {
                result.push(key);
            }
        }

        for (var key in obj2) {
            if (obj2.hasOwnProperty(key)) {
                !obj1[key] && result.push(key);
            }
        }

        return result;
    }

// exports = module.exports = unionKeys;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���½ڵ�� s-bind ����
     */

// var unionKeys = require('../util/union-keys');
// var evalExpr = require('../runtime/eval-expr');
// var changeExprCompare = require('../runtime/change-expr-compare');

    /**
     * ��ʼ���ڵ�� s-bind ����
     *
     * @param {Object} node �ڵ����
     * @param {Object} sBind bindָ�����
     * @param {Array} changes �������
     * @param {Function} updater �󶨶����������ĸ��º���
     */
    function nodeSBindUpdate(node, sBind, changes, updater) {
        if (sBind) {
            var len = changes.length;

            while (len--) {
                if (changeExprCompare(changes[len].expr, sBind.value, node.scope)) {
                    var newBindData = evalExpr(sBind.value, node.scope, node.owner);
                    var keys = unionKeys(newBindData, node._sbindData);

                    for (var i = 0, l = keys.length; i < l; i++) {
                        var key = keys[i];
                        var value = newBindData[key];

                        if (value !== node._sbindData[key]) {
                            updater(key, value);
                        }
                    }

                    node._sbindData = newBindData;
                    break;
                }

            }
        }
    }

// exports = module.exports = nodeSBindUpdate;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ͨ��������ⴴ���ڵ�Ĺ�������
     */

// var NodeType = require('./node-type');
// var TextNode = require('./text-node');
// var Element = require('./element');
// var SlotNode = require('./slot-node');
// var ForNode = require('./for-node');
// var IfNode = require('./if-node');
// var TemplateNode = require('./template-node');

// #[begin] reverse
    /**
     * ͨ��������ⴴ���ڵ�
     *
     * @param {ANode} aNode ����ڵ�
     * @param {DOMChildrenWalker} reverseWalker ��Ԫ�ر�������
     * @param {Node} parent ���׽ڵ�
     * @param {Model=} scope �������ݻ���
     * @return {Node}
     */
    function createReverseNode(aNode, reverseWalker, parent, scope) {
        var parentIsComponent = parent.nodeType === 5;
        var owner = parentIsComponent ? parent : (parent.childOwner || parent.owner);
        scope = scope || (parentIsComponent ? parent.data : (parent.childScope || parent.scope));

        if (aNode.textExpr) {
            return new TextNode(aNode, owner, scope, parent, reverseWalker);
        }

        if (aNode.directives['if']) { // eslint-disable-line dot-notation
            return new IfNode(aNode, owner, scope, parent, reverseWalker);
        }

        if (aNode.directives['for']) { // eslint-disable-line dot-notation
            return new ForNode(aNode, owner, scope, parent, reverseWalker);
        }

        switch (aNode.tagName) {
            case 'slot':
                return new SlotNode(aNode, owner, scope, parent, reverseWalker);

            case 'template':
                return new TemplateNode(aNode, owner, scope, parent, reverseWalker);

            default:
                var ComponentOrLoader = owner.getComponentType
                    ? owner.getComponentType(aNode)
                    : owner.components[aNode.tagName];

                if (ComponentOrLoader) {
                    return typeof ComponentOrLoader === 'function'
                        ? new ComponentOrLoader({
                            source: aNode,
                            owner: owner,
                            scope: scope,
                            parent: parent,
                            subTag: aNode.tagName,
                            reverseWalker: reverseWalker
                        })
                        : new AsyncComponent({
                            source: aNode,
                            owner: owner,
                            scope: scope,
                            parent: parent,
                            subTag: aNode.tagName,
                            reverseWalker: reverseWalker
                        }, ComponentOrLoader);
                }
        }

        return new Element(aNode, owner, scope, parent, reverseWalker);
    }
// #[end]

// exports = module.exports = createReverseNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ͷ�Ԫ�ص���Ԫ��
     */

    /**
     * �����ͷ�Ԫ�ص���Ԫ��
     *
     * @param {Array=} children ��Ԫ������
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     * @param {boolean=} noTransition �Ƿ���ʾ���ɶ���Ч��
     */
    function elementDisposeChildren(children, noDetach, noTransition) {
        var len = children && children.length;
        while (len--) {
            children[len].dispose(noDetach, noTransition);
        }
    }

// exports = module.exports = elementDisposeChildren;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Ԫ�ص���Ԫ����ͼ
     */


    /**
     * ����Ԫ�ص���Ԫ����ͼ
     *
     * @param {Array} children ��Ԫ���б�
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    function elementUpdateChildren(children, changes) {
        for (var i = 0, l = children.length; i < l; i++) {
            children[i]._update(changes);
        }
    }

// exports = module.exports = elementUpdateChildren;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ʹԪ�ؽڵ㵽����Ӧ����������
     */


// var LifeCycle = require('./life-cycle');

    /**
     * ʹԪ�ؽڵ㵽����Ӧ����������
     *
     * @param {string} name ������������
     */
    function elementOwnToPhase(name) {
        this.lifeCycle = LifeCycle[name] || this.lifeCycle;
    }

// exports = module.exports = elementOwnToPhase;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ڵ�Ĺ�������
     */

// var NodeType = require('./node-type');
// var TextNode = require('./text-node');
// var Element = require('./element');
// var SlotNode = require('./slot-node');
// var ForNode = require('./for-node');
// var IfNode = require('./if-node');
// var TemplateNode = require('./template-node');
// var AsyncComponent = require('./async-component');


    /**
     * �����ڵ�
     *
     * @param {ANode} aNode ����ڵ�
     * @param {Node} parent ���׽ڵ�
     * @param {Model=} scope �������ݻ���
     * @return {Node}
     */
    function createNode(aNode, parent, scope) {
        var parentIsComponent = parent.nodeType === 5;
        var owner = parentIsComponent ? parent : (parent.childOwner || parent.owner);
        scope = scope || (parentIsComponent ? parent.data : (parent.childScope || parent.scope));


        if (aNode.textExpr) {
            return new TextNode(aNode, owner, scope, parent);
        }

        if (aNode.directives['if']) { // eslint-disable-line dot-notation
            return new IfNode(aNode, owner, scope, parent);
        }

        if (aNode.directives['for']) { // eslint-disable-line dot-notation
            return new ForNode(aNode, owner, scope, parent);
        }

        switch (aNode.tagName) {
            case 'slot':
                return new SlotNode(aNode, owner, scope, parent);

            case 'template':
                return new TemplateNode(aNode, owner, scope, parent);

            default:
                var ComponentOrLoader = owner.getComponentType
                    ? owner.getComponentType(aNode)
                    : owner.components[aNode.tagName];

                if (ComponentOrLoader) {
                    return typeof ComponentOrLoader === 'function'
                        ? new ComponentOrLoader({
                            source: aNode,
                            owner: owner,
                            scope: scope,
                            parent: parent,
                            subTag: aNode.tagName
                        })
                        : new AsyncComponent({
                            source: aNode,
                            owner: owner,
                            scope: scope,
                            parent: parent,
                            subTag: aNode.tagName
                        }, ComponentOrLoader);
                }
        }

        return new Element(aNode, owner, scope, parent);
    }

// exports = module.exports = createNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ������Ԫ��
     */

// var createNode = require('./create-node');

    /**
     * ������Ԫ��
     *
     * @param {Element} element Ԫ��
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    function genElementChildren(element, parentEl, beforeEl) {
        parentEl = parentEl || element.el;

        var aNodeChildren = element.aNode.children;
        for (var i = 0; i < aNodeChildren.length; i++) {
            var child = createNode(aNodeChildren[i], element);
            element.children.push(child);
            child.attach(parentEl, beforeEl);
        }
    }

// exports = module.exports = genElementChildren;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��û�� root ֻ�� children ��Ԫ�� attach ��ҳ��
     */


// var insertBefore = require('../browser/insert-before');
// var genElementChildren = require('./gen-element-children');


    /**
     * ��û�� root ֻ�� children ��Ԫ�� attach ��ҳ��
     * ��Ҫ���� slot �� template
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    function nodeOwnOnlyChildrenAttach(parentEl, beforeEl) {
        this.sel = document.createComment(this.id);
        insertBefore(this.sel, parentEl, beforeEl);

        genElementChildren(this, parentEl, beforeEl);

        this.el = document.createComment(this.id);
        insertBefore(this.el, parentEl, beforeEl);

        this._toPhase('attached');
    }

// exports = module.exports = nodeOwnOnlyChildrenAttach;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file slot �ڵ���
     */

// var each = require('../util/each');
// var guid = require('../util/guid');
// var extend = require('../util/extend');
// var createANode = require('../parser/create-a-node');
// var ExprType = require('../parser/expr-type');
// var createAccessor = require('../parser/create-accessor');
// var evalExpr = require('../runtime/eval-expr');
// var Data = require('../runtime/data');
// var DataChangeType = require('../runtime/data-change-type');
// var changeExprCompare = require('../runtime/change-expr-compare');
// var insertBefore = require('../browser/insert-before');
// var removeEl = require('../browser/remove-el');
// var NodeType = require('./node-type');
// var LifeCycle = require('./life-cycle');
// var getANodeProp = require('./get-a-node-prop');
// var nodeDispose = require('./node-dispose');
// var nodeSBindInit = require('./node-s-bind-init');
// var nodeSBindUpdate = require('./node-s-bind-update');
// var createReverseNode = require('./create-reverse-node');
// var elementDisposeChildren = require('./element-dispose-children');
// var elementUpdateChildren = require('./element-update-children');
// var elementOwnToPhase = require('./element-own-to-phase');
// var nodeOwnOnlyChildrenAttach = require('./node-own-only-children-attach');


    /**
     * slot �ڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function SlotNode(aNode, owner, scope, parent, reverseWalker) {
        var realANode = createANode();
        this.aNode = realANode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;
        this.parentComponent = parent.nodeType === 5
            ? parent
            : parent.parentComponent;

        this.id = guid();

        this.lifeCycle = LifeCycle.start;
        this.children = [];

        // calc slot name
        this.nameBind = getANodeProp(aNode, 'name');
        if (this.nameBind) {
            this.isNamed = true;
            this.name = evalExpr(this.nameBind.expr, this.scope, this.owner);
        }

        // calc aNode children
        var sourceSlots = owner.sourceSlots;
        var matchedSlots;
        if (sourceSlots) {
            matchedSlots = this.isNamed ? sourceSlots.named[this.name] : sourceSlots.noname;
        }

        if (matchedSlots) {
            this.isInserted = true;
        }

        realANode.children = matchedSlots || aNode.children.slice(0);

        // calc scoped slot vars
        realANode.vars = aNode.vars;
        realANode.directives = aNode.directives;

        var initData;
        if (nodeSBindInit(this, aNode.directives.bind)) {
            initData = extend({}, this._sbindData);
        }

        if (realANode.vars) {
            initData = initData || {};
            each(realANode.vars, function (varItem) {
                initData[varItem.name] = evalExpr(varItem.expr, scope, owner);
            });
        }

        // child owner & child scope
        if (this.isInserted) {
            this.childOwner = owner.owner;
            this.childScope = owner.scope;
        }

        if (initData) {
            this.isScoped = true;
            this.childScope = new Data(initData, this.childScope || this.scope);
        }


        owner.slotChildren.push(this);

        // #[begin] reverse
        if (reverseWalker) {

            this.sel = document.createComment(this.id);
            insertBefore(this.sel, reverseWalker.target, reverseWalker.current);

            var me = this;
            each(this.aNode.children, function (aNodeChild) {
                me.children.push(createReverseNode(aNodeChild, reverseWalker, me));
            });

            this.el = document.createComment(this.id);
            insertBefore(this.el, reverseWalker.target, reverseWalker.current);

            this._toPhase('attached');
        }
        // #[end]
    }

    SlotNode.prototype.nodeType = 6;

    /**
     * �����ͷ� slot
     *
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     * @param {boolean=} noTransition �Ƿ���ʾ���ɶ���Ч��
     */
    SlotNode.prototype.dispose = function (noDetach, noTransition) {
        this.childOwner = null;
        this.childScope = null;

        elementDisposeChildren(this.children, noDetach, noTransition);

        if (!noDetach) {
            removeEl(this.el);
            removeEl(this.sel);
        }
        nodeDispose(this);
    };

    SlotNode.prototype.attach = nodeOwnOnlyChildrenAttach;
    SlotNode.prototype._toPhase = elementOwnToPhase;

    /**
     * ��ͼ���º���
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     * @param {boolean=} isFromOuter �仯��Ϣ�Ƿ���Դ�ڸ����֮������
     * @return {boolean}
     */
    SlotNode.prototype._update = function (changes, isFromOuter) {
        var me = this;

        if (this.nameBind && evalExpr(this.nameBind.expr, this.scope, this.owner) !== this.name) {
            this.owner._notifyNeedReload();
            return false;
        }

        if (isFromOuter) {
            if (this.isInserted) {
                elementUpdateChildren(this.children, changes);
            }
        }
        else {
            if (this.isScoped) {
                var varKeys = {};
                each(this.aNode.vars, function (varItem) {
                    varKeys[varItem.name] = 1;
                    me.childScope.set(varItem.name, evalExpr(varItem.expr, me.scope, me.owner));
                });

                var scopedChanges = [];

                nodeSBindUpdate(
                    this,
                    this.aNode.directives.bind,
                    changes,
                    function (name, value) {
                        if (varKeys[name]) {
                            return;
                        }

                        me.childScope.set(name, value);
                        scopedChanges.push({
                            type: 1,
                            expr: createAccessor([
                                {type: 1, value: name}
                            ]),
                            value: value,
                            option: {}
                        });
                    }
                );

                each(changes, function (change) {
                    if (!me.isInserted) {
                        scopedChanges.push(change);
                    }

                    each(me.aNode.vars, function (varItem) {
                        var name = varItem.name;
                        var relation = changeExprCompare(change.expr, varItem.expr, me.scope);

                        if (relation < 1) {
                            return;
                        }

                        if (change.type !== 2) {
                            scopedChanges.push({
                                type: 1,
                                expr: createAccessor([
                                    {type: 1, value: name}
                                ]),
                                value: me.childScope.get(name),
                                option: change.option
                            });
                        }
                        else if (relation === 2) {
                            scopedChanges.push({
                                expr: createAccessor([
                                    {type: 1, value: name}
                                ]),
                                type: 2,
                                index: change.index,
                                deleteCount: change.deleteCount,
                                value: change.value,
                                insertions: change.insertions,
                                option: change.option
                            });
                        }
                    });
                });

                elementUpdateChildren(this.children, scopedChanges);
            }
            else if (!this.isInserted) {
                elementUpdateChildren(this.children, changes);
            }
        }
    };

// exports = module.exports = SlotNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����ָ��϶���
     */

    /**
     * ����ָ��϶���
     *
     * @param {Object} source Ҫ���Ƶ�ָ��϶���
     * @param {Object=} excludes ��Ҫ�ų���key����
     * @return {Object}
     */
    function cloneDirectives(source, excludes) {
        var result = {};
        excludes = excludes || {};

        for (var key in source) {
            if (!excludes[key]) {
                result[key] = source[key];
            }
        }

        return result;
    }

// exports = module.exports = cloneDirectives;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ִ�����ٽڵ����Ϊ
     */

// var removeEl = require('../browser/remove-el');
// var nodeDispose = require('./node-dispose');
// var elementDisposeChildren = require('./element-dispose-children');

    /**
     * ��ִ�����ٽڵ����Ϊ
     *
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     */
    function nodeOwnSimpleDispose(noDetach) {
        elementDisposeChildren(this.children, noDetach, 1);

        if (!noDetach) {
            removeEl(this.el);
        }

        nodeDispose(this);
    }

// exports = module.exports = nodeOwnSimpleDispose;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ڵ��Ӧ�� stump comment Ԫ��
     */



    /**
     * �����ڵ��Ӧ�� stump comment ��Ԫ��
     */
    function nodeOwnCreateStump() {
        this.el = this.el || document.createComment(this.id);
    }

// exports = module.exports = nodeOwnCreateStump;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file for ָ��ڵ���
     */

// var inherits = require('../util/inherits');
// var each = require('../util/each');
// var guid = require('../util/guid');
// var createANode = require('../parser/create-a-node');
// var ExprType = require('../parser/expr-type');
// var parseExpr = require('../parser/parse-expr');
// var createAccessor = require('../parser/create-accessor');
// var cloneDirectives = require('../parser/clone-directives');
// var Data = require('../runtime/data');
// var DataChangeType = require('../runtime/data-change-type');
// var changeExprCompare = require('../runtime/change-expr-compare');
// var evalExpr = require('../runtime/eval-expr');
// var changesIsInDataRef = require('../runtime/changes-is-in-data-ref');
// var insertBefore = require('../browser/insert-before');
// var NodeType = require('./node-type');
// var createNode = require('./create-node');
// var createReverseNode = require('./create-reverse-node');
// var nodeOwnSimpleDispose = require('./node-own-simple-dispose');
// var nodeOwnCreateStump = require('./node-own-create-stump');
// var dataCache = require('../runtime/data-cache');


    /**
     * ѭ���������������
     *
     * @inner
     * @class
     * @param {Object} forElement forԪ�ض���
     * @param {*} item ��ǰ�������
     * @param {number} index ��ǰ�������
     */
    function ForItemData(forElement, item, index) {
        this.id = guid();
        this.parent = forElement.scope;
        this.raw = {};
        this.listeners = [];

        this.directive = forElement.aNode.directives['for']; // eslint-disable-line dot-notation
        this.raw[this.directive.item.raw] = item;
        this.raw[this.directive.index.raw] = index;
    }

    /**
     * �����ݲ����ı���ʽ��ת����Ϊ��parent���ݲ����ı���ʽ
     * ��Ҫ�Ƕ�item��index���д���
     *
     * @param {Object} expr ����ʽ
     * @return {Object}
     */
    ForItemData.prototype.exprResolve = function (expr) {
        var directive = this.directive;
        var me = this;

        function resolveItem(expr) {
            if (expr.type === 4
                && expr.paths[0].value === directive.item.paths[0].value
            ) {
                return createAccessor(
                    directive.value.paths.concat(
                        {
                            type: 2,
                            value: me.get(directive.index)
                        },
                        expr.paths.slice(1)
                    )
                );
            }

            return expr;
        }

        expr = resolveItem(expr);

        var resolvedPaths = [];

        each(expr.paths, function (item) {
            resolvedPaths.push(
                item.type === 4
                && item.paths[0].value === directive.index.paths[0].value
                    ? {
                        type: 2,
                        value: me.get(directive.index)
                    }
                    : resolveItem(item)
            );
        });

        return createAccessor(resolvedPaths);
    };

// �������ݲ�������
    inherits(ForItemData, Data);
    each(
        ['set', 'remove', 'unshift', 'shift', 'push', 'pop', 'splice'],
        function (method) {
            ForItemData.prototype['_' + method] = Data.prototype[method];
            ForItemData.prototype[method] = function (expr) {
                expr = this.exprResolve(parseExpr(expr));
                dataCache.clear();
                this.parent[method].apply(
                    this.parent,
                    [expr].concat(Array.prototype.slice.call(arguments, 1))
                );
            };
        }
    );

    /**
     * ���� for ָ��Ԫ�ص���Ԫ��
     *
     * @inner
     * @param {ForDirective} forElement for ָ��Ԫ�ض���
     * @param {*} item ��Ԫ�ض�Ӧ����
     * @param {number} index ��Ԫ�ض�Ӧ���
     * @return {Element}
     */
    function createForDirectiveChild(forElement, item, index) {
        var itemScope = new ForItemData(forElement, item, index);
        return createNode(forElement.itemANode, forElement, itemScope);
    }

    /**
     * for ָ��ڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function ForNode(aNode, owner, scope, parent, reverseWalker) {
        this.aNode = aNode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;
        this.parentComponent = parent.nodeType === 5
            ? parent
            : parent.parentComponent;

        this.id = guid();
        this.children = [];

        this.itemANode = createANode({
            children: aNode.children,
            props: aNode.props,
            events: aNode.events,
            tagName: aNode.tagName,
            vars: aNode.vars,
            hotspot: aNode.hotspot,
            directives: cloneDirectives(aNode.directives, {
                'for': 1
            })
        });

        this.param = aNode.directives['for']; // eslint-disable-line dot-notation

        // #[begin] reverse
        if (reverseWalker) {
            var me = this;
            this.listData = evalExpr(this.param.value, this.scope, this.owner);
            eachForData(
                this,
                function (item, i) {
                    var itemScope = new ForItemData(me, item, i);
                    var child = createReverseNode(me.itemANode, reverseWalker, me, itemScope);
                    me.children.push(child);
                }
            );

            this._create();
            insertBefore(this.el, reverseWalker.target, reverseWalker.current);
        }
        // #[end]
    }


    ForNode.prototype.nodeType = 3;
    ForNode.prototype._create = nodeOwnCreateStump;
    ForNode.prototype.dispose = nodeOwnSimpleDispose;

    /**
     * �� for �ڵ����ݽ��б���
     *
     * @inner
     * @param {ForNode} forNode for�ڵ����
     * @param {Function} fn ���ݱ�������
     */
    function eachForData(forNode, fn) {
        var listData = forNode.listData;

        if (listData instanceof Array) {
            for (var i = 0; i < listData.length; i++) {
                fn(listData[i], i);
            }
        }
        else if (listData && typeof listData === 'object') {
            for (var i in listData) {
                if (listData.hasOwnProperty(i)) {
                    (listData[i] != null) && fn(listData[i], i);
                }
            }
        }
    }

    /**
     * ��Ԫ��attach��ҳ�����Ϊ
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    ForNode.prototype.attach = function (parentEl, beforeEl) {
        this._create();
        insertBefore(this.el, parentEl, beforeEl);
        this.listData = evalExpr(this.param.value, this.scope, this.owner);

        this._createChildren();
    };

    /**
     * ������Ԫ��
     */
    ForNode.prototype._createChildren = function () {
        var me = this;
        var parentEl = this.el.parentNode;

        eachForData(this, function (value, i) {
            var child = createForDirectiveChild(me, value, i);
            me.children.push(child);
            child.attach(parentEl, me.el);
        });
    };

    /* eslint-disable fecs-max-statements */

    /**
     * ��ͼ���º���
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    ForNode.prototype._update = function (changes) {
        var listData = evalExpr(this.param.value, this.scope, this.owner);
        var oldIsArr = this.listData instanceof Array;
        var newIsArr = listData instanceof Array;

        if (this.children.length) {
            if (!listData || newIsArr && listData.length === 0) {
                this._disposeChildren();
                this.listData = listData;
                return;
            }

            // ������ô����
            // ���Ƽ�ʹ��for����object���õĻ��Լ�����
            if (oldIsArr !== newIsArr || !newIsArr) {
                this.listData = listData;
                var me = this;
                this._disposeChildren(null, function () {
                    me._createChildren();
                });
                return;
            }

            this._updateArray(changes, listData);
            this.listData = listData;
        }
        else {
            this.listData = listData;
            this._createChildren();
        }
    };

    /**
     * �����ͷ���Ԫ��
     *
     * @param {Array?} children Ҫ���ٵ���Ԫ�أ�Ĭ��Ϊ������children
     * @param {Function} callback �ͷ���ɵĻص�����
     */
    ForNode.prototype._disposeChildren = function (children, callback) {
        var parentEl = this.el.parentNode;
        var parentFirstChild = parentEl.firstChild;
        var parentLastChild = parentEl.lastChild;

        var len = this.children.length;

        var violentClear = !this.aNode.directives.transition
            && !children
            // �Ƿ� parent ��Ψһ child
            && (len
                && parentFirstChild === this.children[0].el
                && (parentLastChild === this.el
                    || parentLastChild === this.children[len - 1].el)
                || len === 0
                && parentFirstChild === this.el
                && parentLastChild === this.el
            );

        if (!children) {
            children = this.children;
            this.children = [];
        }


        var me = this;
        var disposedChildCount = 0;
        len = children.length;
        if (!len) {
            childDisposed();
        }
        else {
            for (var i = 0; i < len; i++) {
                var disposeChild = children[i];
                if (disposeChild) {
                    disposeChild._ondisposed = childDisposed;
                    disposeChild.dispose(violentClear, violentClear);
                }
                else {
                    childDisposed();
                }
            }
        }

        function childDisposed() {
            disposedChildCount++;
            if (disposedChildCount >= len) {
                if (violentClear) {
                    // cloneNode + replaceChild is faster
                    // parentEl.innerHTML = '';
                    var replaceNode = parentEl.cloneNode(false);
                    parentEl.parentNode.replaceChild(replaceNode, parentEl);
                    me.el = document.createComment(me.id);
                    replaceNode.appendChild(me.el);
                }

                callback && callback();
            }
        }
    };

    /**
     * �������͵���ͼ����
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     * @param {Array} newList ����������
     */
    ForNode.prototype._updateArray = function (changes, newList) {
        var oldChildrenLen = this.children.length;
        var childrenChanges = new Array(oldChildrenLen);

        function pushToChildrenChanges(change) {
            for (var i = 0, l = childrenChanges.length; i < l; i++) {
                (childrenChanges[i] = childrenChanges[i] || []).push(change);
            }
        }

        var disposeChildren = [];

        // �����б��Ƿ�������µı���
        var isChildrenRebuild;

        var newLen = newList.length;

        /* eslint-disable no-redeclare */
        for (var cIndex = 0; cIndex < changes.length; cIndex++) {
            var change = changes[cIndex];
            var relation = changeExprCompare(change.expr, this.param.value, this.scope);

            if (!relation) {
                // �޹�ʱ��ֱ�Ӵ��ݸ���Ԫ�ظ��£��б���������Ҫ��
                pushToChildrenChanges(change);
            }
            else if (relation > 2) {
                // �������ʽ��list�󶨱���ʽ������
                // ֻ��Ҫ����Ӧ��������и���
                var changePaths = change.expr.paths;
                var forLen = this.param.value.paths.length;
                var changeIndex = +evalExpr(changePaths[forLen], this.scope, this.owner);

                if (isNaN(changeIndex)) {
                    pushToChildrenChanges(change);
                }
                else {
                    (childrenChanges[changeIndex] = childrenChanges[changeIndex] || [])
                        .push(change);

                    change = {
                        type: change.type,
                        expr: createAccessor(
                            this.param.item.paths.concat(changePaths.slice(forLen + 1))
                        ),
                        value: change.value,
                        index: change.index,
                        deleteCount: change.deleteCount,
                        insertions: change.insertions,
                        option: change.option
                    };

                    childrenChanges[changeIndex].push(change);

                    if (change.type === 1) {
                        if (this.children[changeIndex]) {
                            this.children[changeIndex].scope._set(
                                change.expr,
                                change.value,
                                { silent: 1 }
                            );
                        }
                        else {
                            // ������������������ܳ������鳤�ȣ���ʱ��Ҫ����
                            // ���統ǰ����ֻ��2�����set list[4]
                            this.children[changeIndex] = 0;
                        }
                    }
                    else if (this.children[changeIndex]) {
                        this.children[changeIndex].scope._splice(
                            change.expr,
                            [].concat(change.index, change.deleteCount, change.insertions),
                            { silent: 1 }
                        );
                    }
                }
            }
            else if (change.type !== 2) {
                // �������ʽ��list�󶨱���ʽ������ĸ���������ֵ
                // ��ʱ��Ҫ���������б�

                var getItemKey = this.aNode.hotspot.getForKey;
                if (getItemKey && newLen && oldChildrenLen) {
                    // ���������trackBy����lcs���¡���ʼ ====
                    var lcsFlags = [];
                    var newListKeys = [];
                    var oldListKeys = [];

                    each(newList, function (item) {
                        newListKeys.push(getItemKey(item));
                    });

                    each(this.listData, function (item) {
                        oldListKeys.push(getItemKey(item));
                    });


                    var newIndex;
                    var oldIndex;
                    for (oldIndex = 0; oldIndex <= oldChildrenLen; oldIndex++) {
                        lcsFlags.push([]);

                        for (newIndex = 0; newIndex <= newLen; newIndex++) {
                            var lcsFlag = 0;
                            if (newIndex && oldIndex) {
                                lcsFlag = newListKeys[newIndex - 1] === oldListKeys[oldIndex - 1]
                                    ? lcsFlags[oldIndex - 1][newIndex - 1] + 1
                                    : Math.max(lcsFlags[oldIndex - 1][newIndex], lcsFlags[oldIndex][newIndex - 1]);
                            }

                            lcsFlags[oldIndex].push(lcsFlag);
                        }
                    }

                    newIndex--;
                    oldIndex--;
                    while (1) {
                        if (oldIndex && newIndex && oldListKeys[oldIndex - 1] === newListKeys[newIndex - 1]) {
                            newIndex--;
                            oldIndex--;

                            // ������ݱ������÷����仯�����ñ��
                            if (this.listData[oldIndex] !== newList[newIndex]) {
                                (childrenChanges[oldIndex] = childrenChanges[oldIndex] || []).push({
                                    type: 1,
                                    option: change.option,
                                    expr: createAccessor(this.param.item.paths.slice(0)),
                                    value: newList[newIndex]
                                });
                            }

                            // ��list���ϼ����ݵ�ֱ������
                            if (relation < 2) {
                                (childrenChanges[oldIndex] = childrenChanges[oldIndex] || []).push(change);
                            }
                        }
                        else if (newIndex
                            && (!oldIndex || lcsFlags[oldIndex][newIndex - 1] >= lcsFlags[oldIndex - 1][newIndex])
                        ) {
                            newIndex--;
                            childrenChanges.splice(oldIndex, 0, 0);
                            this.children.splice(oldIndex, 0, 0);
                        }
                        else if (oldIndex
                            && (!newIndex || lcsFlags[oldIndex][newIndex - 1] < lcsFlags[oldIndex - 1][newIndex])
                        ) {
                            oldIndex--;
                            disposeChildren.push(this.children[oldIndex]);
                            childrenChanges.splice(oldIndex, 1);
                            this.children.splice(oldIndex, 1);
                        }
                        else {
                            break;
                        }
                    }
                    // ���������trackBy����lcs���¡����� ====
                }
                else {
                    // �ϵı��µĶ�Ĳ��֣������Ҫdispose
                    if (oldChildrenLen > newLen) {
                        disposeChildren = disposeChildren.concat(this.children.slice(newLen));
                        childrenChanges = childrenChanges.slice(0, newLen);
                        this.children = this.children.slice(0, newLen);
                    }

                    // ʣ�µĲ���������
                    for (var i = 0; i < newLen; i++) {
                        (childrenChanges[i] = childrenChanges[i] || []).push({
                            type: 1,
                            option: change.option,
                            expr: createAccessor(this.param.item.paths.slice(0)),
                            value: newList[i]
                        });

                        // ��list���ϼ����ݵ�ֱ������
                        if (relation < 2) {
                            childrenChanges[i].push(change);
                        }

                        if (this.children[i]) {
                            this.children[i].scope._set(
                                this.param.item,
                                newList[i],
                                {silent: 1}
                            );
                        }
                        else {
                            this.children[i] = 0;
                        }
                    }
                }

                isChildrenRebuild = 1;
            }
            else if (relation === 2 && change.type === 2 && !isChildrenRebuild) {
                // �������ʽ��list�󶨱���ʽ���������splice����
                // ��ʱ��Ҫɾ�����������������
                var changeStart = change.index;
                var deleteCount = change.deleteCount;
                var insertionsLen = change.insertions.length;
                var newCount = insertionsLen - deleteCount;

                if (newCount) {
                    var indexChange = {
                        type: 1,
                        option: change.option,
                        expr: this.param.index
                    };

                    for (var i = changeStart + deleteCount; i < this.children.length; i++) {
                        (childrenChanges[i] = childrenChanges[i] || []).push(indexChange);
                        this.children[i] && this.children[i].scope._set(
                            indexChange.expr,
                            i - deleteCount + insertionsLen,
                            {silent: 1}
                        );
                    }
                }

                var deleteLen = deleteCount;
                while (deleteLen--) {
                    if (deleteLen < insertionsLen) {
                        var i = changeStart + deleteLen;
                        // update
                        (childrenChanges[i] = childrenChanges[i] || []).push({
                            type: 1,
                            option: change.option,
                            expr: createAccessor(this.param.item.paths.slice(0)),
                            value: change.insertions[deleteLen]
                        });
                        if (this.children[i]) {
                            this.children[i].scope._set(
                                this.param.item,
                                change.insertions[deleteLen],
                                {silent: 1}
                            );
                        }
                    }
                }

                if (newCount < 0) {
                    disposeChildren = disposeChildren.concat(this.children.splice(changeStart + insertionsLen, -newCount));
                    childrenChanges.splice(changeStart + insertionsLen, -newCount);
                }
                else if (newCount > 0) {
                    var spliceArgs = [changeStart + deleteCount, 0].concat(new Array(newCount));
                    this.children.splice.apply(this.children, spliceArgs);
                    childrenChanges.splice.apply(childrenChanges, spliceArgs);
                }
            }
        }

        var newChildrenLen = this.children.length;

        // ��� length �Ƿ����仯
        if (newChildrenLen !== oldChildrenLen && this.param.value.paths) {
            var lengthChange = {
                type: 1,
                option: {},
                expr: createAccessor(
                    this.param.value.paths.concat({
                        type: 1,
                        value: 'length'
                    })
                )
            };

            if (changesIsInDataRef([lengthChange], this.aNode.hotspot.data)) {
                pushToChildrenChanges(lengthChange);
            }
        }

        // ִ����ͼ���£���ɾ��ˢ��
        this._doCreateAndUpdate = doCreateAndUpdate;

        var me = this;
        if (disposeChildren.length === 0) {
            doCreateAndUpdate();
        }
        else {
            this._disposeChildren(disposeChildren, function () {
                if (doCreateAndUpdate === me._doCreateAndUpdate) {
                    doCreateAndUpdate();
                }
            });
        }

        function doCreateAndUpdate() {
            me._doCreateAndUpdate = null;

            var beforeEl = me.el;
            var parentEl = beforeEl.parentNode;

            // ����Ӧ������и���
            // �����attached��ֱ�Ӵ����������������ø��º���
            var j = -1;
            for (var i = 0; i < newChildrenLen; i++) {
                var child = me.children[i];

                if (child) {
                    childrenChanges[i] && child._update(childrenChanges[i]);
                }
                else {
                    if (j < i) {
                        j = i + 1;
                        beforeEl = null;
                        while (j < newChildrenLen) {
                            var nextChild = me.children[j];
                            if (nextChild) {
                                beforeEl = nextChild.sel || nextChild.el;
                                break;
                            }
                            j++;
                        }
                    }

                    me.children[i] = createForDirectiveChild(me, newList[i], i);
                    me.children[i].attach(parentEl, beforeEl || me.el);
                }
            }
        }
    };


// exports = module.exports = ForNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ϴ���� aNode
     */


// var createANode = require('../parser/create-a-node');
// var cloneDirectives = require('../parser/clone-directives');


    /**
     * ��ϴ���� aNode�����ش���������ָ��� aNode
     *
     * @param {ANode} aNode �����ڵ����
     * @return {ANode}
     */
    function rinseCondANode(aNode) {
        var clearANode = createANode({
            children: aNode.children,
            props: aNode.props,
            events: aNode.events,
            tagName: aNode.tagName,
            vars: aNode.vars,
            hotspot: aNode.hotspot,
            directives: cloneDirectives(aNode.directives, {
                'if': 1,
                'else': 1,
                'elif': 1
            })
        });

        return clearANode;
    }

// exports = module.exports = rinseCondANode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file if ָ��ڵ���
     */

// var each = require('../util/each');
// var guid = require('../util/guid');
// var insertBefore = require('../browser/insert-before');
// var evalExpr = require('../runtime/eval-expr');
// var NodeType = require('./node-type');
// var rinseCondANode = require('./rinse-cond-anode');
// var createNode = require('./create-node');
// var createReverseNode = require('./create-reverse-node');
// var nodeOwnCreateStump = require('./node-own-create-stump');
// var elementUpdateChildren = require('./element-update-children');
// var nodeOwnSimpleDispose = require('./node-own-simple-dispose');

    /**
     * if ָ��ڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function IfNode(aNode, owner, scope, parent, reverseWalker) {
        this.aNode = aNode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;
        this.parentComponent = parent.nodeType === 5
            ? parent
            : parent.parentComponent;

        this.id = guid();
        this.children = [];

        this.cond = this.aNode.directives['if'].value; // eslint-disable-line dot-notation

        // #[begin] reverse
        if (reverseWalker) {
            if (evalExpr(this.cond, this.scope, this.owner)) {
                this.elseIndex = -1;
                this.children[0] = createReverseNode(
                    rinseCondANode(aNode),
                    reverseWalker,
                    this
                );
            }
            else {
                var me = this;
                each(aNode.elses, function (elseANode, index) {
                    var elif = elseANode.directives.elif;

                    if (!elif || elif && evalExpr(elif.value, me.scope, me.owner)) {
                        me.elseIndex = index;
                        me.children[0] = createReverseNode(
                            rinseCondANode(elseANode),
                            reverseWalker,
                            me
                        );
                        return false;
                    }
                });
            }

            this._create();
            insertBefore(this.el, reverseWalker.target, reverseWalker.current);
        }
        // #[end]
    }

    IfNode.prototype.nodeType = 2;

    IfNode.prototype._create = nodeOwnCreateStump;
    IfNode.prototype.dispose = nodeOwnSimpleDispose;

    /**
     * attach��ҳ��
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    IfNode.prototype.attach = function (parentEl, beforeEl) {
        var me = this;
        var elseIndex;
        var child;

        if (evalExpr(this.cond, this.scope, this.owner)) {
            child = createNode(rinseCondANode(this.aNode), this);
            elseIndex = -1;
        }
        else {
            each(this.aNode.elses, function (elseANode, index) {
                var elif = elseANode.directives.elif;

                if (!elif || elif && evalExpr(elif.value, me.scope, me.owner)) {
                    child = createNode(rinseCondANode(elseANode), me);
                    elseIndex = index;
                    return false;
                }
            });
        }

        if (child) {
            this.children[0] = child;
            child.attach(parentEl, beforeEl);
            this.elseIndex = elseIndex;
        }


        this._create();
        insertBefore(this.el, parentEl, beforeEl);
    };


    /**
     * ��ͼ���º���
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    IfNode.prototype._update = function (changes) {
        var me = this;
        var childANode = this.aNode;
        var elseIndex;

        if (evalExpr(this.cond, this.scope, this.owner)) {
            elseIndex = -1;
        }
        else {
            each(this.aNode.elses, function (elseANode, index) {
                var elif = elseANode.directives.elif;

                if (elif && evalExpr(elif.value, me.scope, me.owner) || !elif) {
                    elseIndex = index;
                    childANode = elseANode;
                    return false;
                }
            });
        }

        if (elseIndex === this.elseIndex) {
            elementUpdateChildren(this.children, changes);
        }
        else {
            var child = this.children[0];
            this.children = [];
            if (child) {
                child._ondisposed = newChild;
                child.dispose();
            }
            else {
                newChild();
            }

            this.elseIndex = elseIndex;
        }

        function newChild() {
            if (typeof elseIndex !== 'undefined') {
                (me.children[0] = createNode(rinseCondANode(childANode), me))
                    .attach(me.el.parentNode, me.el);
            }
        }
    };

// exports = module.exports = IfNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file template �ڵ���
     */

// var each = require('../util/each');
// var guid = require('../util/guid');
// var insertBefore = require('../browser/insert-before');
// var removeEl = require('../browser/remove-el');
// var NodeType = require('./node-type');
// var LifeCycle = require('./life-cycle');
// var nodeDispose = require('./node-dispose');
// var createReverseNode = require('./create-reverse-node');
// var elementDisposeChildren = require('./element-dispose-children');
// var elementOwnToPhase = require('./element-own-to-phase');
// var elementUpdateChildren = require('./element-update-children');
// var nodeOwnOnlyChildrenAttach = require('./node-own-only-children-attach');

    /**
     * template �ڵ���
     *
     * @param {Object} aNode ����ڵ�
     * @param {Component} owner �����������
     * @param {Model=} scope �������ݻ���
     * @param {Node} parent ���׽ڵ�
     * @param {DOMChildrenWalker?} reverseWalker ��Ԫ�ر�������
     */
    function TemplateNode(aNode, owner, scope, parent, reverseWalker) {
        this.aNode = aNode;
        this.owner = owner;
        this.scope = scope;
        this.parent = parent;
        this.parentComponent = parent.nodeType === 5
            ? parent
            : parent.parentComponent;

        this.id = guid();
        this.lifeCycle = LifeCycle.start;
        this.children = [];

        // #[begin] reverse
        if (reverseWalker) {
            this.sel = document.createComment(this.id);
            insertBefore(this.sel, reverseWalker.target, reverseWalker.current);

            var me = this;
            each(this.aNode.children, function (aNodeChild) {
                me.children.push(createReverseNode(aNodeChild, reverseWalker, me));
            });

            this.el = document.createComment(this.id);
            insertBefore(this.el, reverseWalker.target, reverseWalker.current);

            this._toPhase('attached');
        }
        // #[end]
    }



    TemplateNode.prototype.nodeType = 7;

    TemplateNode.prototype.attach = nodeOwnOnlyChildrenAttach;

    /**
     * �����ͷ�
     *
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     * @param {boolean=} noTransition �Ƿ���ʾ���ɶ���Ч��
     */
    TemplateNode.prototype.dispose = function (noDetach, noTransition) {
        elementDisposeChildren(this.children, noDetach, noTransition);

        if (!noDetach) {
            removeEl(this.el);
            removeEl(this.sel);
        }
        nodeDispose(this);
    };


    TemplateNode.prototype._toPhase = elementOwnToPhase;

    /**
     * ��ͼ���º���
     *
     * @param {Array} changes ���ݱ仯��Ϣ
     */
    TemplateNode.prototype._update = function (changes) {
        elementUpdateChildren(this.children, changes);
    };

// exports = module.exports = TemplateNode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��Ԫ�ص��ӽڵ���з���
     */


// var each = require('../util/each');
// var DOMChildrenWalker = require('./dom-children-walker');
// var createReverseNode = require('./create-reverse-node');

// #[begin] reverse

    /**
     * ��Ԫ�ص��ӽڵ���з���
     *
     * @param {Object} element Ԫ��
     */
    function reverseElementChildren(element) {
        var htmlDirective = element.aNode.directives.html;

        if (!htmlDirective) {
            var reverseWalker = new DOMChildrenWalker(element.el);

            each(element.aNode.children, function (aNodeChild) {
                element.children.push(createReverseNode(aNodeChild, reverseWalker, element));
            });
        }
    }
// #[end]

// exports = module.exports = reverseElementChildren;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Ԫ�ص����Բ���
     */

// var getPropHandler = require('./get-prop-handler');

    /**
     * ����Ԫ�����Բ���
     *
     * @param {Object} element Ԫ�ض���
     * @param {*} value ����ֵ
     * @param {Object} prop ������Ϣ����
     */
    function handleProp(element, value, prop) {
        var name = prop.name;
        getPropHandler(element.tagName, name).prop(element.el, value, name, element, prop);
    }

// exports = module.exports = handleProp;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ڵ��Ӧ�� HTMLElement ��Ԫ��
     */


// var evalExpr = require('../runtime/eval-expr');
// var createEl = require('../browser/create-el');
// var handleProp = require('./handle-prop');
// var NodeType = require('./node-type');
// var getPropHandler = require('./get-prop-handler');

    var emptyPropWhenCreate = {
        'class': 1,
        'style': 1,
        'id': 1
    };

    /**
     * �����ڵ��Ӧ�� HTMLElement ��Ԫ��
     */
    function elementOwnCreate() {
        if (!this.lifeCycle.created) {
            var isComponent = this.nodeType === 5;
            var sourceNode = this.aNode.hotspot.sourceNode;
            var props = this.aNode.props;

            if (sourceNode) {
                this.el = sourceNode.cloneNode();
                props = this.aNode.hotspot.dynamicProps;
            }
            else {
                this.el = createEl(this.tagName);
            }

            for (var key in this._sbindData) {
                if (this._sbindData.hasOwnProperty(key)) {
                    getPropHandler(this.tagName, key).prop(
                        this.el,
                        this._sbindData[key],
                        key,
                        this
                    );
                }
            }

            for (var i = 0, l = props.length; i < l; i++) {
                var prop = props[i];
                var value = isComponent
                    ? evalExpr(prop.expr, this.data, this)
                    : evalExpr(prop.expr, this.scope, this.owner);

                if (value || !emptyPropWhenCreate[prop.name]) {
                    handleProp(this, value, prop);
                }
            }

            this._toPhase('created');
        }
    }

// exports = module.exports = elementOwnCreate;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��Ԫ��attach��ҳ��
     */

// var genElementChildren = require('./gen-element-children');
// var evalExpr = require('../runtime/eval-expr');
// var insertBefore = require('../browser/insert-before');

    /**
     * ��Ԫ��attach��ҳ��
     *
     * @param {Object} element Ԫ�ؽڵ�
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    function elementAttach(element, parentEl, beforeEl) {
        element._create();
        insertBefore(element.el, parentEl, beforeEl);

        if (!element._contentReady) {
            var htmlDirective = element.aNode.directives.html;

            if (htmlDirective) {
                element.el.innerHTML = evalExpr(htmlDirective.value, element.scope, element.owner);
            }
            else {
                genElementChildren(element);
            }

            element._contentReady = 1;
        }
    }


// exports = module.exports = elementAttach;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��Ԫ��attach��ҳ��
     */


// var elementAttach = require('./element-attach');

    /**
     * ��Ԫ��attach��ҳ��
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    function elementOwnAttach(parentEl, beforeEl) {
        if (!this.lifeCycle.attached) {
            elementAttach(this, parentEl, beforeEl);

            // element �����ڲ������ģ�ֻ�ж�̬������ component �Ż���������֧
            if (this.owner && !this.parent) {
                this.owner.implicitChildren.push(this);
            }
            this._attached();
        }
    }

// exports = module.exports = elementOwnAttach;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ȡ element �� transition ���ƶ���
     */

// var evalArgs = require('../runtime/eval-args');
// var findMethod = require('../runtime/find-method');
// var NodeType = require('./node-type');

    /**
     * ��ȡ element �� transition ���ƶ���
     *
     * @param {Object} element Ԫ��
     * @return {Object?}
     */
    function elementGetTransition(element) {
        var directive = element.aNode.directives.transition;
        var owner = element.owner;

        if (element.nodeType === 5) {
            var cmptGivenTransition = element.source && element.source.directives.transition;
            if (cmptGivenTransition) {
                directive = cmptGivenTransition;
            }
            else {
                owner = element;
            }
        }

        var transition;
        if (directive && owner) {
            transition = findMethod(owner, directive.value.name);

            if (typeof transition === 'function') {
                transition = transition.apply(
                    owner,
                    evalArgs(directive.value.args, element.scope, owner)
                );
            }
        }

        return transition || element.transition;
    }

// exports = module.exports = elementGetTransition;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file Ԫ�ؽڵ�ִ��leave��Ϊ
     */

// var elementGetTransition = require('./element-get-transition');


    /**
     * Ԫ�ؽڵ�ִ��leave��Ϊ
     *
     * @param {Object} element Ԫ��
     */
    function elementLeave(element) {
        var lifeCycle = element.lifeCycle;
        if (lifeCycle.leaving) {
            return;
        }

        if (element.disposeNoTransition) {
            element._doneLeave();
        }
        else {
            var transition = elementGetTransition(element);

            if (transition && transition.leave) {
                element._toPhase('leaving');
                transition.leave(element.el, function () {
                    element._doneLeave();
                });
            }
            else {
                element._doneLeave();
            }
        }
    }

// exports = module.exports = elementLeave;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��Ԫ�ش�ҳ�����Ƴ�
     */

// var elementLeave = require('./element-leave');

    /**
     * ��Ԫ�ش�ҳ�����Ƴ�
     */
    function elementOwnDetach() {
        elementLeave(this);
    }


// exports = module.exports = elementOwnDetach;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����ͷ�Ԫ��
     */

// var elementLeave = require('./element-leave');

    /**
     * �����ͷ�Ԫ��
     *
     * @param {boolean=} noDetach �Ƿ�Ҫ�ѽڵ��dom�Ƴ�
     * @param {boolean=} noTransition �Ƿ���ʾ���ɶ���Ч��
     */
    function elementOwnDispose(noDetach, noTransition) {
        this.leaveDispose = 1;
        this.disposeNoDetach = noDetach;
        this.disposeNoTransition = noTransition;

        elementLeave(this);
    }

// exports = module.exports = elementOwnDispose;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ΪԪ�ص� el ���¼�
     */

// var on = require('../browser/on');

    /**
     * ΪԪ�ص� el ���¼�
     *
     * @param {string} name �¼���
     * @param {Function} listener ������
     * @param {boolean} capture �Ƿ��ǲ���׶δ���
     */
    function elementOwnOnEl(name, listener, capture) {
        if (typeof listener === 'function') {
            capture = !!capture;
            this._elFns.push([name, listener, capture]);
            on(this.el, name, listener, capture);
        }
    }

// exports = module.exports = elementOwnOnEl;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file  �¼��󶨲����ڵ� warning
     */

// var each = require('../util/each');
// var warn = require('../util/warn');

// #[begin] error
    /**
     * �¼��󶨲����ڵ� warning
     *
     * @param {Object} eventBind �¼��󶨶���
     * @param {Component} owner �������������
     */
    function warnEventListenMethod(eventBind, owner) {
        var valid = true;
        var method = owner;
        each(eventBind.expr.name.paths, function (path) {
            if (!path.value) {
                return false;
            }

            method = method[path.value];
            valid = !!method;
            return valid;
        });

        if (!valid) {
            var paths = [];
            each(eventBind.expr.name.paths, function (path) {
                paths.push(path.value);
            });

            warn(eventBind.name + ' listen fail,"' + paths.join('.') + '" not exist');
        }
    }
// #[end]

// exports = module.exports = warnEventListenMethod;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���Ԫ�� attached �����Ϊ
     */


// var bind = require('../util/bind');
// var empty = require('../util/empty');
// var isBrowser = require('../browser/is-browser');
// var trigger = require('../browser/trigger');
// var NodeType = require('./node-type');
// var elementGetTransition = require('./element-get-transition');
// var eventDeclarationListener = require('./event-declaration-listener');
// var getPropHandler = require('./get-prop-handler');
// var warnEventListenMethod = require('./warn-event-listen-method');

    /**
     * ˫�������CompositionEnd�¼���������
     *
     * @inner
     */
    function inputOnCompositionEnd() {
        if (!this.composing) {
            return;
        }

        this.composing = 0;

        trigger(this, 'input');
    }

    /**
     * ˫�������CompositionStart�¼���������
     *
     * @inner
     */
    function inputOnCompositionStart() {
        this.composing = 1;
    }

    function xPropOutputer(xProp, data) {
        getPropHandler(this.tagName, xProp.name).output(this, xProp, data);
    }

    function inputXPropOutputer(element, xProp, data) {
        var outputer = bind(xPropOutputer, element, xProp, data);
        return function (e) {
            if (!this.composing) {
                outputer(e);
            }
        };
    }

    /**
     * ���Ԫ�� attached �����Ϊ
     *
     * @param {Object} element Ԫ�ؽڵ�
     */
    function elementOwnAttached() {
        this._toPhase('created');

        var isComponent = this.nodeType === 5;
        var data = isComponent ? this.data : this.scope;

        /* eslint-disable no-redeclare */

        // ���������仯ʱ˫��󶨵��߼�
        var xProps = this.aNode.hotspot.xProps;
        for (var i = 0, l = xProps.length; i < l; i++) {
            var xProp = xProps[i];

            switch (xProp.name) {
                case 'value':
                    switch (this.tagName) {
                        case 'input':
                        case 'textarea':
                            if (isBrowser && window.CompositionEvent) {
                                this._onEl('change', inputOnCompositionEnd);
                                this._onEl('compositionstart', inputOnCompositionStart);
                                this._onEl('compositionend', inputOnCompositionEnd);
                            }

                            this._onEl(
                                ('oninput' in this.el) ? 'input' : 'propertychange',
                                inputXPropOutputer(this, xProp, data)
                            );

                            break;

                        case 'select':
                            this._onEl('change', bind(xPropOutputer, this, xProp, data));
                            break;
                    }
                    break;

                case 'checked':
                    switch (this.tagName) {
                        case 'input':
                            switch (this.el.type) {
                                case 'checkbox':
                                case 'radio':
                                    this._onEl('click', bind(xPropOutputer, this, xProp, data));
                            }
                    }
                    break;
            }
        }

        // bind events
        var events = isComponent
            ? this.aNode.events.concat(this.nativeEvents)
            : this.aNode.events;

        for (var i = 0, l = events.length; i < l; i++) {
            var eventBind = events[i];
            var owner = isComponent ? this : this.owner;

            // �ж��Ƿ���nativeEvent�������warn�������¼��󶨶���Ҫ
            // ����ָ��eventBind.expr.nameλ��owner����owner.owner��
            if (eventBind.modifier.native) {
                owner = owner.owner;
                data = this.scope || owner.data;
            }

            // #[begin] error
            warnEventListenMethod(eventBind, owner);
            // #[end]

            this._onEl(
                eventBind.name,
                bind(
                    eventDeclarationListener,
                    owner,
                    eventBind,
                    0,
                    data
                ),
                eventBind.modifier.capture
            );
        }

        this._toPhase('attached');


        if (this._isInitFromEl) {
            this._isInitFromEl = false;
        }
        else {
            var transition = elementGetTransition(this);
            if (transition && transition.enter) {
                transition.enter(this.el, empty);
            }
        }
    }

// exports = module.exports = elementOwnAttached;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Ԫ�ؽڵ�
     */


// var un = require('../browser/un');
// var removeEl = require('../browser/remove-el');
// var elementDisposeChildren = require('./element-dispose-children');
// var nodeDispose = require('./node-dispose');

    /**
     * ����Ԫ�ؽڵ�
     *
     * @param {Object} element Ҫ���ٵ�Ԫ�ؽڵ�
     * @param {Object=} options ������Ϊ�Ĳ���
     */
    function elementDispose(element) {
        elementDisposeChildren(element.children, 1, 1);
        elementDisposeChildren(element.implicitChildren, 0, 1);

        // el �¼����
        var len = element._elFns.length;
        while (len--) {
            var fn = element._elFns[len];
            un(element.el, fn[0], fn[1], fn[2]);
        }
        element._elFns = null;


        // ���û��parent��˵����һ��root component��һ��Ҫ��dom����remove
        if (!element.disposeNoDetach || !element.parent) {
            removeEl(element.el);
        }

        if (element._toPhase) {
            element._toPhase('detached');
        }

        nodeDispose(element);
    }


// exports = module.exports = elementDispose;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ��ʼ�� element �ڵ�� tagName ����
     */

// var ieOldThan9 = require('../browser/ie-old-than-9');

    /**
     * ��ʼ�� element �ڵ�� tagName ����
     *
     * @param {Object} node �ڵ����
     */
    function elementInitTagName(node) {
        node.tagName = node.tagName || node.aNode.tagName || 'div';

        // #[begin] allua
        // ie8- ��֧��innerHTML����Զ����ǩ
        if (ieOldThan9 && node.tagName.indexOf('-') > 0) {
            node.tagName = 'div';
        }
        // #[end]
    }


// exports = module.exports = elementInitTagName;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �첽�����
     */

// var nodeOwnCreateStump = require('./node-own-create-stump');
// var nodeOwnSimpleDispose = require('./node-own-simple-dispose');


    /**
     * �첽�����
     *
     * @class
     * @param {Object} options ��ʼ������
     * @param {Object} loader ���������
     */
    function AsyncComponent(options, loader) {
        this.options = options;
        this.loader = loader;
        this.id = guid();
        this.children = [];

        // #[begin] reverse
        var reverseWalker = options.reverseWalker;
        if (reverseWalker) {
            var PlaceholderComponent = this.loader.placeholder;
            if (PlaceholderComponent) {
                this.children[0] = new PlaceholderComponent(options);
            }

            this._create();
            insertBefore(this.el, reverseWalker.target, reverseWalker.current);

            var me = this;
            this.loader.start(function (ComponentClass) {
                me.onload(ComponentClass);
            });
        }
        options.reverseWalker = null;
        // #[end]
    }

    AsyncComponent.prototype._create = nodeOwnCreateStump;
    AsyncComponent.prototype.dispose = nodeOwnSimpleDispose;

    /**
     * attach��ҳ��
     *
     * @param {HTMLElement} parentEl Ҫ���ӵ��ĸ�Ԫ��
     * @param {HTMLElement��} beforeEl Ҫ���ӵ��ĸ�Ԫ��֮ǰ
     */
    AsyncComponent.prototype.attach = function (parentEl, beforeEl) {
        var PlaceholderComponent = this.loader.placeholder;
        if (PlaceholderComponent) {
            var component = new PlaceholderComponent(this.options);
            this.children[0] = component;
            component.attach(parentEl, beforeEl);
        }

        this._create();
        insertBefore(this.el, parentEl, beforeEl);

        var me = this;
        this.loader.start(function (ComponentClass) {
            me.onload(ComponentClass);
        });
    };


    /**
     * loader������ɣ���Ⱦ���
     *
     * @param {Function=} ComponentClass �����
     */
    AsyncComponent.prototype.onload = function (ComponentClass) {
        if (this.el && ComponentClass) {
            var component = new ComponentClass(this.options);
            component.attach(this.el.parentNode, this.el);

            var parentChildren = this.options.parent.children;
            if (this.parentIndex == null || parentChildren[this.parentIndex] !== this) {
                each(parentChildren, function (child, index) {
                    if (child instanceof AsyncComponent) {
                        child.parentIndex = index;
                    }
                });
            }

            parentChildren[this.parentIndex] = component;
        }

        this.dispose();
    };

// exports = module.exports = AsyncComponent;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �� devtool ��֪ͨ��Ϣ
     */

// var isBrowser = require('../browser/is-browser');

// #[begin] devtool
    var san4devtool;

    /**
     * �� devtool ��֪ͨ��Ϣ
     *
     * @param {string} name ��Ϣ����
     * @param {*} arg ��Ϣ����
     */
    function emitDevtool(name, arg) {
        if (isBrowser && san4devtool && san4devtool.debug && window.__san_devtool__) {
            window.__san_devtool__.emit(name, arg);
        }
    }

    emitDevtool.start = function (main) {
        san4devtool = main;
        emitDevtool('san', main);
    };
// #[end]

// exports = module.exports = emitDevtool;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �����
     */

// var bind = require('../util/bind');
// var each = require('../util/each');
// var guid = require('../util/guid');
// var extend = require('../util/extend');
// var nextTick = require('../util/next-tick');
// var emitDevtool = require('../util/emit-devtool');
// var ExprType = require('../parser/expr-type');
// var parseExpr = require('../parser/parse-expr');
// var createAccessor = require('../parser/create-accessor');
// var postProp = require('../parser/post-prop');
// var removeEl = require('../browser/remove-el');
// var Data = require('../runtime/data');
// var evalExpr = require('../runtime/eval-expr');
// var changeExprCompare = require('../runtime/change-expr-compare');
// var DataChangeType = require('../runtime/data-change-type');
// var compileComponent = require('./compile-component');
// var preheatANode = require('./preheat-a-node');
// var LifeCycle = require('./life-cycle');
// var getANodeProp = require('./get-a-node-prop');
// var isDataChangeByElement = require('./is-data-change-by-element');
// var eventDeclarationListener = require('./event-declaration-listener');
// var reverseElementChildren = require('./reverse-element-children');
// var camelComponentBinds = require('./camel-component-binds');
// var NodeType = require('./node-type');
// var nodeSBindInit = require('./node-s-bind-init');
// var nodeSBindUpdate = require('./node-s-bind-update');
// var elementInitTagName = require('./element-init-tag-name');
// var elementOwnAttached = require('./element-own-attached');
// var elementDispose = require('./element-dispose');
// var elementUpdateChildren = require('./element-update-children');
// var elementOwnOnEl = require('./element-own-on-el');
// var elementOwnCreate = require('./element-own-create');
// var elementOwnAttach = require('./element-own-attach');
// var elementOwnDetach = require('./element-own-detach');
// var elementOwnDispose = require('./element-own-dispose');
// var warnEventListenMethod = require('./warn-event-listen-method');
// var elementDisposeChildren = require('./element-dispose-children');
// var elementAttach = require('./element-attach');
// var handleProp = require('./handle-prop');
// var createDataTypesChecker = require('../util/create-data-types-checker');
// var warn = require('../util/warn');




    /**
     * �����
     *
     * @class
     * @param {Object} options ��ʼ������
     */
    function Component(options) { // eslint-disable-line

        /* eslint-disable no-console */
        // #[begin] error
        for (var key in Component.prototype) {
            if (this[key] !== Component.prototype[key]) {
                warn('\`' + key + '\` is a reserved key of san components. Overriding this property may cause unknown exceptions.');
            }
        }
        // #[end]
        /* eslint-disable no-console */


        options = options || {};

        this.lifeCycle = LifeCycle.start;
        this.children = [];
        this._elFns = [];
        this.listeners = {};
        this.slotChildren = [];
        this.implicitChildren = [];

        var clazz = this.constructor;

        this.filters = this.filters || clazz.filters || {};
        this.computed = this.computed || clazz.computed || {};
        this.messages = this.messages || clazz.messages || {};

        if (options.transition) {
            this.transition = options.transition;
        }

        this.subTag = options.subTag;




        // compile
        compileComponent(clazz);

        var me = this;
        var protoANode = clazz.prototype.aNode;
        preheatANode(protoANode);



        this.source = typeof options.source === 'string'
            ? parseTemplate(options.source).children[0]
            : options.source;
        preheatANode(this.source);


        this.sourceSlotNameProps = [];
        this.sourceSlots = {
            named: {}
        };


        this.owner = options.owner;
        this.scope = options.scope;
        this.el = options.el;

        var parent = options.parent;
        if (parent) {
            this.parent = parent;
            this.parentComponent = parent.nodeType === 5
                ? parent
                : parent && parent.parentComponent;
        }
        else if (this.owner) {
            this.parentComponent = this.owner;
            this.scope = this.owner.data;
        }

        this.id = guid();

        // #[begin] reverse
        if (this.el) {
            var firstCommentNode = this.el.firstChild;
            if (firstCommentNode && firstCommentNode.nodeType === 3) {
                firstCommentNode = firstCommentNode.nextSibling;
            }

            if (firstCommentNode && firstCommentNode.nodeType === 8) {
                var stumpMatch = firstCommentNode.data.match(/^\s*s-data:([\s\S]+)?$/);
                if (stumpMatch) {
                    var stumpText = stumpMatch[1];

                    // fill component data
                    options.data = (new Function(
                        'return ' + stumpText.replace(/^[\s\n]*/, '')
                    ))();

                    if (firstCommentNode.previousSibling) {
                        removeEl(firstCommentNode.previousSibling);
                    }
                    removeEl(firstCommentNode);
                }
            }
        }
        // #[end]

        // native�¼�����
        this.nativeEvents = [];

        if (this.source) {
            // �������ʱ����Ľṹ����slot����
            this._initSourceSlots(1);

            each(this.source.events, function (eventBind) {
                // ���浱ǰʵ����native�¼������洴��aNodeʱ�����ϲ�
                if (eventBind.modifier.native) {
                    me.nativeEvents.push(eventBind);
                    return;
                }

                // #[begin] error
                warnEventListenMethod(eventBind, options.owner);
                // #[end]

                me.on(
                    eventBind.name,
                    bind(eventDeclarationListener, options.owner, eventBind, 1, me.scope),
                    eventBind
                );
            });

            this.tagName = protoANode.tagName || this.source.tagName;
            this.binds = camelComponentBinds(this.source.props);

            // init s-bind data
            nodeSBindInit(this, this.source.directives.bind);
        }

        this._toPhase('compiled');

        // init data
        this.data = new Data(
            extend(
                typeof this.initData === 'function' && this.initData() || {},
                options.data || this._sbindData
            )
        );

        elementInitTagName(this);

        each(this.binds, function (bind) {
            postProp(bind);

            if (me.scope) {
                var value = evalExpr(bind.expr, me.scope, me.owner);
                if (typeof value !== 'undefined') {
                    // See: https://github.com/ecomfe/san/issues/191
                    me.data.set(bind.name, value);
                }
            }
        });

        // #[begin] error
        // �ڳ�ʼ�� + ���ݰ󶨺󣬿�ʼ����У��
        // NOTE: ֻ�ڿ����汾�н�������У��
        var dataTypes = this.dataTypes || clazz.dataTypes;
        if (dataTypes) {
            var dataTypeChecker = createDataTypesChecker(
                dataTypes,
                this.subTag || this.name || clazz.name
            );
            this.data.setTypeChecker(dataTypeChecker);
            this.data.checkDataTypes();
        }
        // #[end]

        this.computedDeps = {};
        for (var expr in this.computed) {
            if (this.computed.hasOwnProperty(expr) && !this.computedDeps[expr]) {
                this._calcComputed(expr);
            }
        }

        if (!this.dataChanger) {
            this.dataChanger = bind(this._dataChanger, this);
            this.data.listen(this.dataChanger);
        }
        this._toPhase('inited');

        // #[begin] reverse
        if (this.el) {
            reverseElementChildren(this);
            this._attached();
        }

        var walker = options.reverseWalker;
        if (walker) {
            var currentNode = walker.current;
            if (currentNode && currentNode.nodeType === 1) {
                this.el = currentNode;
                walker.goNext();
            }

            reverseElementChildren(this);

            this._attached();
        }
        // #[end]
    }


    /**
     * ��ʼ����������ⲿ����Ĳ�۶���
     *
     * @protected
     */
    Component.prototype._initSourceSlots = function (isFirstTime) {
        var me = this;
        this.sourceSlots.named = {};

        // �������ʱ����Ľṹ����slot����
        this.source && this.scope && each(this.source.children, function (child) {
            var target;

            var slotBind = !child.textExpr && getANodeProp(child, 'slot');
            if (slotBind) {
                isFirstTime && me.sourceSlotNameProps.push(slotBind);

                var slotName = evalExpr(slotBind.expr, me.scope, me.owner);
                target = me.sourceSlots.named[slotName];
                if (!target) {
                    target = me.sourceSlots.named[slotName] = [];
                }
            }
            else if (isFirstTime) {
                target = me.sourceSlots.noname;
                if (!target) {
                    target = me.sourceSlots.noname = [];
                }
            }

            target && target.push(child);
        });
    };

    /**
     * ���ͱ�ʶ
     *
     * @type {string}
     */
    Component.prototype.nodeType = 5;

    /**
     * ����һ�������������к���
     *
     * @param {Function} fn Ҫ���еĺ���
     */
    Component.prototype.nextTick = nextTick;

    /* eslint-disable operator-linebreak */
    /**
     * ʹ�ڵ㵽����Ӧ����������
     *
     * @protected
     * @param {string} name ������������
     */
    Component.prototype._callHook =
        Component.prototype._toPhase = function (name) {
            if (!this.lifeCycle[name]) {
                this.lifeCycle = LifeCycle[name] || this.lifeCycle;
                if (typeof this[name] === 'function') {
                    this[name]();
                }
                this['_after' + name] = 1;

                // ֪ͨdevtool
                // #[begin] devtool
                emitDevtool('comp-' + name, this);
                // #[end]
            }
        };
    /* eslint-enable operator-linebreak */


    /**
     * �����¼�������
     *
     * @param {string} name �¼���
     * @param {Function} listener ������
     * @param {string?} declaration ����ʽ
     */
    Component.prototype.on = function (name, listener, declaration) {
        if (typeof listener === 'function') {
            if (!this.listeners[name]) {
                this.listeners[name] = [];
            }
            this.listeners[name].push({fn: listener, declaration: declaration});
        }
    };

    /**
     * �Ƴ��¼�������
     *
     * @param {string} name �¼���
     * @param {Function=} listener ������
     */
    Component.prototype.un = function (name, listener) {
        var nameListeners = this.listeners[name];
        var len = nameListeners && nameListeners.length;

        while (len--) {
            if (!listener || listener === nameListeners[len].fn) {
                nameListeners.splice(len, 1);
            }
        }
    };


    /**
     * �ɷ��¼�
     *
     * @param {string} name �¼���
     * @param {Object} event �¼�����
     */
    Component.prototype.fire = function (name, event) {
        var me = this;
        each(this.listeners[name], function (listener) {
            listener.fn.call(me, event);
        });
    };

    /**
     * ���� computed ���Ե�ֵ
     *
     * @private
     * @param {string} computedExpr computed����ʽ��
     */
    Component.prototype._calcComputed = function (computedExpr) {
        var computedDeps = this.computedDeps[computedExpr];
        if (!computedDeps) {
            computedDeps = this.computedDeps[computedExpr] = {};
        }

        var me = this;
        this.data.set(computedExpr, this.computed[computedExpr].call({
            data: {
                get: function (expr) {
                    // #[begin] error
                    if (!expr) {
                        throw new Error('[SAN ERROR] call get method in computed need argument');
                    }
                    // #[end]

                    if (!computedDeps[expr]) {
                        computedDeps[expr] = 1;

                        if (me.computed[expr] && !me.computedDeps[expr]) {
                            me._calcComputed(expr);
                        }

                        me.watch(expr, function () {
                            me._calcComputed(computedExpr);
                        });
                    }

                    return me.data.get(expr);
                }
            }
        }));
    };

    /**
     * �ɷ���Ϣ
     * ��������ɷ���Ϣ����Ϣ��������������ϴ��ݣ�ֱ�����ϵ�һ��������Ϣ�����
     *
     * @param {string} name ��Ϣ����
     * @param {*?} value ��Ϣֵ
     */
    Component.prototype.dispatch = function (name, value) {
        var parentComponent = this.parentComponent;

        while (parentComponent) {
            var receiver = parentComponent.messages[name] || parentComponent.messages['*'];
            if (typeof receiver === 'function') {
                receiver.call(
                    parentComponent,
                    {target: this, value: value, name: name}
                );
                break;
            }

            parentComponent = parentComponent.parentComponent;
        }
    };

    /**
     * ��ȡ����ڲ��� slot
     *
     * @param {string=} name slot���ƣ���Ϊdefault slot
     * @return {Array}
     */
    Component.prototype.slot = function (name) {
        var result = [];
        var me = this;

        function childrenTraversal(children) {
            each(children, function (child) {
                if (child.nodeType === 6 && child.owner === me) {
                    if (child.isNamed && child.name === name
                        || !child.isNamed && !name
                    ) {
                        result.push(child);
                    }
                }
                else {
                    childrenTraversal(child.children);
                }
            });
        }

        childrenTraversal(this.children);
        return result;
    };

    /**
     * ��ȡ���� san-ref ָ������������
     *
     * @param {string} name �������������
     * @return {Component}
     */
    Component.prototype.ref = function (name) {
        var refTarget;
        var owner = this;

        function childrenTraversal(children) {
            each(children, function (child) {
                elementTraversal(child);
                return !refTarget;
            });
        }

        function elementTraversal(element) {
            var nodeType = element.nodeType;
            if (nodeType === 1) {
                return;
            }

            if (element.owner === owner) {
                var ref;
                switch (element.nodeType) {
                    case 4:
                        ref = element.aNode.directives.ref;
                        if (ref && evalExpr(ref.value, element.scope, owner) === name) {
                            refTarget = element.el;
                        }
                        break;

                    case 5:
                        ref = element.source.directives.ref;
                        if (ref && evalExpr(ref.value, element.scope, owner) === name) {
                            refTarget = element;
                        }
                }

                !refTarget && childrenTraversal(element.slotChildren);
            }

            !refTarget && childrenTraversal(element.children);
        }

        childrenTraversal(this.children);

        return refTarget;
    };


    /**
     * ��ͼ���º���
     *
     * @param {Array?} changes ���ݱ仯��Ϣ
     */
    Component.prototype._update = function (changes) {
        if (this.lifeCycle.disposed) {
            return;
        }

        var me = this;


        var needReloadForSlot = false;
        this._notifyNeedReload = function () {
            needReloadForSlot = true;
        };

        if (changes) {
            this.source && nodeSBindUpdate(
                this,
                this.source.directives.bind,
                changes,
                function (name, value) {
                    if (name in me.source.hotspot.props) {
                        return;
                    }

                    me.data.set(name, value, {
                        target: {
                            id: me.owner.id
                        }
                    });
                }
            );


            each(changes, function (change) {
                var changeExpr = change.expr;

                each(me.binds, function (bindItem) {
                    var relation;
                    var setExpr = bindItem.name;
                    var updateExpr = bindItem.expr;

                    if (!isDataChangeByElement(change, me, setExpr)
                        && (relation = changeExprCompare(changeExpr, updateExpr, me.scope))
                    ) {
                        if (relation > 2) {
                            setExpr = createAccessor(
                                [
                                    {
                                        type: 1,
                                        value: setExpr
                                    }
                                ].concat(changeExpr.paths.slice(updateExpr.paths.length))
                            );
                            updateExpr = changeExpr;
                        }

                        if (relation >= 2 && change.type === 2) {
                            me.data.splice(setExpr, [change.index, change.deleteCount].concat(change.insertions), {
                                target: {
                                    id: me.owner.id
                                }
                            });
                        }
                        else {
                            me.data.set(setExpr, evalExpr(updateExpr, me.scope, me.owner), {
                                target: {
                                    id: me.owner.id
                                }
                            });
                        }
                    }
                });

                each(me.sourceSlotNameProps, function (bindItem) {
                    needReloadForSlot = needReloadForSlot || changeExprCompare(changeExpr, bindItem.expr, me.scope);
                    return !needReloadForSlot;
                });
            });

            if (needReloadForSlot) {
                this._initSourceSlots();
                this._repaintChildren();
            }
            else {
                var slotChildrenLen = this.slotChildren.length;
                while (slotChildrenLen--) {
                    var slotChild = this.slotChildren[slotChildrenLen];

                    if (slotChild.lifeCycle.disposed) {
                        this.slotChildren.splice(slotChildrenLen, 1);
                    }
                    else if (slotChild.isInserted) {
                        slotChild._update(changes, 1);
                    }
                }
            }
        }

        var dataChanges = this.dataChanges;
        if (dataChanges) {
            this.dataChanges = null;
            each(this.aNode.hotspot.dynamicProps, function (prop) {
                each(dataChanges, function (change) {
                    if (changeExprCompare(change.expr, prop.expr, me.data)
                        || prop.hintExpr && changeExprCompare(change.expr, prop.hintExpr, me.data)
                    ) {
                        handleProp(me, evalExpr(prop.expr, me.data, me), prop);
                        return false;
                    }
                });
            });

            elementUpdateChildren(this.children, dataChanges);
            elementUpdateChildren(this.implicitChildren, dataChanges);

            if (needReloadForSlot) {
                this._initSourceSlots();
                this._repaintChildren();
            }

            this._toPhase('updated');

            if (this.owner) {
                this._updateBindxOwner(dataChanges);
                this.owner._update();
            }
        }

        this._notifyNeedReload = null;
    };

    Component.prototype._updateBindxOwner = function (dataChanges) {
        var me = this;
        each(dataChanges, function (change) {
            each(me.binds, function (bindItem) {
                var changeExpr = change.expr;
                if (bindItem.x
                    && !isDataChangeByElement(change, me.owner)
                    && changeExprCompare(changeExpr, parseExpr(bindItem.name), me.data)
                ) {
                    var updateScopeExpr = bindItem.expr;
                    if (changeExpr.paths.length > 1) {
                        updateScopeExpr = createAccessor(
                            bindItem.expr.paths.concat(changeExpr.paths.slice(1))
                        );
                    }

                    me.scope.set(
                        updateScopeExpr,
                        evalExpr(changeExpr, me.data, me),
                        {
                            target: {
                                id: me.id,
                                prop: bindItem.name
                            }
                        }
                    );
                }
            });
        });
    };

    /**
     * ���»������������
     * �� dynamic slot name ��������� slot ƥ�䷢���仯ʱ�����»���
     * ����������ػ��е�ֱ��������ܱ�֤��ͼ�����ȷ��
     */
    Component.prototype._repaintChildren = function () {
        elementDisposeChildren(this.children, 0, 1);
        this.children = [];

        this._contentReady = 0;
        this.slotChildren = [];
        elementAttach(this);
    };


    /**
     * ����ڲ��������ݱ仯�ĺ���
     *
     * @private
     * @param {Object} change ���ݱ仯��Ϣ
     */
    Component.prototype._dataChanger = function (change) {
        if (this.lifeCycle.created && this._aftercreated) {
            if (!this.dataChanges) {
                nextTick(this._update, this);
                this.dataChanges = [];
            }

            this.dataChanges.push(change);
        }
        else if (this.lifeCycle.inited && this.owner) {
            this._updateBindxOwner([change]);
        }
    };


    /**
     * ������������ݱ仯
     *
     * @param {string} dataName �仯��������
     * @param {Function} listener ��������
     */
    Component.prototype.watch = function (dataName, listener) {
        var dataExpr = parseExpr(dataName);

        this.data.listen(bind(function (change) {
            if (changeExprCompare(change.expr, dataExpr, this.data)) {
                listener.call(this, evalExpr(dataExpr, this.data, this), change);
            }
        }, this));
    };

    /**
     * ������ٵ���Ϊ
     *
     * @param {Object} options ������Ϊ�Ĳ���
     */
    Component.prototype.dispose = elementOwnDispose;

    Component.prototype._doneLeave = function () {
        if (this.leaveDispose) {
            if (!this.lifeCycle.disposed) {
                // ���ﲻ�ð������� dispose �ˣ���Ϊ children �ͷ�������õ�
                this.slotChildren = null;

                this.data.unlisten();
                this.dataChanger = null;
                this.dataChanges = null;

                elementDispose(
                    this,
                    this.disposeNoDetach,
                    this.disposeNoTransition
                );
                this.listeners = null;

                this.source = null;
                this.sourceSlots = null;
                this.sourceSlotNameProps = null;

                this.implicitChildren = null;
            }
        }
        else if (this.lifeCycle.attached) {
            removeEl(this.el);
            this._toPhase('detached');
        }
    };

    /**
     * ������ attached �����Ϊ
     *
     * @param {Object} element Ԫ�ؽڵ�
     */
    Component.prototype._attached = elementOwnAttached;

    Component.prototype.attach = elementOwnAttach;
    Component.prototype.detach = elementOwnDetach;
    Component.prototype._create = elementOwnCreate;
    Component.prototype._onEl = elementOwnOnEl;


// exports = module.exports = Component;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���������
     */

// var Component = require('./component');
// var inherits = require('../util/inherits');

    /**
     * ���������
     *
     * @param {Object} proto �����ķ�����
     * @param {Function=} SuperComponent �������
     * @return {Function}
     */
    function defineComponent(proto, SuperComponent) {
        // �������һ������ san component �� constructor��ֱ�ӷ��ز���������캯��
        // ���ֳ������µĴ��� san ���迼��
        if (typeof proto === 'function') {
            return proto;
        }

        // #[begin] error
        if (typeof proto !== 'object') {
            throw new Error('[SAN FATAL] param must be a plain object.');
        }
        // #[end]

        function ComponentClass(option) { // eslint-disable-line
            Component.call(this, option);
        }

        ComponentClass.prototype = proto;
        inherits(ComponentClass, SuperComponent || Component);

        return ComponentClass;
    }

// exports = module.exports = defineComponent;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���������
     */


// var createANode = require('../parser/create-a-node');
// var parseTemplate = require('../parser/parse-template');
// var parseText = require('../parser/parse-text');
// var defineComponent = require('./define-component');


    /**
     * ��������ࡣԤ����template��components
     *
     * @param {Function} ComponentClass �����
     */
    function compileComponent(ComponentClass) {
        var proto = ComponentClass.prototype;

        // pre define components class
        if (!proto.hasOwnProperty('_cmptReady')) {
            proto.components = ComponentClass.components || proto.components || {};
            var components = proto.components;

            for (var key in components) { // eslint-disable-line
                var componentClass = components[key];

                if (typeof componentClass === 'object' && !(componentClass instanceof ComponentLoader)) {
                    components[key] = defineComponent(componentClass);
                }
                else if (componentClass === 'self') {
                    components[key] = ComponentClass;
                }
            }

            proto._cmptReady = 1;
        }


        // pre compile template
        if (!proto.hasOwnProperty('aNode')) {
            proto.aNode = createANode();

            var tpl = ComponentClass.template || proto.template;
            if (tpl) {
                var aNode = parseTemplate(tpl, {
                    trimWhitespace: proto.trimWhitespace || ComponentClass.trimWhitespace,
                    delimiters: proto.delimiters || ComponentClass.delimiters
                });
                var firstChild = aNode.children[0];

                // #[begin] error
                if (aNode.children.length !== 1 || firstChild.textExpr) {
                    throw new Error('[SAN FATAL] template must have a root element.');
                }
                // #[end]

                proto.aNode = firstChild;
                if (firstChild.tagName === 'template') {
                    firstChild.tagName = null;
                }

                var componentPropExtra = {
                    'class': {name: 'class', expr: parseText('{{class | _class | _sep(" ")}}')},
                    'style': {name: 'style', expr: parseText('{{style | _style | _sep(";")}}')},
                    'id': {name: 'id', expr: parseText('{{id}}')}
                };

                var len = firstChild.props.length;
                while (len--) {
                    var prop = firstChild.props[len];
                    var extra = componentPropExtra[prop.name];

                    if (extra) {
                        firstChild.props.splice(len, 1);
                        componentPropExtra[prop.name] = prop;

                        if (prop.name !== 'id') {
                            prop.expr.segs.push(extra.expr.segs[0]);
                            prop.expr.value = null;
                        }
                    }
                }

                firstChild.props.push(
                    componentPropExtra['class'], // eslint-disable-line dot-notation
                    componentPropExtra.style,
                    componentPropExtra.id
                );
            }
        }
    }

// exports = module.exports = compileComponent;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ANodeԤ��
     */

// var ExprType = require('../parser/expr-type');
// var each = require('../util/each');
// var createEl = require('../browser/create-el');
// var getPropHandler = require('./get-prop-handler');
// var getANodeProp = require('./get-a-node-prop');
// var isBrowser = require('../browser/is-browser');

    /**
     * ANodeԤ�ȣ��������������õ���Ϣ
     *
     * @param {Object} aNode ҪԤ�ȵ�ANode
     */
    function preheatANode(aNode) {
        var stack = [];

        function recordHotspotData(refs, notContentData) {
            var len = stack.length;
            each(stack, function (aNode, index) {
                if (!notContentData || index !== len - 1) {
                    each(refs, function (ref) {
                        aNode.hotspot.data[ref] = 1;
                    });
                }
            });
        }


        function analyseANodeHotspot(aNode) {
            if (!aNode.hotspot) {
                stack.push(aNode);


                if (aNode.textExpr) {
                    aNode.hotspot = { data: {} };
                    recordHotspotData(analyseExprDataHotspot(aNode.textExpr));
                }
                else {
                    var sourceNode;
                    if (isBrowser && aNode.tagName
                        && !/^(template|slot|select|input|option|button)$/i.test(aNode.tagName)
                    ) {
                        sourceNode = createEl(aNode.tagName);
                    }

                    aNode.hotspot = {
                        data: {},
                        dynamicProps: [],
                        xProps: [],
                        props: {},
                        sourceNode: sourceNode
                    };


                    // === analyse hotspot data: start
                    each(aNode.vars, function (varItem) {
                        recordHotspotData(analyseExprDataHotspot(varItem.expr));
                    });

                    each(aNode.props, function (prop) {
                        recordHotspotData(analyseExprDataHotspot(prop.expr));
                    });

                    for (var key in aNode.directives) {
                        if (aNode.directives.hasOwnProperty(key)) {
                            var directive = aNode.directives[key];
                            recordHotspotData(
                                analyseExprDataHotspot(directive.value),
                                !/^(html|bind)$/.test(key)
                            );

                            // init trackBy getKey function
                            if (key === 'for') {
                                var trackBy = directive.trackBy;
                                if (trackBy
                                    && trackBy.type === 4
                                    && trackBy.paths[0].value === directive.item.raw
                                ) {
                                    aNode.hotspot.getForKey = new Function(
                                        directive.item.raw,
                                        'return ' + trackBy.raw
                                    );
                                }
                            }
                        }
                    }

                    each(aNode.elses, function (child) {
                        analyseANodeHotspot(child);
                    });

                    each(aNode.children, function (child) {
                        analyseANodeHotspot(child);
                    });
                    // === analyse hotspot data: end


                    // === analyse hotspot props: start
                    each(aNode.props, function (prop, index) {
                        aNode.hotspot.props[prop.name] = index;

                        if (prop.name === 'id') {
                            prop.id = true;
                            aNode.hotspot.idProp = prop;
                            aNode.hotspot.dynamicProps.push(prop);
                        }
                        else if (prop.expr.value != null) {
                            if (sourceNode) {
                                getPropHandler(aNode.tagName, prop.name)
                                    .prop(sourceNode, prop.expr.value, prop.name, aNode);
                            }
                        }
                        else {
                            if (prop.x) {
                                aNode.hotspot.xProps.push(prop);
                            }
                            aNode.hotspot.dynamicProps.push(prop);
                        }
                    });

                    // ie �£���� option û�� value ���ԣ�select.value = xx ��������ѡ�� option
                    // ����û������ value ʱ��Ĭ�ϰ� option ��������Ϊ value
                    if (aNode.tagName === 'option'
                        && !getANodeProp(aNode, 'value')
                        && aNode.children[0]
                    ) {
                        var valueProp = {
                            name: 'value',
                            expr: aNode.children[0].textExpr
                        };
                        aNode.props.push(valueProp);
                        aNode.hotspot.dynamicProps.push(valueProp);
                        aNode.hotspot.props.value = aNode.props.length - 1;
                    }
                    // === analyse hotspot props: end
                }

                stack.pop();
            }
        }

        if (aNode && !aNode.hotspot) {
            analyseANodeHotspot(aNode);
        }
    }

    /**
     * ��������ʽ����������
     *
     * @param {Object} expr Ҫ�����ı���ʽ
     * @return {Array}
     */
    function analyseExprDataHotspot(expr) {
        var refs = [];

        function analyseExprs(exprs) {
            each(exprs, function (expr) {
                refs = refs.concat(analyseExprDataHotspot(expr));
            });
        }

        switch (expr.type) {
            case 4:
                var paths = expr.paths;
                refs.push(paths[0].value);

                if (paths.length > 1) {
                    refs.push(paths[0].value + '.' + (paths[1].value || '*'));
                }

                analyseExprs(paths.slice(1));
                break;

            case 9:
                return analyseExprDataHotspot(expr.expr);

            case 7:
            case 8:
            case 10:
                analyseExprs(expr.segs);
                break;

            case 5:
                refs = analyseExprDataHotspot(expr.expr);

                each(expr.filters, function (filter) {
                    analyseExprs(filter.name.paths);
                    analyseExprs(filter.args);
                });

                break;

        }

        return refs;
    }

// exports = module.exports = preheatANode;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �� binds �� name �� kebabcase ת���� camelcase
     */

// var kebab2camel = require('../util/kebab2camel');
// var each = require('../util/each');

    /**
     * �� binds �� name �� kebabcase ת���� camelcase
     *
     * @param {Array} binds binds����
     * @return {Array}
     */
    function camelComponentBinds(binds) {
        var result = [];
        each(binds, function (bind) {
            result.push({
                name: kebab2camel(bind.name),
                expr: bind.expr,
                x: bind.x,
                raw: bind.raw
            });
        });

        return result;
    }

// exports = module.exports = camelComponentBinds;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���Loader��
     */

// var nextTick = require('../util/next-tick');
// var each = require('../util/each');


    /**
     * ���Loader��
     *
     * @class
     *
     * @param {Object} options loader����
     * @param {Function} options.load load����
     * @param {Function=} options.loading loading��������Ⱦ�����
     * @param {Function=} options.fallback loadʧ��ʱ��Ⱦ�����
     */
    function ComponentLoader(load, placeholder, fallback) {
        this.load = load;
        this.placeholder = placeholder;
        this.fallback = fallback;

        this.listeners = [];
    }


    /**
     * ��ʼ�������
     *
     * @param {Function} onload ���������ɼ�������
     */
    ComponentLoader.prototype.start = function (onload) {
        var me = this;

        switch (this.state) {
            case 2:
                nextTick(function () {
                    onload(me.Component);
                });
                break;

            case 1:
                this.listeners.push(onload);
                break;

            default:
                this.listeners.push(onload);
                this.state = 1;

                var startLoad = this.load();
                var done = function (RealComponent) {
                    me.done(RealComponent);
                };

                if (startLoad && typeof startLoad.then === 'function') {
                    startLoad.then(done, done);
                }
        }
    };

    /**
     * ����������
     *
     * @param {Function=} ComponentClass �����
     */
    ComponentLoader.prototype.done = function (ComponentClass) {
        this.state = 2;
        ComponentClass = ComponentClass || this.fallback;
        this.Component = ComponentClass;

        each(this.listeners, function (listener) {
            listener(ComponentClass);
        });
    };

// exports = module.exports = ComponentLoader;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file �������Loader
     */

// var ComponentLoader = require('./component-loader');

    /**
     * �������Loader
     *
     * @param {Object|Function} options �������Loader�Ĳ�����ΪObjectʱ�ο��·�������ΪFunctionʱ����load������
     * @param {Function} options.load load����
     * @param {Function=} options.placeholder loading��������Ⱦ��ռλ���
     * @param {Function=} options.fallback loadʧ��ʱ��Ⱦ�����
     * @return {ComponentLoader}
     */
    function createComponentLoader(options) {
        var placeholder = options.placeholder;
        var fallback = options.fallback;
        var load = typeof options === 'function' ? options : options.load;

        return new ComponentLoader(load, placeholder, fallback);
    }

// exports = module.exports = createComponentLoader;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Դ��� helper ��������
     */

// var each = require('../util/each');
// var ExprType = require('../parser/expr-type');

// #[begin] ssr
//
// /**
//  * ����Դ��� helper �������϶���
//  */
// var compileExprSource = {
//
//     /**
//      * �ַ������滯
//      *
//      * @param {string} source ��Ҫ���滯���ַ���
//      * @return {string} �ַ������滯���
//      */
//     stringLiteralize: function (source) {
//         return '"'
//             + source
//                 .replace(/\x5C/g, '\\\\')
//                 .replace(/"/g, '\\"')
//                 .replace(/\x0A/g, '\\n')
//                 .replace(/\x09/g, '\\t')
//                 .replace(/\x0D/g, '\\r')
//                 // .replace( /\x08/g, '\\b' )
//                 // .replace( /\x0C/g, '\\f' )
//             + '"';
//     },
//
//     /**
//      * �������ݷ��ʱ���ʽ����
//      *
//      * @param {Object?} accessorExpr accessor����ʽ����
//      * @return {string}
//      */
//     dataAccess: function (accessorExpr) {
//         var code = 'componentCtx.data';
//         if (accessorExpr) {
//             each(accessorExpr.paths, function (path) {
//                 if (path.type === 4) {
//                     code += '[' + compileExprSource.dataAccess(path) + ']';
//                     return;
//                 }
//
//                 switch (typeof path.value) {
//                     case 'string':
//                         code += '.' + path.value;
//                         break;
//
//                     case 'number':
//                         code += '[' + path.value + ']';
//                         break;
//                 }
//             });
//         }
//
//         return code;
//     },
//
//     /**
//      * ���ɵ��ñ���ʽ����
//      *
//      * @param {Object?} callExpr ���ñ���ʽ����
//      * @return {string}
//      */
//     callExpr: function (callExpr) {
//         var paths = callExpr.name.paths;
//         var code = 'componentCtx.' + paths[0].value;
//
//         for (var i = 1; i < paths.length; i++) {
//             var path = paths[i];
//
//             switch (path.type) {
//                 case 1:
//                     code += '.' + path.value;
//                     break;
//
//                 case 2:
//                     code += '[' + path.value + ']';
//                     break;
//
//                 default:
//                     code += '[' + compileExprSource.expr(path) + ']';
//             }
//         }
//
//         code += '(';
//         each(callExpr.args, function (arg, index) {
//             code += (index > 0 ? ', ' : '') + compileExprSource.expr(arg);
//         });
//         code += ')';
//
//         return code;
//     },
//
//     /**
//      * ���ɲ�ֵ����
//      *
//      * @param {Object} interpExpr ��ֵ����ʽ����
//      * @return {string}
//      */
//     interp: function (interpExpr) {
//         var code = compileExprSource.expr(interpExpr.expr);
//
//
//         each(interpExpr.filters, function (filter) {
//             code = 'componentCtx.callFilter("' + filter.name.paths[0].value + '", [' + code;
//             each(filter.args, function (arg) {
//                 code += ', ' + compileExprSource.expr(arg);
//             });
//             code += '])';
//         });
//
//         if (!interpExpr.original) {
//             return 'escapeHTML(' + code + ')';
//         }
//
//         return code;
//     },
//
//     /**
//      * �����ı�Ƭ�δ���
//      *
//      * @param {Object} textExpr �ı�Ƭ�α���ʽ����
//      * @return {string}
//      */
//     text: function (textExpr) {
//         if (textExpr.segs.length === 0) {
//             return '""';
//         }
//
//         var code = '';
//
//         each(textExpr.segs, function (seg) {
//             var segCode = compileExprSource.expr(seg);
//             code += code ? ' + ' + segCode : segCode;
//         });
//
//         return code;
//     },
//
//     /**
//      * ������������������
//      *
//      * @param {Object} arrayExpr ��������������ʽ����
//      * @return {string}
//      */
//     array: function (arrayExpr) {
//         var code = [];
//
//         each(arrayExpr.items, function (item) {
//             code.push((item.spread ? '...' : '') + compileExprSource.expr(item.expr));
//         });
//
//         return '[\n' + code.join(',\n') + '\n]';
//     },
//
//     /**
//      * ���ɶ�������������
//      *
//      * @param {Object} objExpr ��������������ʽ����
//      * @return {string}
//      */
//     object: function (objExpr) {
//         var code = [];
//
//         each(objExpr.items, function (item) {
//             if (item.spread) {
//                 code.push('...' + compileExprSource.expr(item.expr));
//             }
//             else {
//                 code.push(compileExprSource.expr(item.name) + ':' + compileExprSource.expr(item.expr));
//             }
//         });
//
//         return '{\n' + code.join(',\n') + '\n}';
//     },
//
//     /**
//      * ��Ԫ����ʽ������ӳ���
//      *
//      * @type {Object}
//      */
//     binaryOp: {
//         /* eslint-disable */
//         43: '+',
//         45: '-',
//         42: '*',
//         47: '/',
//         60: '<',
//         62: '>',
//         76: '&&',
//         94: '!=',
//         121: '<=',
//         122: '==',
//         123: '>=',
//         155: '!==',
//         183: '===',
//         248: '||'
//         /* eslint-enable */
//     },
//
//     /**
//      * ���ɱ���ʽ����
//      *
//      * @param {Object} expr ����ʽ����
//      * @return {string}
//      */
//     expr: function (expr) {
//         if (expr.parenthesized) {
//             return '(' + compileExprSource._expr(expr) + ')';
//         }
//
//         return compileExprSource._expr(expr);
//     },
//
//     /**
//      * ���ݱ���ʽ���ͽ������ɴ��뺯������ת�ַ�
//      *
//      * @param {Object} expr ����ʽ����
//      * @return {string}
//      */
//     _expr: function (expr) {
//         switch (expr.type) {
//             case 9:
//                 switch (expr.operator) {
//                     case 33:
//                         return '!' + compileExprSource.expr(expr.expr);
//                     case 45:
//                         return '-' + compileExprSource.expr(expr.expr);
//                 }
//
//             case 8:
//                 return compileExprSource.expr(expr.segs[0])
//                     + compileExprSource.binaryOp[expr.operator]
//                     + compileExprSource.expr(expr.segs[1]);
//
//             case 10:
//                 return compileExprSource.expr(expr.segs[0])
//                     + '?' + compileExprSource.expr(expr.segs[1])
//                     + ':' + compileExprSource.expr(expr.segs[2]);
//
//             case 1:
//                 return compileExprSource.stringLiteralize(expr.literal || expr.value);
//
//             case 2:
//                 return expr.value;
//
//             case 3:
//                 return expr.value ? 'true' : 'false';
//
//             case 4:
//                 return compileExprSource.dataAccess(expr);
//
//             case 5:
//                 return compileExprSource.interp(expr);
//
//             case 7:
//                 return compileExprSource.text(expr);
//
//             case 12:
//                 return compileExprSource.array(expr);
//
//             case 11:
//                 return compileExprSource.object(expr);
//
//             case 6:
//                 return compileExprSource.callExpr(expr);
//         }
//     }
// };
// #[end]

// exports = module.exports = compileExprSource;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ����Դ����м�buffer��
     */

// var each = require('../util/each');
// var compileExprSource = require('./compile-expr-source');


// #[begin] ssr
// /**
//  * ����Դ����м�buffer��
//  *
//  * @class
//  */
// function CompileSourceBuffer() {
//     this.segs = [];
// }
//
// /**
//  * ����ԭʼ���룬��ԭ�ⲻ�����
//  *
//  * @param {string} code ԭʼ����
//  */
// CompileSourceBuffer.prototype.addRaw = function (code) {
//     this.segs.push({
//         type: 'RAW',
//         code: code
//     });
// };
//
// /**
//  * ���ӱ�ƴ��Ϊhtml��ԭʼ����
//  *
//  * @param {string} code ԭʼ����
//  */
// CompileSourceBuffer.prototype.joinRaw = function (code) {
//     this.segs.push({
//         type: 'JOIN_RAW',
//         code: code
//     });
// };
//
// /**
//  * ����renderer��������ʼԴ��
//  */
// CompileSourceBuffer.prototype.addRendererStart = function () {
//     this.addRaw('function (data, parentCtx, sourceSlots) {');
//     this.addRaw('var html = "";');
// };
//
// /**
//  * ����renderer�����Ľ���Դ��
//  */
// CompileSourceBuffer.prototype.addRendererEnd = function () {
//     this.addRaw('return html;');
//     this.addRaw('}');
// };
//
// /**
//  * ���ӱ�ƴ��Ϊhtml�ľ�̬�ַ���
//  *
//  * @param {string} str ��ƴ�ӵ��ַ���
//  */
// CompileSourceBuffer.prototype.joinString = function (str) {
//     this.segs.push({
//         str: str,
//         type: 'JOIN_STRING'
//     });
// };
//
// /**
//  * ���ӱ�ƴ��Ϊhtml�����ݷ���
//  *
//  * @param {Object?} accessor ���ݷ��ʱ���ʽ����
//  */
// CompileSourceBuffer.prototype.joinDataStringify = function () {
//     this.segs.push({
//         type: 'JOIN_DATA_STRINGIFY'
//     });
// };
//
// /**
//  * ���ӱ�ƴ��Ϊhtml�ı���ʽ
//  *
//  * @param {Object} expr ����ʽ����
//  */
// CompileSourceBuffer.prototype.joinExpr = function (expr) {
//     this.segs.push({
//         expr: expr,
//         type: 'JOIN_EXPR'
//     });
// };
//
// /**
//  * ���ɱ�������
//  *
//  * @return {string}
//  */
// CompileSourceBuffer.prototype.toCode = function () {
//     var code = [];
//     var temp = '';
//
//     function genStrLiteral() {
//         if (temp) {
//             code.push('html += ' + compileExprSource.stringLiteralize(temp) + ';');
//         }
//
//         temp = '';
//     }
//
//     each(this.segs, function (seg) {
//         if (seg.type === 'JOIN_STRING') {
//             temp += seg.str;
//             return;
//         }
//
//         genStrLiteral();
//         switch (seg.type) {
//             case 'JOIN_DATA_STRINGIFY':
//                 code.push('html += stringifier.any(' + compileExprSource.dataAccess() + ');');
//                 break;
//
//             case 'JOIN_EXPR':
//                 code.push('html += ' + compileExprSource.expr(seg.expr) + ';');
//                 break;
//
//             case 'JOIN_RAW':
//                 code.push('html += ' + seg.code + ';');
//                 break;
//
//             case 'RAW':
//                 code.push(seg.code);
//                 break;
//
//         }
//     });
//
//     genStrLiteral();
//
//     return code.join('\n');
// };
//
// #[end]

// exports = module.exports = CompileSourceBuffer;


    /**
     * Copyright (c) Baidu Inc. All rights reserved.
     *
     * This source code is licensed under the MIT license.
     * See LICENSE file in the project root for license information.
     *
     * @file ���������� render ������ js Դ��
     */


// var each = require('../util/each');
// var guid = require('../util/guid');
// var splitStr2Obj = require('../util/split-str-2-obj');
// var parseExpr = require('../parser/parse-expr');
// var createANode = require('../parser/create-a-node');
// var cloneDirectives = require('../parser/clone-directives');
// var autoCloseTags = require('../browser/auto-close-tags');
// var CompileSourceBuffer = require('./compile-source-buffer');
// var compileExprSource = require('./compile-expr-source');
// var rinseCondANode = require('./rinse-cond-anode');
// var getANodeProp = require('./get-a-node-prop');
// var ComponentLoader = require('./component-loader');

// #[begin] ssr
//
// /**
//  * �������л�ʱ��ʼ׮��html
//  *
//  * @param {string} type ׮���ͱ�ʶ
//  * @param {string?} content ׮�ڵ�����
//  * @return {string}
//  */
// function serializeStump(type, content) {
//     return '<!--s-' + type + (content ? ':' + content : '') + '-->';
// }
//
// /**
//  * �������л�ʱ����׮��html
//  *
//  * @param {string} type ׮���ͱ�ʶ
//  * @return {string}
//  */
// function serializeStumpEnd(type) {
//     return '<!--/s-' + type + '-->';
// }
//
// /**
//  * element �ı��뷽�����϶���
//  *
//  * @inner
//  */
// var elementSourceCompiler = {
//
//     /* eslint-disable max-params */
//     /**
//      * ����Ԫ�ر�ǩͷ
//      *
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {string} tagName ��ǩ��
//      * @param {Array} props �����б�
//      * @param {string=} extraProp ��������Դ�
//      * @param {Object=} bindDirective bindָ�����
//      */
//     tagStart: function (sourceBuffer, tagName, props, extraProp, bindDirective) {
//         sourceBuffer.joinString('<' + tagName);
//         sourceBuffer.joinString(extraProp || '');
//
//         // index list
//         var propsIndex = {};
//         each(props, function (prop) {
//             propsIndex[prop.name] = prop;
//         });
//
//         each(props, function (prop) {
//             if (prop.name === 'slot') {
//                 return;
//             }
//
//             if (prop.name === 'value') {
//                 switch (tagName) {
//                     case 'textarea':
//                         return;
//
//                     case 'select':
//                         sourceBuffer.addRaw('$selectValue = '
//                             + compileExprSource.expr(prop.expr)
//                             + ' || "";'
//                         );
//                         return;
//
//                     case 'option':
//                         sourceBuffer.addRaw('$optionValue = '
//                             + compileExprSource.expr(prop.expr)
//                             + ';'
//                         );
//                         // value
//                         sourceBuffer.addRaw('if ($optionValue != null) {');
//                         sourceBuffer.joinRaw('" value=\\"" + $optionValue + "\\""');
//                         sourceBuffer.addRaw('}');
//
//                         // selected
//                         sourceBuffer.addRaw('if ($optionValue === $selectValue) {');
//                         sourceBuffer.joinString(' selected');
//                         sourceBuffer.addRaw('}');
//                         return;
//                 }
//             }
//
//             switch (prop.name) {
//                 case 'readonly':
//                 case 'disabled':
//                 case 'multiple':
//                     if (prop.raw === '') {
//                         sourceBuffer.joinString(' ' + prop.name);
//                     }
//                     else {
//                         sourceBuffer.joinRaw('boolAttrFilter("' + prop.name + '", '
//                             + compileExprSource.expr(prop.expr)
//                             + ')'
//                         );
//                     }
//                     break;
//
//                 case 'checked':
//                     if (tagName === 'input') {
//                         var valueProp = propsIndex.value;
//                         var valueCode = compileExprSource.expr(valueProp.expr);
//
//                         if (valueProp) {
//                             switch (propsIndex.type.raw) {
//                                 case 'checkbox':
//                                     sourceBuffer.addRaw('if (contains('
//                                         + compileExprSource.expr(prop.expr)
//                                         + ', '
//                                         + valueCode
//                                         + ')) {'
//                                     );
//                                     sourceBuffer.joinString(' checked');
//                                     sourceBuffer.addRaw('}');
//                                     break;
//
//                                 case 'radio':
//                                     sourceBuffer.addRaw('if ('
//                                         + compileExprSource.expr(prop.expr)
//                                         + ' === '
//                                         + valueCode
//                                         + ') {'
//                                     );
//                                     sourceBuffer.joinString(' checked');
//                                     sourceBuffer.addRaw('}');
//                                     break;
//                             }
//                         }
//                     }
//                     break;
//
//                 default:
//                     if (prop.attr) {
//                         sourceBuffer.joinString(' ' + prop.attr);
//                     }
//                     else {
//                         sourceBuffer.joinRaw('attrFilter("' + prop.name + '", '
//                             + (prop.x ? 'escapeHTML(' : '')
//                             + compileExprSource.expr(prop.expr)
//                             + (prop.x ? ')' : '')
//                             + ')'
//                         );
//                     }
//                     break;
//             }
//         });
//
//         if (bindDirective) {
//             sourceBuffer.addRaw(
//                 '(function ($bindObj) {for (var $key in $bindObj) {'
//                 + 'var $value = $bindObj[$key];'
//             );
//
//             if (tagName === 'textarea') {
//                 sourceBuffer.addRaw(
//                     'if ($key === "value") {'
//                     + 'continue;'
//                     + '}'
//                 );
//             }
//
//             sourceBuffer.addRaw('switch ($key) {\n'
//                 + 'case "readonly":\n'
//                 + 'case "disabled":\n'
//                 + 'case "multiple":\n'
//                 + 'case "multiple":\n'
//                 + 'html += boolAttrFilter($key, escapeHTML($value));\n'
//                 + 'break;\n'
//                 + 'default:\n'
//                 + 'html += attrFilter($key, escapeHTML($value));'
//                 + '}'
//             );
//
//             sourceBuffer.addRaw(
//                 '}})('
//                 + compileExprSource.expr(bindDirective.value)
//                 + ');'
//             );
//         }
//
//         sourceBuffer.joinString('>');
//     },
//     /* eslint-enable max-params */
//
//     /**
//      * ����Ԫ�رպ�
//      *
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {string} tagName ��ǩ��
//      */
//     tagEnd: function (sourceBuffer, tagName) {
//         if (!autoCloseTags[tagName]) {
//             sourceBuffer.joinString('</' + tagName + '>');
//         }
//
//         if (tagName === 'select') {
//             sourceBuffer.addRaw('$selectValue = null;');
//         }
//
//         if (tagName === 'option') {
//             sourceBuffer.addRaw('$optionValue = null;');
//         }
//     },
//
//     /**
//      * ����Ԫ������
//      *
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {ANode} aNode Ԫ�صĳ���ڵ���Ϣ
//      * @param {Component} owner �������ʵ������
//      */
//     inner: function (sourceBuffer, aNode, owner) {
//         // inner content
//         if (aNode.tagName === 'textarea') {
//             var valueProp = getANodeProp(aNode, 'value');
//             if (valueProp) {
//                 sourceBuffer.joinRaw('escapeHTML('
//                     + compileExprSource.expr(valueProp.expr)
//                     + ')'
//                 );
//             }
//
//             return;
//         }
//
//         var htmlDirective = aNode.directives.html;
//         if (htmlDirective) {
//             sourceBuffer.joinExpr(htmlDirective.value);
//         }
//         else {
//             /* eslint-disable no-use-before-define */
//             each(aNode.children, function (aNodeChild) {
//                 sourceBuffer.addRaw(aNodeCompiler.compile(aNodeChild, sourceBuffer, owner));
//             });
//             /* eslint-enable no-use-before-define */
//         }
//     }
// };
//
// /**
//  * ANode �ı��뷽�����϶���
//  *
//  * @inner
//  */
// var aNodeCompiler = {
//
//     /**
//      * ����ڵ�
//      *
//      * @param {ANode} aNode ����ڵ�
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      * @param {Object} extra ���������һЩ������Ϣ
//      */
//     compile: function (aNode, sourceBuffer, owner, extra) {
//         extra = extra || {};
//         var compileMethod = 'compileElement';
//
//         if (aNode.textExpr) {
//             compileMethod = 'compileText';
//         }
//         else if (aNode.directives['if']) { // eslint-disable-line dot-notation
//             compileMethod = 'compileIf';
//         }
//         else if (aNode.directives['for']) { // eslint-disable-line dot-notation
//             compileMethod = 'compileFor';
//         }
//         else if (aNode.tagName === 'slot') {
//             compileMethod = 'compileSlot';
//         }
//         else if (aNode.tagName === 'template') {
//             compileMethod = 'compileTemplate';
//         }
//         else {
//             var ComponentType = owner.getComponentType
//                 ? owner.getComponentType(aNode)
//                 : owner.components[aNode.tagName];
//
//             if (ComponentType) {
//                 compileMethod = 'compileComponent';
//                 extra.ComponentClass = ComponentType;
//
//                 if (ComponentType instanceof ComponentLoader) {
//                     compileMethod = 'compileComponentLoader';
//                 }
//             }
//         }
//
//         aNodeCompiler[compileMethod](aNode, sourceBuffer, owner, extra);
//     },
//
//     /**
//      * �����ı��ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      */
//     compileText: function (aNode, sourceBuffer) {
//         if (aNode.textExpr.original) {
//             sourceBuffer.joinString(serializeStump('text'));
//         }
//
//         sourceBuffer.joinExpr(aNode.textExpr);
//
//         if (aNode.textExpr.original) {
//             sourceBuffer.joinString(serializeStumpEnd('text'));
//         }
//     },
//
//     /**
//      * ����template�ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      */
//     compileTemplate: function (aNode, sourceBuffer, owner) {
//         elementSourceCompiler.inner(sourceBuffer, aNode, owner);
//     },
//
//     /**
//      * ���� if �ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      */
//     compileIf: function (aNode, sourceBuffer, owner) {
//         sourceBuffer.addRaw('(function () {');
//
//         sourceBuffer.addRaw('var ifIndex = null;');
//
//         // output main if
//         var ifDirective = aNode.directives['if']; // eslint-disable-line dot-notation
//         sourceBuffer.addRaw('if (' + compileExprSource.expr(ifDirective.value) + ') {');
//         sourceBuffer.addRaw(
//             aNodeCompiler.compile(
//                 rinseCondANode(aNode),
//                 sourceBuffer,
//                 owner
//             )
//         );
//         sourceBuffer.addRaw('}');
//
//         // output elif and else
//         each(aNode.elses, function (elseANode, index) {
//             var elifDirective = elseANode.directives.elif;
//             if (elifDirective) {
//                 sourceBuffer.addRaw('else if (' + compileExprSource.expr(elifDirective.value) + ') {');
//             }
//             else {
//                 sourceBuffer.addRaw('else {');
//             }
//
//             sourceBuffer.addRaw(
//                 aNodeCompiler.compile(
//                     rinseCondANode(elseANode),
//                     sourceBuffer,
//                     owner
//                 )
//             );
//             sourceBuffer.addRaw('}');
//         });
//
//         sourceBuffer.addRaw('})();');
//     },
//
//     /**
//      * ���� for �ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      */
//     compileFor: function (aNode, sourceBuffer, owner) {
//         var forElementANode = createANode({
//             children: aNode.children,
//             props: aNode.props,
//             events: aNode.events,
//             tagName: aNode.tagName,
//             directives: cloneDirectives(aNode.directives, {
//                 'for': 1
//             }),
//             hotspot: aNode.hotspot
//         });
//
//         var forDirective = aNode.directives['for']; // eslint-disable-line dot-notation
//         var itemName = forDirective.item.raw;
//         var indexName = forDirective.index.raw;
//         var listName = guid();
//
//         if (indexName === '$index') {
//             indexName = guid();
//         }
//
//         sourceBuffer.addRaw('var ' + listName + ' = ' + compileExprSource.expr(forDirective.value) + ';');
//         sourceBuffer.addRaw('if (' + listName + ' instanceof Array) {');
//
//         // for array
//         sourceBuffer.addRaw('for ('
//             + 'var ' + indexName + ' = 0; '
//             + indexName + ' < ' + listName + '.length; '
//             + indexName + '++) {'
//         );
//         sourceBuffer.addRaw('componentCtx.data.' + indexName + '=' + indexName + ';');
//         sourceBuffer.addRaw('componentCtx.data.' + itemName + '= ' + listName + '[' + indexName + '];');
//         sourceBuffer.addRaw(
//             aNodeCompiler.compile(
//                 forElementANode,
//                 sourceBuffer,
//                 owner
//             )
//         );
//         sourceBuffer.addRaw('}');
//
//         sourceBuffer.addRaw('} else if (typeof ' + listName + ' === "object") {');
//
//         // for object
//         sourceBuffer.addRaw('for (var ' + indexName + ' in ' + listName + ') {');
//         sourceBuffer.addRaw('if (' + listName + '[' + indexName + '] != null) {');
//         sourceBuffer.addRaw('componentCtx.data.' + indexName + '=' + indexName + ';');
//         sourceBuffer.addRaw('componentCtx.data.' + itemName + '= ' + listName + '[' + indexName + '];');
//         sourceBuffer.addRaw(
//             aNodeCompiler.compile(
//                 forElementANode,
//                 sourceBuffer,
//                 owner
//             )
//         );
//         sourceBuffer.addRaw('}');
//         sourceBuffer.addRaw('}');
//
//         sourceBuffer.addRaw('}');
//     },
//
//     /**
//      * ���� slot �ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      */
//     compileSlot: function (aNode, sourceBuffer, owner) {
//         sourceBuffer.addRaw('(function () {');
//
//         sourceBuffer.addRaw('function $defaultSlotRender(componentCtx) {');
//         sourceBuffer.addRaw('  var html = "";');
//         each(aNode.children, function (aNodeChild) {
//             sourceBuffer.addRaw(aNodeCompiler.compile(aNodeChild, sourceBuffer, owner));
//         });
//         sourceBuffer.addRaw('  return html;');
//         sourceBuffer.addRaw('}');
//
//         sourceBuffer.addRaw('  var $mySourceSlots = [];');
//
//         var nameProp = getANodeProp(aNode, 'name');
//         if (nameProp) {
//             sourceBuffer.addRaw('var $slotName = ' + compileExprSource.expr(nameProp.expr) + ';');
//         }
//         else {
//             sourceBuffer.addRaw('var $slotName = null;');
//         }
//
//         sourceBuffer.addRaw('var $ctxSourceSlots = componentCtx.sourceSlots;');
//         sourceBuffer.addRaw('for (var $i = 0; $i < $ctxSourceSlots.length; $i++) {');
//         sourceBuffer.addRaw('  if ($ctxSourceSlots[$i][1] == $slotName) {');
//         sourceBuffer.addRaw('    $mySourceSlots.push($ctxSourceSlots[$i][0]);');
//         sourceBuffer.addRaw('  }');
//         sourceBuffer.addRaw('}');
//
//
//         sourceBuffer.addRaw('var $isInserted = $mySourceSlots.length > 0;');
//         sourceBuffer.addRaw('if (!$isInserted) { $mySourceSlots.push($defaultSlotRender); }');
//
//         sourceBuffer.addRaw('var $slotCtx = $isInserted ? componentCtx.owner : componentCtx;');
//
//         if (aNode.vars || aNode.directives.bind) {
//             sourceBuffer.addRaw('$slotCtx = {data: extend({}, $slotCtx.data), filters: $slotCtx.filters, callFilter: $slotCtx.callFilter};'); // eslint-disable-line
//
//             if (aNode.directives.bind) {
//                 sourceBuffer.addRaw('extend($slotCtx.data, ' + compileExprSource.expr(aNode.directives.bind.value) + ');'); // eslint-disable-line
//             }
//
//             each(aNode.vars, function (varItem) {
//                 sourceBuffer.addRaw(
//                     '$slotCtx.data["' + varItem.name + '"] = '
//                     + compileExprSource.expr(varItem.expr)
//                     + ';'
//                 );
//             });
//         }
//
//         sourceBuffer.addRaw('for (var $renderIndex = 0; $renderIndex < $mySourceSlots.length; $renderIndex++) {');
//         sourceBuffer.addRaw('  html += $mySourceSlots[$renderIndex]($slotCtx);');
//         sourceBuffer.addRaw('}');
//
//         sourceBuffer.addRaw('})();');
//     },
//
//     /**
//      * ������ͨ�ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      * @param {Object} extra ���������һЩ������Ϣ
//      */
//     compileElement: function (aNode, sourceBuffer, owner, extra) {
//         extra = extra || {};
//         // if (aNode.tagName === 'option'
//         //     && !getANodeProp(aNode, 'value')
//         //     && aNode.children[0]
//         // ) {
//         //     aNode.props.push({
//         //         name: 'value',
//         //         expr: aNode.children[0].textExpr
//         //     });
//         // }
//
//         elementSourceCompiler.tagStart(
//             sourceBuffer,
//             aNode.tagName,
//             aNode.props,
//             extra.prop,
//             aNode.directives.bind
//         );
//
//         elementSourceCompiler.inner(sourceBuffer, aNode, owner);
//         elementSourceCompiler.tagEnd(sourceBuffer, aNode.tagName);
//     },
//
//     /**
//      * ��������ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      * @param {Object} extra ���������һЩ������Ϣ
//      * @param {Function} extra.ComponentClass ��Ӧ�����
//      */
//     compileComponent: function (aNode, sourceBuffer, owner, extra) {
//         if (aNode) {
//             sourceBuffer.addRaw('var $slotName = null;');
//             sourceBuffer.addRaw('var $sourceSlots = [];');
//             each(aNode.children, function (child) {
//                 var slotBind = !child.textExpr && getANodeProp(child, 'slot');
//                 if (slotBind) {
//                     sourceBuffer.addRaw('$slotName = ' + compileExprSource.expr(slotBind.expr) + ';');
//                     sourceBuffer.addRaw('$sourceSlots.push([function (componentCtx) {');
//                     sourceBuffer.addRaw('  var html = "";');
//                     sourceBuffer.addRaw(aNodeCompiler.compile(child, sourceBuffer, owner));
//                     sourceBuffer.addRaw('  return html;');
//                     sourceBuffer.addRaw('}, $slotName]);');
//                 }
//                 else {
//                     sourceBuffer.addRaw('$sourceSlots.push([function (componentCtx) {');
//                     sourceBuffer.addRaw('  var html = "";');
//                     sourceBuffer.addRaw(aNodeCompiler.compile(child, sourceBuffer, owner));
//                     sourceBuffer.addRaw('  return html;');
//                     sourceBuffer.addRaw('}]);');
//                 }
//             });
//         }
//
//         var ComponentClass = extra.ComponentClass;
//         var component = new ComponentClass({
//             source: aNode,
//             owner: owner,
//             subTag: aNode.tagName
//         });
//
//         var givenData = [];
//
//         each(component.binds, function (prop) {
//             givenData.push(
//                 compileExprSource.stringLiteralize(prop.name)
//                 + ':'
//                 + compileExprSource.expr(prop.expr)
//             );
//         });
//
//         var givenDataHTML = '{' + givenData.join(',\n') + '}';
//         if (aNode.directives.bind) {
//             givenDataHTML = 'extend('
//                 + compileExprSource.expr(aNode.directives.bind.value)
//                  + ', '
//                 + givenDataHTML
//                 + ')';
//         }
//
//         sourceBuffer.addRaw('html += (');
//         sourceBuffer.addRendererStart();
//         compileComponentSource(sourceBuffer, component, extra && extra.prop);
//         sourceBuffer.addRendererEnd();
//         sourceBuffer.addRaw(')(' + givenDataHTML + ', componentCtx, $sourceSlots);');
//         sourceBuffer.addRaw('$sourceSlots = null;');
//     },
//
//     /**
//      * ��������������ڵ�
//      *
//      * @param {ANode} aNode �ڵ����
//      * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//      * @param {Component} owner �������ʵ������
//      * @param {Object} extra ���������һЩ������Ϣ
//      * @param {Function} extra.ComponentClass ��Ӧ��
//      */
//     compileComponentLoader: function (aNode, sourceBuffer, owner, extra) {
//         var LoadingComponent = extra.ComponentClass.placeholder;
//         if (typeof LoadingComponent === 'function') {
//             aNodeCompiler.compileComponent(aNode, sourceBuffer, owner, {
//                 prop: extra.prop,
//                 ComponentClass: LoadingComponent
//             });
//         }
//     }
// };
//
// /**
//  * ������� renderer ʱ ctx ���󹹽��Ĵ���
//  *
//  * @inner
//  * @param {CompileSourceBuffer} sourceBuffer ����Դ����м�buffer
//  * @param {Object} component ���ʵ��
//  * @param {string?} extraProp ��������Դ�
//  */
// function compileComponentSource(sourceBuffer, component, extraProp) {
//     sourceBuffer.addRaw(genComponentContextCode(component));
//     sourceBuffer.addRaw('componentCtx.owner = parentCtx;');
//     sourceBuffer.addRaw('componentCtx.sourceSlots = sourceSlots;');
//
//
//     sourceBuffer.addRaw('data = extend(componentCtx.data, data);');
//     sourceBuffer.addRaw('for (var $i = 0; $i < componentCtx.computedNames.length; $i++) {');
//     sourceBuffer.addRaw('  var $computedName = componentCtx.computedNames[$i];');
//     sourceBuffer.addRaw('  data[$computedName] = componentCtx.computed[$computedName]();');
//     sourceBuffer.addRaw('}');
//
//     extraProp = extraProp || '';
//
//     var eventDeclarations = [];
//     for (var key in component.listeners) {
//         if (component.listeners.hasOwnProperty(key)) {
//             each(component.listeners[key], function (listener) {
//                 if (listener.declaration) {
//                     eventDeclarations.push(listener.declaration);
//                 }
//             });
//         }
//     }
//
//     elementSourceCompiler.tagStart(
//         sourceBuffer,
//         component.tagName,
//         component.aNode.props,
//         extraProp,
//         component.aNode.directives.bind
//     );
//
//     if (!component.owner) {
//         sourceBuffer.joinString('<!--s-data:');
//         sourceBuffer.joinDataStringify();
//         sourceBuffer.joinString('-->');
//     }
//
//
//     elementSourceCompiler.inner(sourceBuffer, component.aNode, component);
//     elementSourceCompiler.tagEnd(sourceBuffer, component.tagName);
// }
//
// var stringifier = {
//     obj: function (source) {
//         var prefixComma;
//         var result = '{';
//
//         for (var key in source) {
//             if (!source.hasOwnProperty(key) || typeof source[key] === 'undefined') {
//                 continue;
//             }
//
//             if (prefixComma) {
//                 result += ',';
//             }
//             prefixComma = 1;
//
//             result += compileExprSource.stringLiteralize(key) + ':' + stringifier.any(source[key]);
//         }
//
//         return result + '}';
//     },
//
//     arr: function (source) {
//         var prefixComma;
//         var result = '[';
//
//         each(source, function (value) {
//             if (prefixComma) {
//                 result += ',';
//             }
//             prefixComma = 1;
//
//             result += stringifier.any(value);
//         });
//
//         return result + ']';
//     },
//
//     str: function (source) {
//         return compileExprSource.stringLiteralize(source);
//     },
//
//     date: function (source) {
//         return 'new Date(' + source.getTime() + ')';
//     },
//
//     any: function (source) {
//         switch (typeof source) {
//             case 'string':
//                 return stringifier.str(source);
//
//             case 'number':
//                 return '' + source;
//
//             case 'boolean':
//                 return source ? 'true' : 'false';
//
//             case 'object':
//                 if (!source) {
//                     return null;
//                 }
//
//                 if (source instanceof Array) {
//                     return stringifier.arr(source);
//                 }
//
//                 if (source instanceof Date) {
//                     return stringifier.date(source);
//                 }
//
//                 return stringifier.obj(source);
//         }
//
//         throw new Error('Cannot Stringify:' + source);
//     }
// };
//
// var COMPONENT_RESERVED_MEMBERS = splitStr2Obj('computed,filters,components,'
//     + 'initData,template,attached,created,detached,disposed,compiled'
// );
//
// /**
//  * ������� renderer ʱ ctx ���󹹽��Ĵ���
//  *
//  * @inner
//  * @param {Object} component ���ʵ��
//  * @return {string}
//  */
// function genComponentContextCode(component) {
//     var code = ['var componentCtx = {'];
//
//     // members for call expr
//     var ComponentProto = component.constructor.prototype;
//     Object.keys(ComponentProto).forEach(function (protoMemberKey) {
//         var protoMember = ComponentProto[protoMemberKey];
//         if (COMPONENT_RESERVED_MEMBERS[protoMemberKey] || !protoMember) {
//             return;
//         }
//
//         switch (typeof protoMember) {
//             case 'function':
//                 code.push(protoMemberKey + ': ' + protoMember.toString() + ',');
//                 break;
//
//             case 'object':
//                 code.push(protoMemberKey + ':');
//
//                 if (protoMember instanceof Array) {
//                     code.push('[');
//                     protoMember.forEach(function (item) {
//                         code.push(typeof item === 'function' ? item.toString() : '' + ',');
//                     });
//                     code.push(']');
//                 }
//                 else {
//                     code.push('{');
//                     Object.keys(protoMember).forEach(function (itemKey) {
//                         var item = protoMember[itemKey];
//                         if (typeof item === 'function') {
//                             code.push(itemKey + ':' + item.toString() + ',');
//                         }
//                     });
//                     code.push('}');
//                 }
//
//                 code.push(',');
//         }
//     });
//
//     // given anode
//     code.push('sourceSlots: [],');
//
//     // filters
//     code.push('filters: {');
//     var filterCode = [];
//     for (var key in component.filters) {
//         if (component.filters.hasOwnProperty(key)) {
//             var filter = component.filters[key];
//
//             if (typeof filter === 'function') {
//                 filterCode.push(key + ': ' + filter.toString());
//             }
//         }
//     }
//     code.push(filterCode.join(','));
//     code.push('},');
//
//     code.push(
//         'callFilter: function (name, args) {',
//         '    var filter = this.filters[name] || DEFAULT_FILTERS[name];',
//         '    if (typeof filter === "function") {',
//         '        return filter.apply(this, args);',
//         '    }',
//         '},'
//     );
//
//     /* eslint-disable no-redeclare */
//     // computed obj
//     code.push('computed: {');
//     var computedCode = [];
//     for (var key in component.computed) {
//         if (component.computed.hasOwnProperty(key)) {
//             var computed = component.computed[key];
//
//             if (typeof computed === 'function') {
//                 computedCode.push(key + ': '
//                     + computed.toString().replace(
//                         /this.data.get\(([^\)]+)\)/g,
//                         function (match, exprLiteral) {
//                             var exprStr = (new Function('return ' + exprLiteral))();
//                             var expr = parseExpr(exprStr);
//
//                             return compileExprSource.expr(expr);
//                         })
//                 );
//             }
//         }
//     }
//     code.push(computedCode.join(','));
//     code.push('},');
//
//     // computed names
//     code.push('computedNames: [');
//     computedCode = [];
//     for (var key in component.computed) {
//         if (component.computed.hasOwnProperty(key)) {
//             var computed = component.computed[key];
//
//             if (typeof computed === 'function') {
//                 computedCode.push('"' + key + '"');
//             }
//         }
//     }
//     code.push(computedCode.join(','));
//     code.push('],');
//     /* eslint-enable no-redeclare */
//
//     // data
//     code.push('data: ' + stringifier.any(component.data.get()) + ',');
//
//     // tagName
//     code.push('tagName: "' + component.tagName + '"');
//     code.push('};');
//
//     return code.join('\n');
// }
//
// /* eslint-enable guard-for-in */
//
// /* eslint-disable no-unused-vars */
// /* eslint-disable fecs-camelcase */
//
// /**
//  * ��������ģ�庯��
//  *
//  * @inner
//  */
// function componentCompilePreCode() {
//     var $version = '3.7.1';
//
//     function extend(target, source) {
//         if (source) {
//             Object.keys(source).forEach(function (key) {
//                 let value = source[key];
//                 if (typeof value !== 'undefined') {
//                     target[key] = value;
//                 }
//             });
//         }
//
//         return target;
//     }
//
//     function each(array, iterator) {
//         if (array && array.length > 0) {
//             for (var i = 0, l = array.length; i < l; i++) {
//                 if (iterator(array[i], i) === false) {
//                     break;
//                 }
//             }
//         }
//     }
//
//     function contains(array, value) {
//         var result;
//         each(array, function (item) {
//             result = item === value;
//             return !result;
//         });
//
//         return result;
//     }
//
//     var HTML_ENTITY = {
//         /* jshint ignore:start */
//         '&': '&amp;',
//         '<': '&lt;',
//         '>': '&gt;',
//         '"': '&quot;',
//         /* eslint-disable quotes */
//         "'": '&#39;'
//         /* eslint-enable quotes */
//         /* jshint ignore:end */
//     };
//
//     function htmlFilterReplacer(c) {
//         return HTML_ENTITY[c];
//     }
//
//     function escapeHTML(source) {
//         if (source == null) {
//             return '';
//         }
//
//         return String(source).replace(/[&<>"']/g, htmlFilterReplacer);
//     }
//
//     var DEFAULT_FILTERS = {
//         url: encodeURIComponent,
//         _class: function (source) {
//             if (source instanceof Array) {
//                 return source.join(' ');
//             }
//
//             return source;
//         },
//         _style: function (source) {
//             if (typeof source === 'object') {
//                 var result = '';
//                 if (source) {
//                     Object.keys(source).forEach(function (key) {
//                         result += key + ':' + source[key] + ';';
//                     });
//                 }
//
//                 return result;
//             }
//
//             return source || '';
//         },
//         _sep: function (source, sep) {
//             return source ? sep + source : '';
//         }
//     };
//
//     function attrFilter(name, value) {
//         if (value) {
//             return ' ' + name + '="' + value + '"';
//         }
//
//         return '';
//     }
//
//     function boolAttrFilter(name, value) {
//         if (value && value !== 'false' && value !== '0') {
//             return ' ' + name;
//         }
//
//         return '';
//     }
//
//     function stringLiteralize(source) {
//         return '"'
//             + source
//                 .replace(/\x5C/g, '\\\\')
//                 .replace(/"/g, '\\"')
//                 .replace(/\x0A/g, '\\n')
//                 .replace(/\x09/g, '\\t')
//                 .replace(/\x0D/g, '\\r')
//             + '"';
//     }
//
//     var stringifier = {
//         obj: function (source) {
//             var prefixComma;
//             var result = '{';
//
//             Object.keys(source).forEach(function (key) {
//                 if (typeof source[key] === 'undefined') {
//                     return;
//                 }
//
//                 if (prefixComma) {
//                     result += ',';
//                 }
//                 prefixComma = 1;
//
//                 result += stringLiteralize(key) + ':' + stringifier.any(source[key]);
//             });
//
//             return result + '}';
//         },
//
//         arr: function (source) {
//             var prefixComma;
//             var result = '[';
//
//             each(source, function (value) {
//                 if (prefixComma) {
//                     result += ',';
//                 }
//                 prefixComma = 1;
//
//                 result += stringifier.any(value);
//             });
//
//             return result + ']';
//         },
//
//         str: function (source) {
//             return stringLiteralize(source);
//         },
//
//         date: function (source) {
//             return 'new Date(' + source.getTime() + ')';
//         },
//
//         any: function (source) {
//             switch (typeof source) {
//                 case 'string':
//                     return stringifier.str(source);
//
//                 case 'number':
//                     return '' + source;
//
//                 case 'boolean':
//                     return source ? 'true' : 'false';
//
//                 case 'object':
//                     if (!source) {
//                         return null;
//                     }
//
//                     if (source instanceof Array) {
//                         return stringifier.arr(source);
//                     }
//
//                     if (source instanceof Date) {
//                         return stringifier.date(source);
//                     }
//
//                     return stringifier.obj(source);
//             }
//
//             throw new Error('Cannot Stringify:' + source);
//         }
//     };
// }
// /* eslint-enable no-unused-vars */
// /* eslint-enable fecs-camelcase */
//
// /**
//  * ���������� render ������ js Դ��
//  *
//  * @param {Function} ComponentClass �����
//  * @return {string}
//  */
// function compileJSSource(ComponentClass) {
//     var sourceBuffer = new CompileSourceBuffer();
//
//     sourceBuffer.addRendererStart();
//     sourceBuffer.addRaw(
//         componentCompilePreCode.toString()
//             .split('\n')
//             .slice(1)
//             .join('\n')
//             .replace(/\}\s*$/, '')
//     );
//
//     // �ȳ�ʼ����ʵ������ģ������ ANode�������ܻ�ó�ʼ������
//     var component = new ComponentClass();
//
//     compileComponentSource(sourceBuffer, component);
//     sourceBuffer.addRendererEnd();
//     return sourceBuffer.toCode();
// }
// #[end]

// exports = module.exports = compileJSSource;

    /* eslint-disable no-unused-vars */
//     var nextTick = require('./util/next-tick');
//     var inherits = require('./util/inherits');
//     var parseTemplate = require('./parser/parse-template');
//     var parseExpr = require('./parser/parse-expr');
//     var ExprType = require('./parser/expr-type');
//     var LifeCycle = require('./view/life-cycle');
//     var NodeType = require('./view/node-type');
//     var Component = require('./view/component');
//     var compileComponent = require('./view/compile-component');
//     var defineComponent = require('./view/define-component');
//     var createComponentLoader = require('./view/create-component-loader');
//     var emitDevtool = require('./util/emit-devtool');
//     var compileJSSource = require('./view/compile-js-source');
//     var Data = require('./runtime/data');
//     var evalExpr = require('./runtime/eval-expr');
//     var DataTypes = require('./util/data-types');


    var san = {
        /**
         * san�汾��
         *
         * @type {string}
         */
        version: '3.7.1',

        // #[begin] devtool
        /**
         * �Ƿ������ԡ���������ʱ devtool �Ṥ��
         *
         * @type {boolean}
         */
        debug: true,
        // #[end]

        // #[begin] ssr
//         /**
//          * ����������� renderer ����
//          *
//          * @param {Function} ComponentClass �����
//          * @return {function(Object):string}
//          */
//         compileToRenderer: function (ComponentClass) {
//             var renderer = ComponentClass.__ssrRenderer;
//
//             if (!renderer) {
//                 var code = compileJSSource(ComponentClass);
//                 renderer = (new Function('return ' + code))();
//                 ComponentClass.__ssrRenderer = renderer;
//             }
//
//             return renderer;
//         },
//
//         /**
//          * ����������� renderer ������Դ�ļ�
//          *
//          * @param {Function} ComponentClass �����
//          * @return {string}
//          */
//         compileToSource: compileJSSource,
        // #[end]

        /**
         * �������
         *
         * @type {Function}
         */
        Component: Component,

        /**
         * ���������
         *
         * @param {Object} proto �����ķ�����
         * @return {Function}
         */
        defineComponent: defineComponent,

        /**
         * �������Loader
         *
         * @param {Object|Function} options �������Loader�Ĳ�����ΪObjectʱ�ο��·�������ΪFunctionʱ����load������
         * @param {Function} options.load load����
         * @param {Function=} options.placeholder loading��������Ⱦ��ռλ���
         * @param {Function=} options.fallback loadʧ��ʱ��Ⱦ�����
         * @return {ComponentLoader}
         */
        createComponentLoader: createComponentLoader,

        /**
         * ��������ࡣԤ����template��components
         *
         * @param {Function} ComponentClass �����
         */
        compileComponent: compileComponent,

        /**
         * ���� template
         *
         * @inner
         * @param {string} source template Դ��
         * @return {ANode}
         */
        parseTemplate: parseTemplate,

        /**
         * ��������ʽ
         *
         * @param {string} source Դ��
         * @return {Object}
         */
        parseExpr: parseExpr,

        /**
         * ����ʽ����ö��
         *
         * @const
         * @type {Object}
         */
        ExprType: ExprType,

        /**
         * ��������
         */
        LifeCycle: LifeCycle,

        /**
         * �ڵ�����
         *
         * @const
         * @type {Object}
         */
        NodeType: NodeType,

        /**
         * ����һ�������������к���
         *
         * @param {Function} fn Ҫ���еĺ���
         */
        nextTick: nextTick,

        /**
         * ������
         *
         * @class
         * @param {Object?} data ��ʼ����
         * @param {Data?} parent �������ݶ���
         */
        Data: Data,

        /**
         * �������ʽ��ֵ
         *
         * @param {Object} expr ����ʽ����
         * @param {Data} data ���ݶ���
         * @param {Component=} owner ����������ڱ���ʽ��filter��ִ��
         * @return {*}
         */
        evalExpr: evalExpr,

        /**
         * ������֮��ļ̳й�ϵ
         *
         * @param {Function} subClass ���ຯ��
         * @param {Function} superClass ���ຯ��
         */
        inherits: inherits,

        /**
         * DataTypes
         *
         * @type {Object}
         */
        DataTypes: DataTypes
    };

    // export
    if (typeof exports === 'object' && typeof module === 'object') {
        // For CommonJS
        exports = module.exports = san;
    }
    else if (typeof define === 'function' && define.amd) {
        // For AMD
        define('san', [], san);
    }
    else {
        // For <script src="..."
        root.san = san;
    }

    // #[begin] devtool
    emitDevtool.start(san);
    // #[end]
})(this);
//@ sourceMappingURL=san.dev.js.map